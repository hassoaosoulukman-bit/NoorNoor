package com.osogold.tv

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

/**
 * When a movie / series is not available in the subscription that listed it, "Play" looks for it
 * (1) in the other lists saved by the user, then (2) in the free open / official sources:
 * Archive.org (public-domain and openly licensed films) and the YouTube Data API (Creative Commons
 * videos and the free full movies published by official studio channels).
 */
object OpenSources {

    /** Result of a search: the playable entries and where they were found. */
    class Found(val channels: List<Channel>, val source: String, val youtubeId: String = "")

    /** Official free-movie channels accepted besides Creative Commons videos. */
    private val officialChannels = listOf(
        "filmrise", "popcornflix", "cinedigm", "lionsgate movies", "youtube movies",
        "warner bros", "paramount", "crackle", "hallmark movies"
    )

    private fun norm(text: String): String = ArabicText.normalize(TmdbClient.parseTitle(text).first)

    private fun matches(candidate: String, wanted: String): Boolean {
        if (wanted.length < 2) return false
        val c = norm(candidate)
        return c == wanted || (wanted.length >= 4 && c.contains(wanted))
    }

    // ------------------------------------------------------------------ 1) the other lists of the user

    suspend fun inUserLists(prefs: Prefs, rawTitle: String, tv: Boolean, skipUrl: String): Found? {
        val wanted = norm(rawTitle)
        if (wanted.isBlank()) return null
        val ids = ArrayList<String>()
        if (prefs.xtreamConfigured()) ids.add(if (tv) "x_series" else "x_vod")
        prefs.customLists().forEach { ids.add("m3u:${it.id}") }
        ids.add(if (tv) "series" else "movies")

        for (id in ids) {
            try {
                val all = Catalog.channels(prefs, id, null)
                val hits = all.filter { it.url != skipUrl && matches(it.name, wanted) }
                if (hits.isEmpty()) continue
                val title = Catalog.sections(prefs).firstOrNull { it.id == id }?.title ?: id
                if (tv) {
                    val series = hits.firstOrNull { it.seriesId.isNotEmpty() }
                    if (series != null) {
                        val episodes = Catalog.episodes(prefs, series.seriesId)
                        if (episodes.isNotEmpty()) return Found(episodes, title)
                    }
                    val files = hits.filter { it.seriesId.isEmpty() }.sortedBy { it.name }
                    if (files.isNotEmpty()) return Found(files, title)
                } else {
                    val movie = hits.firstOrNull { it.seriesId.isEmpty() } ?: continue
                    return Found(listOf(movie), title)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // a list that cannot be read must not stop the search
            }
        }
        return null
    }

    // ------------------------------------------------------------------ 2) Archive.org

    suspend fun inArchive(rawTitle: String, englishTitle: String = ""): Found? = withContext(Dispatchers.IO) {
        val names = listOf(englishTitle, TmdbClient.parseTitle(rawTitle).first).filter { it.isNotBlank() }.distinct()
        for (name in names) {
            val wanted = ArabicText.normalize(name)
            if (wanted.length < 3) continue
            try {
                val query = "title:(\"" + name.replace("\"", " ") + "\") AND mediatype:(movies)"
                val url = "https://archive.org/advancedsearch.php?q=" + URLEncoder.encode(query, "UTF-8") +
                    "&fl[]=identifier&fl[]=title&rows=8&output=json"
                val docs = JSONObject(NetConfig.getText(url)).optJSONObject("response")?.optJSONArray("docs")
                    ?: continue
                for (i in 0 until docs.length()) {
                    val doc = docs.optJSONObject(i) ?: continue
                    val id = doc.optString("identifier")
                    val title = doc.optString("title")
                    if (id.isBlank() || !ArabicText.normalize(title).contains(wanted)) continue
                    val file = bestFile(id) ?: continue
                    val link = "https://archive.org/download/$id/" + URLEncoder.encode(file, "UTF-8").replace("+", "%20")
                    return@withContext Found(listOf(Channel(name = title, url = link)), "Archive.org")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            }
        }
        null
    }

    /** Direct link of the best video file of an Archive.org item (null when it has none). Blocking. */
    fun resolveArchive(id: String): String? {
        val file = try {
            bestFile(id)
        } catch (_: Exception) {
            null
        } ?: return null
        return "https://archive.org/download/$id/" + URLEncoder.encode(file, "UTF-8").replace("+", "%20")
    }

    /** The best playable video file of an Archive.org item (MP4 first, then MKV / OGV), skipping tiny previews. */
    private fun bestFile(id: String): String? {
        val files = JSONObject(NetConfig.getText("https://archive.org/metadata/$id")).optJSONArray("files") ?: return null
        var best: String? = null
        var bestScore = -1L
        for (i in 0 until files.length()) {
            val f = files.optJSONObject(i) ?: continue
            val name = f.optString("name")
            val lower = name.lowercase(Locale.ROOT)
            val rank = when {
                lower.endsWith(".mp4") -> 3L
                lower.endsWith(".mkv") -> 2L
                lower.endsWith(".ogv") -> 1L
                else -> continue
            }
            val size = f.optString("size").toLongOrNull() ?: 0L
            if (size in 1 until 5_000_000L) continue
            val score = rank * 10_000_000_000_000L + size
            if (score > bestScore) {
                bestScore = score
                best = name
            }
        }
        return best
    }

    // ------------------------------------------------------------------ 3) YouTube (official channels / Creative Commons)

    /** Needs the YouTube Data API key of Settings. Returns the id of a full free movie, or null. */
    suspend fun onYoutube(prefs: Prefs, rawTitle: String): Found? = withContext(Dispatchers.IO) {
        val key = prefs.youtubeKey
        if (key.isBlank()) return@withContext null
        val title = TmdbClient.parseTitle(rawTitle).first
        val wanted = ArabicText.normalize(title)
        if (wanted.length < 3) return@withContext null
        try {
            for (license in listOf("creativeCommon", "any")) {
                val url = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoDuration=long" +
                    "&videoEmbeddable=true&maxResults=10&videoLicense=$license" +
                    "&q=" + URLEncoder.encode("$title full movie", "UTF-8") + "&key=" + URLEncoder.encode(key, "UTF-8")
                var currentUrl = url
                var text = ""
                var tries = 0
                while (true) {
                    val request = Request.Builder().url(currentUrl).build()
                    var rotated = false
                    text = NetConfig.client().newCall(request).execute().use { r ->
                        val body = r.body?.string().orEmpty()
                        if (ApiKeys.isKeyProblem(r.code) && tries <= prefs.backupKeys(ApiKeys.YOUTUBE).size &&
                            prefs.rotateKey(ApiKeys.YOUTUBE)
                        ) {
                            rotated = true
                            tries++
                            currentUrl = url.substringBeforeLast("&key=") + "&key=" +
                                URLEncoder.encode(prefs.youtubeKey, "UTF-8")
                        }
                        body
                    }
                    if (!rotated) break
                }
                val items: JSONArray = JSONObject(text).optJSONArray("items") ?: continue
                for (i in 0 until items.length()) {
                    val item = items.optJSONObject(i) ?: continue
                    val id = item.optJSONObject("id")?.optString("videoId").orEmpty()
                    val snippet = item.optJSONObject("snippet") ?: continue
                    val channel = snippet.optString("channelTitle").lowercase(Locale.ROOT)
                    val official = officialChannels.any { channel.contains(it) }
                    if (id.isBlank() || !ArabicText.normalize(snippet.optString("title")).contains(wanted)) continue
                    if (license == "creativeCommon" || official) {
                        val label = if (license == "creativeCommon") "YouTube (Creative Commons)"
                        else "YouTube (" + snippet.optString("channelTitle") + ")"
                        return@withContext Found(emptyList(), label, id)
                    }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
        }
        null
    }
}
