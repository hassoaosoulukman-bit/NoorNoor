package com.osogold.tv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Full screen backgrounds drawn by code (no pictures, no big memory): 6 luxurious still ones and 6 soft live
 * ones for the songs player, and the same 6 + 6 in a religious style for the Holy Quran player.
 * The live ones redraw with the display refresh (postInvalidateOnAnimation), only while the view is visible.
 */
object Scenes {

    const val STILL_COUNT = 6
    const val TOTAL = 12

    val songNames = listOf(
        "ذهب أسود", "ليل أزرق", "قطيفة عنابية", "زمرد", "بنفسجي ملكي", "فحم وذهب",
        "مطر", "ثلوج", "بحر وغروب", "موقد نار", "طبيعة ونهر", "شفق ونجوم"
    )
    val quranNames = listOf(
        "نجمة ذهبية", "ليل المئذنة", "محراب", "فيروزي هندسي", "رمل وذهب", "ليل بنفسجي",
        "هلال ونجوم", "قناديل ذهبية", "نور صاعد", "أمواج ضوئية", "غيوم الفجر", "زخرفة دوارة"
    )

    fun create(context: Context, id: Int, religious: Boolean): View =
        if (id < STILL_COUNT) StillScene(context, id, religious)
        else LiveScene(context, id - STILL_COUNT, religious)

    // ------------------------------------------------------------------ still

    private class StillScene(context: Context, val style: Int, val religious: Boolean) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()

        private val songColors = arrayOf(
            intArrayOf(0xFF2B2108.toInt(), 0xFF000000.toInt()), intArrayOf(0xFF10204A.toInt(), 0xFF02040C.toInt()),
            intArrayOf(0xFF5A0F24.toInt(), 0xFF0C0206.toInt()), intArrayOf(0xFF0B4A36.toInt(), 0xFF010A07.toInt()),
            intArrayOf(0xFF3A1766.toInt(), 0xFF06020F.toInt()), intArrayOf(0xFF3A3A3F.toInt(), 0xFF050505.toInt())
        )
        private val quranColors = arrayOf(
            intArrayOf(0xFF0E4D3A.toInt(), 0xFF02100B.toInt()), intArrayOf(0xFF0B1B45.toInt(), 0xFF01030A.toInt()),
            intArrayOf(0xFF2A1C06.toInt(), 0xFF000000.toInt()), intArrayOf(0xFF0A5560.toInt(), 0xFF01100F.toInt()),
            intArrayOf(0xFF6B5428.toInt(), 0xFF120D04.toInt()), intArrayOf(0xFF2C1458.toInt(), 0xFF05020E.toInt())
        )

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val c = (if (religious) quranColors else songColors)[style % 6]
            p.shader = RadialGradient(w * 0.5f, h * 0.35f, max(w, h) * 0.85f, c[0], c[1], Shader.TileMode.CLAMP)
            p.style = Paint.Style.FILL
            canvas.drawRect(0f, 0f, w, h, p)
            p.shader = null
            val gold = 0xFFD4AF37.toInt()
            if (religious) {
                // eight pointed star pattern
                p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f; p.color = (gold and 0x00FFFFFF) or 0x30000000
                val step = max(w, h) / 7f
                var y = step / 2
                while (y < h + step) {
                    var x = step / 2 + if (((y / step).toInt() % 2) == 0) 0f else step / 2
                    while (x < w + step) { star(canvas, x, y, step * 0.36f); x += step }
                    y += step * 0.86f
                }
                if (style == 1 || style == 5) crescent(canvas, w * 0.82f, h * 0.2f, min(w, h) * 0.12f, gold)
                if (style == 2) arch(canvas, w, h, gold)
            } else {
                p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f; p.color = 0x22D4AF37
                val gap = min(w, h) / 9f
                var i = -h
                while (i < w) { canvas.drawLine(i, 0f, i + h, h, p); i += gap } // fine diagonal lines
                p.style = Paint.Style.FILL; p.color = 0x14FFFFFF
                canvas.drawCircle(w * 0.2f, h * 0.8f, min(w, h) * 0.3f, p)
                canvas.drawCircle(w * 0.85f, h * 0.2f, min(w, h) * 0.2f, p)
            }
        }

        private fun star(canvas: Canvas, cx: Float, cy: Float, r: Float) {
            path.reset()
            for (i in 0 until 16) {
                val a = (PI / 8 * i - PI / 2).toFloat()
                val rr = if (i % 2 == 0) r else r * 0.62f
                val x = cx + cos(a) * rr; val y = cy + sin(a) * rr
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            canvas.drawPath(path, p)
        }

        private fun crescent(canvas: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
            p.style = Paint.Style.FILL; p.color = color
            path.reset(); path.addCircle(cx, cy, r, Path.Direction.CW)
            val cut = Path().apply { addCircle(cx + r * 0.42f, cy - r * 0.12f, r * 0.85f, Path.Direction.CW) }
            path.op(cut, Path.Op.DIFFERENCE)
            canvas.drawPath(path, p)
        }

        private fun arch(canvas: Canvas, w: Float, h: Float, color: Int) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = (color and 0x00FFFFFF) or 0x66000000
            val aw = min(w, h) * 0.5f
            path.reset()
            path.moveTo(w / 2 - aw / 2, h)
            path.lineTo(w / 2 - aw / 2, h * 0.45f)
            path.quadTo(w / 2 - aw / 2, h * 0.12f, w / 2, h * 0.08f)
            path.quadTo(w / 2 + aw / 2, h * 0.12f, w / 2 + aw / 2, h * 0.45f)
            path.lineTo(w / 2 + aw / 2, h)
            canvas.drawPath(path, p)
        }
    }

    // ------------------------------------------------------------------ live

    private class LiveScene(context: Context, val kind: Int, val religious: Boolean) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private val rnd = Random(kind * 977 + (if (religious) 5 else 0))
        private var t0 = 0L
        // particles: x, y (0..1), speed, size, phase
        private val n = when { religious && kind == 0 -> 90; religious && kind == 2 -> 70; !religious && kind == 0 -> 130; !religious && kind == 1 -> 110; !religious && kind == 3 -> 46; !religious && kind == 5 -> 80; else -> 40 }
        private val px = FloatArray(n) { rnd.nextFloat() }
        private val py = FloatArray(n) { rnd.nextFloat() }
        private val ps = FloatArray(n) { 0.3f + rnd.nextFloat() }
        private val pz = FloatArray(n) { 0.4f + rnd.nextFloat() }
        private val pf = FloatArray(n) { rnd.nextFloat() * 6.28f }
        private var running = false

        override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; t0 = System.nanoTime(); postInvalidateOnAnimation() }
        override fun onDetachedFromWindow() { running = false; super.onDetachedFromWindow() }
        override fun onVisibilityChanged(changedView: View, visibility: Int) {
            super.onVisibilityChanged(changedView, visibility)
            running = visibility == VISIBLE && isAttachedToWindow
            if (running) postInvalidateOnAnimation()
        }

        private fun grad(canvas: Canvas, w: Float, h: Float, top: Int, bottom: Int, y0: Float = 0f, y1: Float = h) {
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(0f, y0, 0f, y1, top, bottom, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, y0, w, y1, p)
            p.shader = null
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val t = (System.nanoTime() - t0) / 1e9f
            if (religious) when (kind) {
                0 -> starsCrescent(canvas, w, h, t); 1 -> lanterns(canvas, w, h, t); 2 -> risingLight(canvas, w, h, t)
                3 -> lightWaves(canvas, w, h, t); 4 -> dawnClouds(canvas, w, h, t); else -> ornament(canvas, w, h, t)
            } else when (kind) {
                0 -> rain(canvas, w, h, t); 1 -> snow(canvas, w, h, t); 2 -> sea(canvas, w, h, t)
                3 -> fireplace(canvas, w, h, t); 4 -> nature(canvas, w, h, t); else -> aurora(canvas, w, h, t)
            }
            if (running) postInvalidateOnAnimation()
        }

        private fun fall(i: Int, t: Float, speed: Float): Float = ((py[i] + t * speed * ps[i]) % 1f + 1f) % 1f

        private fun rain(c: Canvas, w: Float, h: Float, t: Float) {
            grad(c, w, h, 0xFF16202E.toInt(), 0xFF05080D.toInt())
            p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
            for (i in 0 until n) {
                val y = fall(i, t, 1.1f) * (h + 80f) - 40f
                val x = px[i] * w - y * 0.12f
                p.strokeWidth = 1f + pz[i]; p.color = Color.argb((60 + 90 * pz[i]).toInt().coerceAtMost(200), 170, 200, 235)
                c.drawLine(x, y, x - 4f, y + 14f + 16f * pz[i], p)
            }
            // splashes at the bottom
            p.strokeWidth = 1.4f
            for (i in 0 until 12) {
                val ph = (t * 1.3f + pf[i]) % 1f
                p.color = Color.argb(((1f - ph) * 120).toInt(), 190, 215, 240)
                c.drawOval(px[i] * w - 20f * ph, h - 26f - 6f * pz[i] - 4f * ph, px[i] * w + 20f * ph, h - 26f - 6f * pz[i] + 4f * ph, p)
            }
        }

        private fun snow(c: Canvas, w: Float, h: Float, t: Float) {
            grad(c, w, h, 0xFF1C2B45.toInt(), 0xFF0A1220.toInt())
            p.style = Paint.Style.FILL
            for (i in 0 until n) {
                val y = fall(i, t, 0.08f) * (h + 20f) - 10f
                val x = px[i] * w + sin(t * 0.8f * ps[i] + pf[i]) * 24f
                p.color = Color.argb((120 + 120 * pz[i]).toInt().coerceAtMost(240), 255, 255, 255)
                c.drawCircle(x, y, 1.5f + 3.2f * pz[i], p)
            }
            p.color = 0xFFE9F1FA.toInt()
            c.drawRect(0f, h - 18f, w, h, p) // snowy ground
        }

        private fun sea(c: Canvas, w: Float, h: Float, t: Float) {
            val horizon = h * 0.58f
            grad(c, w, h, 0xFF2A1B4D.toInt(), 0xFFFF8A3D.toInt(), 0f, horizon)
            // sun
            val sunY = horizon - h * 0.05f + sin(t * 0.1f) * 4f
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(w / 2, sunY, h * 0.3f, 0x99FFD27A.toInt(), 0x00FFB347, Shader.TileMode.CLAMP)
            c.drawCircle(w / 2, sunY, h * 0.3f, p); p.shader = null
            p.color = 0xFFFFE2A0.toInt(); c.drawCircle(w / 2, sunY, h * 0.075f, p)
            grad(c, w, h, 0xFF5C3A6E.toInt(), 0xFF0B1E3A.toInt(), horizon, h * 0.88f)
            // waves
            for (k in 0 until 4) {
                val base = horizon + (h * 0.88f - horizon) * (k + 1) / 5f
                path.reset(); path.moveTo(0f, h)
                var x = 0f
                while (x <= w + 20f) { path.lineTo(x, base + sin(x / (60f + k * 30f) + t * (0.9f + k * 0.25f)) * (4f + k * 3f)); x += 20f }
                path.lineTo(w, h); path.close()
                p.color = Color.argb(70 + k * 20, 30 + k * 10, 60 + k * 15, 110 + k * 15)
                c.drawPath(path, p)
            }
            // sun reflection
            p.color = 0x55FFD27A
            for (i in 0 until 7) { val y = horizon + 10f + i * 16f; val ww = 90f - i * 8f + sin(t * 2f + i) * 10f; c.drawRect(w / 2 - ww / 2, y, w / 2 + ww / 2, y + 3f, p) }
            // beach
            path.reset(); path.moveTo(0f, h); path.lineTo(0f, h * 0.92f)
            var x = 0f
            while (x <= w + 20f) { path.lineTo(x, h * 0.92f + sin(x / 90f) * 6f); x += 20f }
            path.lineTo(w, h); path.close(); p.color = 0xFFC9A36B.toInt(); c.drawPath(path, p)
            // foam
            p.color = Color.argb(110, 255, 255, 255)
            val fy = h * 0.9f + sin(t * 1.2f) * 5f
            c.drawRect(0f, fy, w, fy + 3f, p)
        }

        private fun fireplace(c: Canvas, w: Float, h: Float, t: Float) {
            grad(c, w, h, 0xFF2A1610.toInt(), 0xFF0B0504.toInt())
            val cx = w / 2; val fw = min(w * 0.5f, h * 0.7f); val top = h * 0.3f; val bottom = h * 0.9f
            // bricks / mantle
            p.style = Paint.Style.FILL; p.color = 0xFF4A2A1E.toInt()
            c.drawRect(cx - fw / 2 - 24f, top - 28f, cx + fw / 2 + 24f, bottom, p)
            p.color = 0xFF2E1710.toInt(); c.drawRect(cx - fw / 2, top, cx + fw / 2, bottom, p)
            p.color = 0xFF5E3626.toInt(); c.drawRect(cx - fw / 2 - 40f, top - 40f, cx + fw / 2 + 40f, top - 22f, p)
            // glow of the fire on the room (flickers)
            val flick = 0.75f + 0.25f * sin(t * 9f) * sin(t * 5.3f)
            p.shader = RadialGradient(cx, bottom - fw * 0.15f, max(w, h) * 0.7f, Color.argb((120 * flick).toInt(), 255, 140, 40), 0x00FF8C28, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p); p.shader = null
            // logs
            p.color = 0xFF3B2314.toInt(); c.drawRoundRect(cx - fw * 0.38f, bottom - 26f, cx + fw * 0.38f, bottom - 6f, 10f, 10f, p)
            // flames: rising particles
            for (i in 0 until n) {
                val life = fall(i, t, 0.55f)
                val x = cx + (px[i] - 0.5f) * fw * 0.7f * (1f - life * 0.6f) + sin(t * 3f + pf[i]) * 8f * life
                val y = bottom - 20f - life * fw * 0.6f
                val r = (10f + 20f * pz[i]) * (1f - life * 0.8f)
                val a = ((1f - life) * 200).toInt()
                p.color = Color.argb(a, 255, (80 + 150 * (1f - life)).toInt().coerceAtMost(255), (20 + 40 * (1f - life)).toInt())
                c.drawCircle(x, y, r, p)
            }
        }

        private fun nature(c: Canvas, w: Float, h: Float, t: Float) {
            grad(c, w, h, 0xFF6FB6E8.toInt(), 0xFFEAF6FF.toInt(), 0f, h * 0.55f)
            p.style = Paint.Style.FILL
            // clouds
            p.color = 0x99FFFFFF.toInt()
            for (i in 0 until 4) { val x = ((i * 0.3f + t * 0.01f * (1 + i * 0.2f)) % 1.3f - 0.15f) * w; c.drawOval(x, h * (0.08f + i * 0.05f), x + w * 0.2f, h * (0.08f + i * 0.05f) + h * 0.06f, p) }
            // hills
            p.color = 0xFF2F7A47.toInt()
            path.reset(); path.moveTo(0f, h * 0.62f)
            var x = 0f; while (x <= w + 20f) { path.lineTo(x, h * 0.5f + sin(x / w * 5f) * h * 0.05f); x += 20f }
            path.lineTo(w, h); path.lineTo(0f, h); path.close(); c.drawPath(path, p)
            // river
            val rx = w * 0.5f
            path.reset(); path.moveTo(rx - 30f, h * 0.52f)
            path.quadTo(rx - 160f, h * 0.7f, rx - 80f, h); path.lineTo(rx + 160f, h)
            path.quadTo(rx + 70f, h * 0.7f, rx + 30f, h * 0.52f); path.close()
            p.color = 0xFF2A7FB5.toInt(); c.drawPath(path, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0x88FFFFFF.toInt()
            for (i in 0 until 14) { // flowing ripples
                val life = ((i / 14f + t * 0.2f) % 1f)
                val y = h * 0.54f + life * h * 0.46f
                val spread = 28f + life * 150f
                val cxr = rx + 15f - life * 55f
                c.drawLine(cxr - spread * 0.4f + sin(t + i) * 6f, y, cxr + spread * 0.4f + sin(t + i) * 6f, y, p)
            }
            // trees
            p.style = Paint.Style.FILL
            for (i in 0 until 14) {
                val side = if (i % 2 == 0) -1 else 1
                val tx = rx + side * (w * 0.22f + (i / 2) * w * 0.065f) + (if (side < 0) -20f else 40f)
                val ty = h * 0.6f + (i % 7) * h * 0.055f
                val s = 0.7f + (i % 7) * 0.12f
                p.color = 0xFF4A2F1A.toInt(); c.drawRect(tx - 4f * s, ty, tx + 4f * s, ty + 26f * s, p)
                p.color = 0xFF14532D.toInt()
                val sway = sin(t * 0.8f + i) * 3f * s
                for (j in 0 until 3) { path.reset(); path.moveTo(tx + sway * (3 - j) / 3f, ty - 36f * s + j * 18f * s); path.lineTo(tx - 24f * s + j * 3f * s, ty + j * 10f * s); path.lineTo(tx + 24f * s - j * 3f * s, ty + j * 10f * s); path.close(); c.drawPath(path, p) }
            }
        }

        private fun aurora(c: Canvas, w: Float, h: Float, t: Float) {
            grad(c, w, h, 0xFF030614.toInt(), 0xFF0E1E3A.toInt())
            p.style = Paint.Style.FILL
            for (i in 0 until n) { // twinkling stars
                val a = (0.35f + 0.65f * abs(sin(t * ps[i] + pf[i]))); p.color = Color.argb((a * 255).toInt(), 255, 255, 255)
                c.drawCircle(px[i] * w, py[i] * h * 0.75f, 0.8f + 1.6f * pz[i], p)
            }
            val cols = intArrayOf(0x4400FFAA, 0x3340B0FF, 0x33C060FF)
            for (k in 0 until 3) {
                path.reset(); path.moveTo(0f, h * 0.7f)
                var x = 0f
                while (x <= w + 20f) { path.lineTo(x, h * (0.28f + k * 0.07f) + sin(x / (110f + k * 40f) + t * (0.5f + k * 0.2f)) * h * 0.06f); x += 20f }
                path.lineTo(w, h * 0.7f); path.close()
                p.shader = LinearGradient(0f, h * 0.2f, 0f, h * 0.7f, cols[k], 0x00000000, Shader.TileMode.CLAMP)
                c.drawPath(path, p)
            }
            p.shader = null
            p.color = 0xFF04070F.toInt() // dark ground with a few trees
            c.drawRect(0f, h * 0.9f, w, h, p)
        }

        // ---- religious

        private fun starsCrescent(c: Canvas, w: Float, h: Float, t: Float) {
            grad(c, w, h, 0xFF0B1B45.toInt(), 0xFF02050F.toInt())
            p.style = Paint.Style.FILL
            for (i in 0 until n) {
                val a = (0.3f + 0.7f * abs(sin(t * ps[i] * 1.2f + pf[i]))); p.color = Color.argb((a * 255).toInt(), 255, 244, 205)
                c.drawCircle(px[i] * w, py[i] * h, 0.9f + 1.8f * pz[i], p)
            }
            val r = min(w, h) * 0.13f; val cx = w * 0.8f; val cy = h * 0.22f + sin(t * 0.4f) * 5f
            p.shader = RadialGradient(cx, cy, r * 2.6f, 0x66FFE9A0, 0x00FFE9A0, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r * 2.6f, p); p.shader = null
            path.reset(); path.addCircle(cx, cy, r, Path.Direction.CW)
            val cut = Path().apply { addCircle(cx + r * 0.42f, cy - r * 0.12f, r * 0.85f, Path.Direction.CW) }
            path.op(cut, Path.Op.DIFFERENCE)
            p.color = 0xFFF4D67A.toInt(); c.drawPath(path, p)
        }

        private fun lanterns(c: Canvas, w: Float, h: Float, t: Float) {
            grad(c, w, h, 0xFF17102E.toInt(), 0xFF05030C.toInt())
            val count = 5
            for (i in 0 until count) {
                val x0 = w * (i + 0.5f) / count
                val len = h * (0.22f + 0.1f * ((i * 37) % 5) / 5f)
                val ang = sin(t * (0.7f + i * 0.11f) + i) * 0.12f
                val lx = x0 + sin(ang) * len; val ly = len * cos(ang)
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0xAAD4AF37.toInt()
                c.drawLine(x0, 0f, lx, ly, p)
                val glow = 0.8f + 0.2f * sin(t * 3f + i * 2f)
                p.style = Paint.Style.FILL
                p.shader = RadialGradient(lx, ly + 30f, 110f, Color.argb((130 * glow).toInt(), 255, 190, 70), 0x00FFBE46, Shader.TileMode.CLAMP)
                c.drawCircle(lx, ly + 30f, 110f, p); p.shader = null
                c.save(); c.rotate(Math.toDegrees(ang.toDouble()).toFloat(), lx, ly)
                p.color = 0xFFD4AF37.toInt(); c.drawRect(lx - 14f, ly, lx + 14f, ly + 6f, p)
                path.reset(); path.moveTo(lx - 14f, ly + 6f); path.lineTo(lx + 14f, ly + 6f); path.lineTo(lx + 24f, ly + 52f); path.lineTo(lx - 24f, ly + 52f); path.close()
                p.color = Color.argb(230, 255, (170 + 40 * glow).toInt().coerceAtMost(255), 60); c.drawPath(path, p)
                p.color = 0xFFD4AF37.toInt(); c.drawRect(lx - 26f, ly + 52f, lx + 26f, ly + 60f, p)
                c.restore()
            }
        }

        private fun risingLight(c: Canvas, w: Float, h: Float, t: Float) {
            grad(c, w, h, 0xFF063B2C.toInt(), 0xFF010C08.toInt())
            p.style = Paint.Style.FILL
            for (i in 0 until n) {
                val life = 1f - fall(i, t, 0.07f)
                val y = life * h
                val x = px[i] * w + sin(t * 0.6f + pf[i]) * 20f
                val a = (sin(life * PI.toFloat()) * 200).toInt().coerceIn(0, 255)
                p.shader = RadialGradient(x, y, 10f + 10f * pz[i], Color.argb(a, 255, 226, 140), 0x00FFE28C, Shader.TileMode.CLAMP)
                c.drawCircle(x, y, 10f + 10f * pz[i], p)
            }
            p.shader = null
        }

        private fun lightWaves(c: Canvas, w: Float, h: Float, t: Float) {
            grad(c, w, h, 0xFF042F3A.toInt(), 0xFF010A0D.toInt())
            p.style = Paint.Style.FILL
            for (k in 0 until 5) {
                path.reset(); path.moveTo(0f, h)
                var x = 0f
                while (x <= w + 20f) { path.lineTo(x, h * (0.35f + k * 0.12f) + sin(x / (140f + k * 30f) + t * (0.4f + k * 0.12f) + k) * h * 0.04f); x += 20f }
                path.lineTo(w, h); path.close()
                p.shader = LinearGradient(0f, h * 0.3f, 0f, h, Color.argb(70, 120, 230, 210), 0x00000000, Shader.TileMode.CLAMP)
                c.drawPath(path, p)
            }
            p.shader = null
        }

        private fun dawnClouds(c: Canvas, w: Float, h: Float, t: Float) {
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(0xFF141C4A.toInt(), 0xFF7A4B8A.toInt(), 0xFFF0A070.toInt(), 0xFFFFD98A.toInt()), floatArrayOf(0f, 0.45f, 0.8f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p); p.shader = null
            p.color = 0x55FFFFFF
            for (i in 0 until 7) {
                val sp = 0.008f + 0.004f * (i % 3)
                val x = ((px[i] + t * sp) % 1.4f - 0.2f) * w; val y = h * (0.15f + 0.1f * i)
                val s = 40f + 25f * pz[i]
                for (j in 0 until 4) c.drawCircle(x + j * s * 0.8f, y + (if (j % 2 == 0) 0f else -s * 0.3f), s, p)
            }
        }

        private fun ornament(c: Canvas, w: Float, h: Float, t: Float) {
            grad(c, w, h, 0xFF0A0A14.toInt(), 0xFF020206.toInt())
            val cx = w / 2; val cy = h / 2; val r = min(w, h) * 0.42f
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f
            for (layer in 0 until 4) {
                val rot = t * (0.15f + layer * 0.07f) * (if (layer % 2 == 0) 1 else -1)
                val rr = r * (1f - layer * 0.2f)
                val pts = 8 + layer * 4
                p.color = Color.argb(150 - layer * 25, 212, 175, 55)
                path.reset()
                for (i in 0 until pts * 2) {
                    val a = rot + PI.toFloat() / pts * i
                    val q = if (i % 2 == 0) rr else rr * 0.6f
                    val x = cx + cos(a) * q; val y = cy + sin(a) * q
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close(); c.drawPath(path, p)
                c.drawCircle(cx, cy, rr * 1.05f, p)
            }
        }
    }
}
