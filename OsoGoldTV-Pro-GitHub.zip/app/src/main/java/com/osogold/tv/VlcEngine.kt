package com.osogold.tv

import android.content.Context
import android.net.Uri
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

/**
 * Secondary player: LibVLC (built in). Media3 / ExoPlayer is the default player of the app; the
 * user can switch to LibVLC in Settings or with the engine button of the player at any time.
 *
 * LibVLC plays inside the activity (it is not part of the background service), so the guaranteed
 * background / locked screen playback belongs to the Media3 engine.
 */
class VlcEngine(context: Context) {

    private val appContext = context.applicationContext
    private var libVlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private var attachedLayout: VLCVideoLayout? = null
    private var currentUrl: String? = null
    private var currentAgent: String = "IPTVSmartersPro"

    /** LibVLC options for the subtitle look (size / colour / position). Applied when the player is created. */
    var subtitleOptions: List<String> = emptyList()

    /** Called (main thread) when the stream cannot be played. */
    var onError: (() -> Unit)? = null

    /** Called (main thread) as soon as the picture starts. */
    var onPlaying: (() -> Unit)? = null

    /** Called (main thread) when the video output is created (first picture): the surface must be redrawn. */
    var onVout: (() -> Unit)? = null

    private var equalizer: Any? = null

    /** Equalizer of LibVLC (10 bands, dB). null = off. Reflection keeps this independent of the LibVLC version. */
    fun setEqualizer(gainsDb: FloatArray?, preAmpDb: Float) {
        val mp = player ?: return
        try {
            val eqClass = Class.forName("org.videolan.libvlc.MediaPlayer\$Equalizer")
            val setter = mp.javaClass.getMethod("setEqualizer", eqClass)
            if (gainsDb == null) {
                setter.invoke(mp, *arrayOf<Any?>(null))
                equalizer = null
                return
            }
            val eq = eqClass.getMethod("create").invoke(null)
            eqClass.getMethod("setPreAmp", Float::class.javaPrimitiveType).invoke(eq, preAmpDb)
            val setAmp = eqClass.getMethod("setAmp", Int::class.javaPrimitiveType, Float::class.javaPrimitiveType)
            for (i in gainsDb.indices) setAmp.invoke(eq, i, gainsDb[i].coerceIn(-20f, 20f))
            setter.invoke(mp, eq)
            equalizer = eq
        } catch (_: Throwable) {
        }
    }

    val isPlaying: Boolean
        get() = player?.isPlaying == true

    private fun ensure(): MediaPlayer {
        player?.let { return it }
        // hardware decoding (MediaCodec) is forced for every stream: smooth 1080p / 4K with a light CPU
        // audio: AC3 / EAC3 / DTS are fully decoded and mixed down to stereo PCM (no pass-through, no crackling)
        val options = arrayListOf(
            "--avcodec-hw=any", "--no-drop-late-frames", "--no-skip-frames",
            "--no-spdif", "--audio-time-stretch", "--aout=opensles"
        )
        options.addAll(subtitleOptions)
        val lib = LibVLC(appContext, options)
        val mp = MediaPlayer(lib)
        mp.setVolume(100)
        mp.setEventListener { event ->
            when (event.type) {
                MediaPlayer.Event.EncounteredError -> onError?.invoke()
                MediaPlayer.Event.Playing -> onPlaying?.invoke()
                MediaPlayer.Event.Vout -> onVout?.invoke()
                else -> Unit
            }
        }
        libVlc = lib
        player = mp
        return mp
    }

    /** Shows the video inside [layout] (the circle of the main screen or the full screen stage). */
    fun attach(layout: VLCVideoLayout?) {
        val mp = ensure()
        if (attachedLayout === layout) return
        if (attachedLayout != null) mp.detachViews()
        attachedLayout = layout
        if (layout != null) mp.attachViews(layout, null, false, false)
    }

    fun play(url: String, userAgent: String, startMs: Long = 0L) {
        val mp = ensure()
        val lib = libVlc ?: return
        currentUrl = url
        currentAgent = userAgent
        val media = Media(lib, Uri.parse(url))
        media.addOption(":http-user-agent=$userAgent")
        applyProxy(media)
        // anti-freeze: a short 0.8 s network buffer (fast zapping), automatic re-connection, hardware decoding (4K / 8K / HEVC / AV1)
        if (startMs > 0L) media.addOption(":start-time=${startMs / 1000.0}")
        media.addOption(":network-caching=800")
        media.addOption(":live-caching=800")
        media.addOption(":http-reconnect")
        media.addOption(":avcodec-hw=any")
        media.addOption(":no-spdif")
        media.addOption(":audio-desync=0")
        if (!url.startsWith("http", true) || startMs > 0L) media.addOption(":file-caching=1500")
        media.setHWDecoderEnabled(true, true)
        mp.setMedia(media)
        media.release()
        mp.play()
    }

    /** The encrypted proxy of the protection settings is used by LibVLC too. */
    private fun applyProxy(media: Media) {
        val p = Prefs(appContext)
        if (!p.protectionOn || !p.proxyConfigured()) return
        if (p.proxyType == 1) {
            media.addOption(":socks=${p.proxyHost}:${p.proxyPort}")
            if (p.proxyUser.isNotBlank()) {
                media.addOption(":socks-user=${p.proxyUser}")
                media.addOption(":socks-pwd=${p.proxyPass}")
            }
        } else {
            val auth = if (p.proxyUser.isNotBlank())
                Uri.encode(p.proxyUser) + ":" + Uri.encode(p.proxyPass) + "@" else ""
            media.addOption(":http-proxy=http://$auth${p.proxyHost}:${p.proxyPort}")
        }
    }

    /** Subtitle tracks of the running stream as (id, name). id -1 = off. */
    fun subtitleTracks(): List<Pair<Int, String>> {
        val tracks = player?.spuTracks ?: return emptyList()
        return tracks.map { it.id to it.name }
    }

    fun selectSubtitleTrack(id: Int) {
        player?.setSpuTrack(id)
    }

    /** Loads an external subtitle file (srt / ass / vtt ...) and selects it. */
    fun addSubtitle(uri: Uri) {
        player?.addSlave(org.videolan.libvlc.interfaces.IMedia.Slave.Type.Subtitle, uri, true)
    }

    /** New subtitle look: LibVLC reads these options only when it is created, so it is rebuilt. */
    fun applySubtitleOptions(options: List<String>) {
        subtitleOptions = options
        val layout = attachedLayout
        val url = currentUrl
        val agent = currentAgent
        if (player == null) return
        try {
            player?.stop()
            if (attachedLayout != null) player?.detachViews()
            player?.release()
            libVlc?.release()
        } catch (_: Exception) {
        }
        player = null
        libVlc = null
        attachedLayout = null
        if (layout != null) attach(layout)
        if (url != null) play(url, agent)
    }

    fun pause() {
        player?.pause()
    }

    fun resume() {
        player?.play()
    }

    fun togglePlayPause() {
        val mp = player ?: return
        if (mp.isPlaying) mp.pause() else mp.play()
    }

    fun stop() {
        currentUrl = null
        player?.stop()
    }

    /**
     * Video shape: 0 fill screen (crop), 1 cinema 2.39:1, 2 original (fit), 3 stretch.
     * Really changes the picture: aspect ratio + scale type of the LibVLC player.
     */
    fun applyAspect(mode: Int, screenW: Int = 0, screenH: Int = 0) {
        val mp = player ?: return
        try {
            when (mode) {
                0 -> {
                    mp.setAspectRatio(null)
                    mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_FIT_SCREEN)
                }
                1 -> {
                    mp.setAspectRatio("239:100")
                    mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_FILL)
                }
                2 -> {
                    mp.setAspectRatio(null)
                    mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_BEST_FIT)
                }
                else -> {
                    val w = if (screenW > 0) screenW else 16
                    val h = if (screenH > 0) screenH else 9
                    mp.setAspectRatio("$w:$h")
                    mp.setVideoScale(MediaPlayer.ScaleType.SURFACE_FILL)
                }
            }
        } catch (_: Throwable) {
        }
    }

    /** Video tracks of the running stream as (id, name). */
    fun videoTracks(): List<Pair<Int, String>> {
        val tracks = player?.videoTracks ?: return emptyList()
        return tracks.filter { it.id >= 0 }.map { it.id to it.name }
    }

    /** Real (width, height, fps) of the running picture, or null. */
    fun videoInfo(): Triple<Int, Int, Float>? = try {
        val t = player?.currentVideoTrack
        if (t == null) null
        else Triple(t.width, t.height, if (t.frameRateDen > 0) t.frameRateNum.toFloat() / t.frameRateDen else 0f)
    } catch (_: Throwable) {
        null
    }

    /** Audio-only mode: the video track is switched off (the sound goes on). */
    fun setVideoEnabled(enabled: Boolean) {
        try {
            if (!enabled) player?.setVideoTrack(-1)
            else videoTracks().firstOrNull()?.let { player?.setVideoTrack(it.first) }
        } catch (_: Throwable) {
        }
    }

    fun selectVideoTrack(id: Int) {
        player?.setVideoTrack(id)
    }

    /** Back to automatic quality: the stream is simply started again with the default choice. */
    /** Position and length of the running movie in milliseconds (0 when unknown / live). */
    fun position(): Long = try { player?.time?.coerceAtLeast(0L) ?: 0L } catch (_: Exception) { 0L }

    /** Jumps to [ms] inside the running movie. */
    fun seekTo(ms: Long) {
        try { player?.time = ms.coerceAtLeast(0L) } catch (_: Exception) {}
    }

    fun duration(): Long = try { player?.length?.coerceAtLeast(0L) ?: 0L } catch (_: Exception) { 0L }

    fun resetQuality(userAgent: String) {
        val url = currentUrl ?: return
        play(url, userAgent)
    }

    fun release() {
        try {
            player?.stop()
            if (attachedLayout != null) player?.detachViews()
            player?.release()
            libVlc?.release()
        } catch (_: Exception) {
        }
        attachedLayout = null
        player = null
        libVlc = null
        currentUrl = null
    }
}
