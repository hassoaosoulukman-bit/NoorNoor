package com.osogold.tv

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.ContentValues
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import coil.load
import coil.transform.CircleCropTransformation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder

/**
 * Songs and music: three tabs (Arabic / Kurdish / Turkish, old and new). A bilingual singer search
 * (Arabic spelling + Latin transliteration) on the free iTunes Search API: singer -> albums -> the songs
 * of the opened album. The player has a rotating golden disc with the cover (drag it anywhere, 4 sizes),
 * all controls, a music equalizer, saving to Music/OsoGoldTV (MediaStore) and the full song through YouTube.
 *
 * Note: iTunes gives a 30 second preview of every song; the full song is played through YouTube.
 */
class SongsActivity : BaseActivity() {

    private class Song(val name: String, val artist: String, val album: String, val preview: String, val art: String)
    private class Album(val id: Long, val name: String, val art: String)
    private class Artist(val label: String, val term: String, val id: Long = 0L)

    private lateinit var prefs: Prefs
    private val ui = Handler(Looper.getMainLooper())
    private val gold = 0xFFD4AF37.toInt()

    private val tabs = listOf(
        "fav" to "❤️ المفضلة", "ar" to "أغاني عربية", "ku" to "أغاني كردية", "tr" to "أغاني تركية"
    )
    private val curated = mapOf(
        "ar" to listOf("عمرو دياب" to "Amr Diab", "فيروز" to "Fairuz", "أم كلثوم" to "Umm Kulthum", "عبد الحليم حافظ" to "Abdel Halim Hafez",
            "فريد الأطرش" to "Farid al-Atrash", "وردة" to "Warda", "كاظم الساهر" to "Kadim Al Sahir", "نانسي عجرم" to "Nancy Ajram",
            "محمد عبده" to "Mohammed Abdu", "أصالة" to "Assala", "وائل كفوري" to "Wael Kfoury", "ماجدة الرومي" to "Majida El Roumi",
            "حسين الجسمي" to "Hussain Al Jassmi", "تامر حسني" to "Tamer Hosny", "محمد منير" to "Mohamed Mounir"),
        "ku" to listOf("شيفان برور" to "Sivan Perwer", "جوان حاجو" to "Ciwan Haco", "آرام تيغران" to "Aram Tigran", "محسون كيرميزيغول" to "Mahsun Kirmizigul",
            "روجدا" to "Rojda", "هوزان دينو" to "Hozan Dino", "نظام الدين أريج" to "Nizamettin Aric", "فرهاد تونج" to "Ferhat Tunc", "آينور دوغان" to "Aynur Dogan"),
        "tr" to listOf("تاركان" to "Tarkan", "إبراهيم تاتليسس" to "Ibrahim Tatlises", "سيزن أكسو" to "Sezen Aksu", "أجدا بيكان" to "Ajda Pekkan",
            "بارش مانتشو" to "Baris Manco", "مسلم غورسس" to "Muslum Gurses", "إيبرو غوندش" to "Ebru Gundes", "سرتاب أرنر" to "Sertab Erener",
            "مصطفى ساندال" to "Mustafa Sandal", "كينان دوغولو" to "Kenan Dogulu", "فردي تايفور" to "Ferdi Tayfur", "هاندي ينير" to "Hande Yener")
    )

    private var tab = "ar"
    private var artists: List<Artist> = emptyList()
    private var albums: List<Album> = emptyList()
    private var songs: List<Song> = emptyList()
    private var currentArtist = ""
    private var currentAlbum = ""
    private var index = -1

    private lateinit var status: TextView
    private lateinit var artistList: ListView
    private lateinit var albumList: ListView
    private lateinit var songList: ListView
    private lateinit var search: EditText
    private val tabViews = ArrayList<TextView>()

    // player
    private var exo: ExoPlayer? = null
    private var fx: SoundFx.SessionFx? = null
    private var currentStream = ""
    private var resolveJob: kotlinx.coroutines.Job? = null
    private var playerLayer: FrameLayout? = null
    private lateinit var kit: PlayerUiKit
    private var panelRow: LinearLayout? = null
    private var swipe: SwipeControl? = null
    private var albumSel = -1
    private var floatSongs: ListView? = null
    private val pickImage = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && ::kit.isInitialized) kit.onImagePicked(uri)
    }
    private lateinit var disc: FrameLayout
    private lateinit var cover: ImageView
    private lateinit var songTitle: TextView
    private lateinit var songSub: TextView
    private lateinit var playBtn: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeText: TextView
    private var floatingPanel: LinearLayout? = null
    private var spin: ObjectAnimator? = null
    private var seeking = false
    private var prepared = false

    private val tick = object : Runnable {
        override fun run() {
            try {
                val p = exo
                if (p != null && prepared && !seeking) {
                    val total = if (p.duration == C.TIME_UNSET) 0 else p.duration.toInt()
                    seek.max = total.coerceAtLeast(1)
                    seek.progress = p.currentPosition.toInt().coerceAtLeast(0)
                    timeText.text = fmt(p.currentPosition.toInt()) + " / " + fmt(total)
                    playBtn.text = if (p.isPlaying) "⏸" else "▶"
                    spin?.let { s -> if (p.isPlaying && s.isPaused) s.resume() else if (!p.isPlaying && s.isRunning) s.pause() }
                }
            } catch (_: Throwable) {
            }
            ui.postDelayed(this, 400L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        currentPreset = SoundFx.presetById(getSharedPreferences("player_ui", MODE_PRIVATE).getString("song_eq", "normal") ?: "normal")
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (playerLayer?.visibility == View.VISIBLE) {
                    closePlayer()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        root.addView(CosmicBackgroundView(this), FrameLayout.LayoutParams(-1, -1))

        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(66), dp(10), dp(16), dp(10)) // the golden back button sits in the top-left corner
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(main, FrameLayout.LayoutParams(-1, -1))

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "🎵 الأغاني والموسيقى"; textSize = 20f; setTextColor(gold); typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        for ((code, name) in tabs) {
            val t = chip(name) { selectTab(code) }
            tabViews.add(t)
            head.addView(t, LinearLayout.LayoutParams(-2, dp(38)).apply { marginStart = dp(6) })
        }
        main.addView(head)

        search = EditText(this).apply {
            hint = "ابحث عن مطرب — بالعربية أو الحروف اللاتينية (مثال: تاركان / Tarkan)"
            setTextColor(Color.WHITE); setHintTextColor(0x88FFFFFF.toInt()); textSize = 14f
            isSingleLine = true
            setBackgroundColor(0x33FFFFFF)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { v, _, _ ->
                hideKeyboard(v)                 // the keyboard closes at once so the singers appear directly
                runSearch(text.toString())
                true
            }
        }
        main.addView(search, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(6) })

        status = TextView(this).apply { setTextColor(0xFFB8A878.toInt()); textSize = 12f; gravity = Gravity.CENTER }
        main.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        val cols = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        artistList = listView(); albumList = listView(); songList = listView()
        fun column(title: String, list: ListView): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = title; setTextColor(gold); textSize = 14f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD })
            addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        cols.addView(column("الأغاني", songList), LinearLayout.LayoutParams(0, -1, 1.2f).apply { marginEnd = dp(4) })
        cols.addView(column("الألبومات", albumList), LinearLayout.LayoutParams(0, -1, 1f).apply { marginEnd = dp(4) })
        cols.addView(column("المطربون", artistList), LinearLayout.LayoutParams(0, -1, 1f))
        main.addView(cols, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(4) })

        artistList.setOnItemClickListener { _, _, i, _ -> hideKeyboard(search); artists.getOrNull(i)?.let { openArtist(it) } }
        albumList.setOnItemClickListener { _, _, i, _ -> albums.getOrNull(i)?.let { openAlbum(it) } }
        songList.setOnItemClickListener { _, _, i, _ -> playAt(i) }
        songList.setOnItemLongClickListener { _, _, i, _ -> songs.getOrNull(i)?.let { toggleFav(it) }; true }

        buildPlayer(root)
        setContentView(root)
        ui.post(tick)
        selectTab("ar")
    }

    // ------------------------------------------------------------------ browsing

    private fun selectTab(code: String) {
        tab = code
        tabs.forEachIndexed { i, (c, _) -> paintChip(tabViews[i], c == code) }
        artists = (curated[code] ?: emptyList()).map { Artist(it.first + "  ·  " + it.second, it.second) }
        showArtists()
        albums = emptyList(); songs = emptyList()
        if (code == "fav") {
            // the favourite songs (kept permanently): tap = play, long press = remove
            songs = prefs.favoritesOf("song").map { Song(it.name.substringAfter(" — "), it.name.substringBefore(" — "), it.group, "", it.logo) }
            showAlbums(); showSongs()
            status.text = if (songs.isEmpty()) "لا توجد أغانٍ مفضلة بعد — اضغط مطولاً على أغنية أو ❤️ في المشغل" else "${songs.size} أغنية مفضلة"
            return
        }
        showAlbums(); showSongs()
        status.text = "اختر مطرباً أو ابحث عنه"
    }

    private fun showArtists() { artistList.adapter = listAdapter(artists.map { it.label }) }
    private fun showAlbums() { albumList.adapter = listAdapter(albums.map { it.name }) { albumSel } }
    private fun songKey(s: Song) = "song:" + s.artist + "||" + s.name
    private fun songAsChannel(s: Song) = Channel(name = s.artist + " — " + s.name, url = songKey(s), logo = s.art, group = s.album)
    private fun isFav(s: Song) = prefs.isFavorite(songKey(s))
    private fun toggleFav(s: Song) {
        val now = prefs.toggleFavorite(songAsChannel(s), "song")
        toast(if (now) "❤️ أُضيفت «${s.name}» إلى المفضلة" else "أُزيلت «${s.name}» من المفضلة")
        if (tab == "fav") selectTab("fav") else showSongs()
    }
    private fun showSongs() { songList.adapter = listAdapter(songs.mapIndexed { i, s -> (if (isFav(s)) "❤️ " else "") + "${i + 1}. ${s.name}" }) }

    private fun country(): String = when (tab) { "ar" -> "EG"; else -> "TR" }

    private fun itunes(path: String): JSONObject = JSONObject(NetConfig.getText("https://itunes.apple.com/$path"))

    private fun hideKeyboard(v: View) {
        try {
            val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.hideSoftInputFromWindow(v.windowToken, 0)
            v.clearFocus()
        } catch (_: Throwable) {}
    }

    /** Comparison key of a singer name: Arabic letters unified, symbols and spaces removed. */
    private fun nameKey(s: String): String = LogoDb.norm(s)

    /**
     * True when [artist] is the singer asked for: same name in any of the Arabic / Latin spellings (the phonetic
     * variants of [Translit] included). Other singers that only share a word are not shown.
     */
    private fun isSameSinger(artist: String, variants: List<String>): Boolean {
        val a = nameKey(artist)
        if (a.isEmpty()) return false
        for (v in variants) {
            val k = nameKey(v)
            if (k.length < 2) continue
            if (a == k) return true
            // "Tarkan" ~ "Tarkan Tevetoglu" : the asked name is the beginning of the full name (or the reverse)
            if (k.length >= 4 && (a.startsWith(k) || (a.length >= 4 && k.startsWith(a)))) return true
        }
        return false
    }

    private fun runSearch(raw: String) {
        val q = raw.trim()
        if (q.length < 2) return
        status.text = "جارٍ البحث…"
        val variants = Translit.variants(q)
        lifecycleScope.launch {
            val found = LinkedHashMap<Long, Artist>()
            withContext(Dispatchers.IO) {
                for (v in variants) {
                    for (cc in listOf(country(), "US")) {
                        try {
                            val arr = itunes("search?term=" + URLEncoder.encode(v, "UTF-8") + "&entity=musicArtist&limit=8&country=$cc")
                                .optJSONArray("results") ?: continue
                            for (i in 0 until arr.length()) {
                                val o = arr.optJSONObject(i) ?: continue
                                val id = o.optLong("artistId")
                                val name = o.optString("artistName")
                                if (id != 0L && !found.containsKey(id) && isSameSinger(name, variants)) found[id] = Artist(name, name, id)
                            }
                        } catch (_: Exception) {
                        }
                    }
                }
            }
            // the exact spelling of the typed name first
            val typed = nameKey(q)
            artists = found.values.sortedByDescending { if (nameKey(it.term) == typed) 1 else 0 }
            showArtists()
            status.text = if (artists.isEmpty()) "لا نتائج — جرّب كتابة الاسم بحروف لاتينية" else "${artists.size} مطرب — اختر واحداً"
        }
    }

    private fun openArtist(a: Artist) {
        currentArtist = a.term
        albumSel = -1
        status.text = "جارٍ تحميل ألبومات ${a.term}…"
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) {
                try {
                    var id = a.id
                    if (id == 0L) {
                        val arr = itunes("search?term=" + URLEncoder.encode(a.term, "UTF-8") + "&entity=musicArtist&limit=1&country=${country()}")
                            .optJSONArray("results")
                        id = arr?.optJSONObject(0)?.optLong("artistId") ?: 0L
                        if (id == 0L) {
                            val arr2 = itunes("search?term=" + URLEncoder.encode(a.term, "UTF-8") + "&entity=musicArtist&limit=1").optJSONArray("results")
                            id = arr2?.optJSONObject(0)?.optLong("artistId") ?: 0L
                        }
                    }
                    val out = ArrayList<Album>()
                    if (id != 0L) {
                        val arr = itunes("lookup?id=$id&entity=album&limit=60").optJSONArray("results")
                        if (arr != null) for (i in 0 until arr.length()) {
                            val o = arr.optJSONObject(i) ?: continue
                            if (o.optString("wrapperType") != "collection") continue
                            out.add(Album(o.optLong("collectionId"), o.optString("collectionName"), o.optString("artworkUrl100")))
                        }
                    }
                    out
                } catch (_: Exception) {
                    emptyList<Album>()
                }
            }
            albums = list
            songs = emptyList()
            showAlbums(); showSongs()
            status.text = if (list.isEmpty()) "لا توجد ألبومات متاحة لهذا المطرب" else "${list.size} ألبوم — اضغط ألبوماً لعرض أغانيه"
        }
    }

    private fun openAlbum(a: Album) {
        albumSel = albums.indexOfFirst { it.id == a.id }
        (albumList.adapter as? ArrayAdapter<*>)?.notifyDataSetChanged()
        currentAlbum = a.name
        songs = emptyList()
        showSongs()
        floatSongs?.adapter = listAdapter(emptyList())
        status.text = "جارٍ تحميل أغاني الألبوم…"
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) {
                try {
                    val arr = itunes("lookup?id=${a.id}&entity=song&limit=80").optJSONArray("results")
                    val out = ArrayList<Song>()
                    if (arr != null) for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        if (o.optString("wrapperType") != "track") continue
                        out.add(Song(o.optString("trackName"), o.optString("artistName"), a.name,
                            o.optString("previewUrl"), o.optString("artworkUrl100").replace("100x100", "600x600")))
                    }
                    out
                } catch (_: Exception) {
                    emptyList<Song>()
                }
            }
            if (albums.getOrNull(albumSel)?.id != a.id) return@launch // another album was chosen meanwhile
            songs = list
            showSongs()
            // the songs column of the floating panel shows THIS album at once
            floatSongs?.adapter = listAdapter(songs.mapIndexed { i, s -> "${i + 1}. ${s.name}" })
            status.text = "${list.size} أغنية من «${a.name}» — اضغط أغنية لتشغيلها"
        }
    }

    // ------------------------------------------------------------------ player

    private fun buildPlayer(root: FrameLayout) {
        val layer = TouchWatchLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
            isClickable = true
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        root.addView(layer, FrameLayout.LayoutParams(-1, -1))
        playerLayer = layer

        // 12 backgrounds (6 still + 6 live) / gallery picture + the shade whose opacity the user chooses
        kit = PlayerUiKit(this, "song", false, { pickImage.launch("image/*") }) { applyKit() }
        layer.addView(kit.background, FrameLayout.LayoutParams(-1, -1))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(66), dp(10), dp(16), dp(10)) }
        layer.addView(row, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        panelRow = row
        kit.bindPanel(row)
        layer.onAnyTouch = { kit.touch() }
        // an empty place of the player opens the two column panel (when the panel was hidden the touch only brings it back)
        layer.setOnClickListener { if (!kit.touch()) showFloatingLists() }
        swipe = SwipeControl(this, layer).also { sw ->
            @Suppress("ClickableViewAccessibility")
            layer.setOnTouchListener { v, e -> sw.onTouch(v, e) }
        }

        val discHolder = FrameLayout(this)
        row.addView(discHolder, LinearLayout.LayoutParams(0, -1, 1f))
        disc = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(0xFF1A1405.toInt()); setStroke(dp(5), gold)
            }
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        cover = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        disc.addView(cover, FrameLayout.LayoutParams(-1, -1))
        discHolder.addView(disc, FrameLayout.LayoutParams(dp(220), dp(220), Gravity.CENTER))
        installDrag()
        applyDiscSize()

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        row.addView(col, LinearLayout.LayoutParams(0, -1, 1.3f))
        songTitle = TextView(this).apply { textSize = 20f; setTextColor(gold); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; maxLines = 2 }
        songSub = TextView(this).apply { textSize = 13f; setTextColor(0xFFF3E9CF.toInt()); gravity = Gravity.CENTER; maxLines = 2 }
        col.addView(songTitle, LinearLayout.LayoutParams(-1, -2))
        col.addView(songSub, LinearLayout.LayoutParams(-1, -2))

        val sizes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("صغير", "وسط", "كبير", "أكبر").forEachIndexed { i, n ->
            sizes.addView(chip("◉ $n") { prefs.songDiscSize = i; applyDiscSize() }, LinearLayout.LayoutParams(-2, dp(34)).apply { setMargins(dp(3), dp(6), dp(3), dp(2)) })
        }
        col.addView(sizes)

        seek = SeekBar(this).apply {
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) { seeking = true }
                override fun onStopTrackingTouch(s: SeekBar?) {
                    seeking = false
                    try { if (prepared) exo?.seekTo((s?.progress ?: 0).toLong()) } catch (_: Throwable) {}
                }
            })
        }
        timeText = TextView(this).apply { textSize = 11f; setTextColor(0xFFB8A878.toInt()); gravity = Gravity.CENTER }
        col.addView(seek, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        col.addView(timeText)

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun round(text: String, click: () -> Unit) = TextView(this).apply {
            this.text = text; textSize = 20f; gravity = Gravity.CENTER; setTextColor(gold)
            setBackgroundResource(R.drawable.bg_control_dark); setOnClickListener { click() }
        }
        playBtn = round("▶") { togglePlay() }
        controls.addView(round("⏮") { playAt(index - 1) }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(dp(4), 0, dp(4), 0) })
        controls.addView(round("⏪") { seekBy(-10_000) }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(dp(4), 0, dp(4), 0) })
        controls.addView(playBtn, LinearLayout.LayoutParams(dp(56), dp(56)).apply { setMargins(dp(4), 0, dp(4), 0) })
        controls.addView(round("⏩") { seekBy(10_000) }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(dp(4), 0, dp(4), 0) })
        controls.addView(round("⏭") { playAt(index + 1) }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(dp(4), 0, dp(4), 0) })
        col.addView(controls, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })

        val eqRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        // real equalizer + bass boost on the audio session of the player: huge / deep bass / oriental / warm / pop / classic / normal
        val eqScroll = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(eqRow) }
        SoundFx.SONG_IDS.forEach { id ->
            val preset = SoundFx.presetById(id)
            val name = songModeName(id)
            eqRow.addView(chip(name) { applyEq(preset); toast("المعادل: $name") }, LinearLayout.LayoutParams(-2, dp(34)).apply { setMargins(dp(3), dp(6), dp(3), dp(2)) })
        }
        col.addView(eqScroll, LinearLayout.LayoutParams(-2, -2))

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actions.addView(chip("💾 حفظ في الهاتف") { downloadCurrent() }, LinearLayout.LayoutParams(-2, dp(36)).apply { setMargins(dp(3), dp(6), dp(3), dp(2)) })
        actions.addView(chip("☰ ضبط القائمة") { showListSettings() }, LinearLayout.LayoutParams(-2, dp(36)).apply { setMargins(dp(3), dp(6), dp(3), dp(2)) })
        actions.addView(chip("✕ إغلاق المشغل") { closePlayer() }, LinearLayout.LayoutParams(-2, dp(36)).apply { setMargins(dp(3), dp(6), dp(3), dp(2)) })
        col.addView(actions)

        // interface buttons inside the player itself: background, panel (size / opacity / auto-hide), spinning disc
        val ui = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        ui.addView(chip("🖼 الخلفية") { kit.showBackgroundStrip(layer) }, LinearLayout.LayoutParams(-2, dp(36)).apply { setMargins(dp(3), dp(6), dp(3), dp(2)) })
        ui.addView(chip("⚙ واجهة المشغل") { kit.showControlsDialog(false) }, LinearLayout.LayoutParams(-2, dp(36)).apply { setMargins(dp(3), dp(6), dp(3), dp(2)) })
        ui.addView(chip("❤️ مفضلة") { songs.getOrNull(index)?.let { toggleFav(it) } }, LinearLayout.LayoutParams(-2, dp(36)).apply { setMargins(dp(3), dp(6), dp(3), dp(2)) })
        ui.addView(chip("💿 الأسطوانة") { kit.discVisible = !kit.discVisible; applyKit() }, LinearLayout.LayoutParams(-2, dp(36)).apply { setMargins(dp(3), dp(6), dp(3), dp(2)) })
        col.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(ui) })
        applyKit()
        col.addView(TextView(this).apply {
            text = "الأغنية تُشغَّل كاملة داخل التطبيق (صوت مباشر عبر Piped / Invidious). المس مكاناً فارغاً لعرض القوائم."
            textSize = 10f; setTextColor(0xAAFFFFFF.toInt()); gravity = Gravity.CENTER
        })
    }

    /** Saved panel size, spinning disc visibility and auto-hide mode. */
    private fun applyKit() {
        val m = resources.displayMetrics
        val f = kit.sizeFraction()
        panelRow?.layoutParams = FrameLayout.LayoutParams((m.widthPixels * f).toInt(), (m.heightPixels * f).toInt(), Gravity.CENTER)
        if (::disc.isInitialized) disc.visibility = if (kit.discVisible) View.VISIBLE else View.INVISIBLE
        kit.touch()
    }

    private fun applyDiscSize() {
        val sizes = intArrayOf(150, 210, 270, 330)
        val s = dp(sizes[prefs.songDiscSize.coerceIn(0, 3)])
        disc.layoutParams = (disc.layoutParams as FrameLayout.LayoutParams).apply { width = s; height = s }
        disc.requestLayout()
        // the cover always fills the whole circle with the same ratio (no stretching)
    }

    private fun installDrag() {
        var dx = 0f; var dy = 0f; var tx = 0f; var ty = 0f
        disc.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; tx = disc.translationX; ty = disc.translationY; v.parent.requestDisallowInterceptTouchEvent(true); true }
                MotionEvent.ACTION_MOVE -> {
                    val w = resources.displayMetrics.widthPixels.toFloat()
                    val h = resources.displayMetrics.heightPixels.toFloat()
                    disc.translationX = (tx + e.rawX - dx).coerceIn(-w * 0.45f, w * 0.75f)
                    disc.translationY = (ty + e.rawY - dy).coerceIn(-h * 0.4f, h * 0.4f)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    prefs.songDiscX = disc.translationX / resources.displayMetrics.widthPixels
                    prefs.songDiscY = disc.translationY / resources.displayMetrics.heightPixels
                    true
                }
                else -> false
            }
        }
    }

    private fun songModeName(id: String) = when (id) {
        "cinema" -> "ضخم"
        "deep" -> "باس عميق"
        "tarab" -> "طرب شرقي"
        "warm" -> "ناعم دافئ"
        "pop" -> "بوب"
        "classic" -> "كلاسيك"
        else -> "عادي"
    }

    private fun playAt(i: Int) {
        if (songs.isEmpty()) return
        val n = (if (i < 0) songs.size - 1 else if (i >= songs.size) 0 else i)
        val s = songs[n]
        index = n
        songTitle.text = s.name
        songSub.text = s.artist + " — " + s.album
        cover.load(s.art) { transformations(CircleCropTransformation()); error(R.drawable.ic_music) }
        disc.translationX = prefs.songDiscX * resources.displayMetrics.widthPixels
        disc.translationY = prefs.songDiscY * resources.displayMetrics.heightPixels
        playerLayer?.visibility = View.VISIBLE
        playerLayer?.bringToFront()
        kit.touch()
        if (spin == null) spin = ObjectAnimator.ofFloat(disc, View.ROTATION, 0f, 360f).apply {
            duration = 12_000L; interpolator = LinearInterpolator(); repeatCount = ValueAnimator.INFINITE; start()
        }
        releasePlayer()
        currentStream = ""
        timeText.text = "جارٍ جلب الأغنية كاملة…"
        // iTunes / Deezer only supply the names and pictures: the FULL audio stream comes from Piped / Invidious
        resolveJob?.cancel()
        resolveJob = lifecycleScope.launch {
            val full = withContext(Dispatchers.IO) { SongStream.resolve(s.artist, s.name) }
            if (index != n) return@launch
            val url = full ?: s.preview.takeIf { it.isNotBlank() }
            if (url == null) {
                toast("تعذّر العثور على هذه الأغنية")
                return@launch
            }
            if (full == null) toast("تعذّر جلب الأغنية كاملة الآن — تُشغَّل المعاينة (30 ثانية)")
            currentStream = url
            startStream(url)
        }
    }

    private fun startStream(url: String) {
        try {
            val p = ExoPlayer.Builder(this)
                .setMediaSourceFactory(DefaultMediaSourceFactory(NetConfig.dataSourceFactory(this)))
                .build()
            exo = p
            prepared = false
            p.setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),
                true
            )
            p.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY && !prepared) {
                        prepared = true
                        // the real equalizer + bass boost are bound to the audio session of this player
                        try {
                            fx?.release()
                            fx = SoundFx.SessionFx(p.audioSessionId)
                            fx?.apply(currentPreset)
                        } catch (_: Throwable) {}
                    }
                    if (state == Player.STATE_ENDED) playAt(index + 1) // the next song starts by itself
                }

                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    toast("تعذّر تشغيل الأغنية")
                }
            })
            p.setMediaItem(MediaItem.fromUri(url))
            p.prepare()
            p.playWhenReady = true
        } catch (e: Throwable) {
            toast("تعذّر التشغيل: " + (e.message ?: ""))
        }
    }

    private val eqPrefs by lazy { getSharedPreferences("player_ui", MODE_PRIVATE) }
    private var currentPreset: SoundFx.Preset = SoundFx.presetById("normal")

    private fun applyEq(preset: SoundFx.Preset) {
        currentPreset = preset
        eqPrefs.edit().putString("song_eq", preset.id).apply() // the chosen sound mode is remembered
        fx?.apply(preset)
    }

    private fun togglePlay() {
        try {
            val p = exo ?: return
            if (!prepared) return
            if (p.isPlaying) p.pause() else p.play()
        } catch (_: Throwable) {}
    }

    private fun seekBy(ms: Int) {
        try {
            val p = exo ?: return
            if (prepared) p.seekTo((p.currentPosition + ms).coerceIn(0L, p.duration.coerceAtLeast(0L)))
        } catch (_: Throwable) {}
    }

    private fun closePlayer() {
        hideFloating()
        resolveJob?.cancel()
        releasePlayer()
        spin?.cancel(); spin = null
        playerLayer?.visibility = View.GONE
    }

    private fun releasePlayer() {
        try { fx?.release() } catch (_: Throwable) {}
        fx = null
        try { exo?.release() } catch (_: Throwable) {}
        exo = null
        prepared = false
    }

    /** Saves the full song to Music/OsoGoldTV through MediaStore. */
    private fun downloadCurrent() {
        val s = songs.getOrNull(index) ?: return
        toast("جارٍ الحفظ…")
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val name = (s.artist + " - " + s.name).replace(Regex("[\\\\/:*?\"<>|]"), " ").trim() + ".m4a"
                    val source = currentStream.ifBlank { s.preview }
                    val bytes = NetConfig.client().newCall(okhttp3.Request.Builder().url(source).build()).execute().use { r ->
                        if (!r.isSuccessful) return@use null
                        r.body?.bytes()
                    } ?: return@withContext false
                    if (Build.VERSION.SDK_INT >= 29) {
                        val values = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                            put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
                            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/OsoGoldTV")
                        }
                        val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
                        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    } else {
                        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "OsoGoldTV")
                        dir.mkdirs()
                        File(dir, name).writeBytes(bytes)
                    }
                    true
                } catch (_: Throwable) {
                    false
                }
            }
            toast(if (ok) "تم الحفظ في Music/OsoGoldTV" else "تعذّر الحفظ")
        }
    }

    // ------------------------------------------------------------------ transparent two column panel

    private fun showFloatingLists() {
        val layer = playerLayer ?: return
        if (floatingPanel != null) { hideFloating(); return }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setBackgroundColor(0xB0000000.toInt())
            setPadding(dp(6), dp(6), dp(6), dp(6))
            isClickable = true
        }
        fun col(title: String, list: ListView) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = title; setTextColor(gold); gravity = Gravity.CENTER; textSize = 13f })
            addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        val albumsView = listView().apply {
            adapter = listAdapter(albums.map { it.name }) { albumSel }
            setOnItemClickListener { _, _, i, _ ->
                albums.getOrNull(i)?.let {
                    openAlbum(it)
                    (adapter as? ArrayAdapter<*>)?.notifyDataSetChanged() // shade the chosen album
                }
            }
        }
        val songsView = listView().apply {
            adapter = listAdapter(songs.mapIndexed { i, s -> "${i + 1}. ${s.name}" })
            setOnItemClickListener { _, _, i, _ -> playAt(i) }
        }
        floatSongs = songsView
        panel.addView(col("أغاني الألبوم", songsView), LinearLayout.LayoutParams(0, -1, 1f).apply { marginEnd = dp(4) })
        panel.addView(col("ألبومات المطرب", albumsView), LinearLayout.LayoutParams(0, -1, 1f))
        val m = resources.displayMetrics
        val lp = FrameLayout.LayoutParams(
            (m.widthPixels * prefs.songListWidth / 100f).toInt(),
            (m.heightPixels * prefs.songListHeight / 100f).toInt(),
            (if (prefs.songListSide == 1) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL
        )
        layer.addView(panel, lp)
        floatingPanel = panel
    }

    private fun hideFloating() {
        floatingPanel?.let { (playerLayer)?.removeView(it) }
        floatingPanel = null
        floatSongs = null
    }

    /** Size and side of the transparent list, applied at once and saved. */
    private fun showListSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), 0) }
        fun slider(name: String, value: Int, min: Int, max: Int, save: (Int) -> Unit) {
            val label = TextView(this).apply { text = "$name: $value%"; setTextColor(Color.WHITE) }
            box.addView(label)
            box.addView(SeekBar(this).apply {
                this.max = max - min; progress = value - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        if (fromUser) { save(p + min); label.text = "$name: ${p + min}%"; hideFloating(); showFloatingLists() }
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }
        slider("العرض", prefs.songListWidth, 30, 95) { prefs.songListWidth = it }
        slider("الطول", prefs.songListHeight, 30, 95) { prefs.songListHeight = it }
        val sideRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        sideRow.addView(chip("القائمة يميناً") { prefs.songListSide = 0; hideFloating(); showFloatingLists() }, LinearLayout.LayoutParams(-2, dp(36)).apply { setMargins(dp(4), dp(8), dp(4), 0) })
        sideRow.addView(chip("القائمة يساراً") { prefs.songListSide = 1; hideFloating(); showFloatingLists() }, LinearLayout.LayoutParams(-2, dp(36)).apply { setMargins(dp(4), dp(8), dp(4), 0) })
        box.addView(sideRow)
        showImmersive(
            androidx.appcompat.app.AlertDialog.Builder(this, R.style.GoldDialog)
                .setTitle("ضبط القائمة الشفافة")
                .setView(box)
                .setPositiveButton("تم", null)
                .create()
        )
        hideFloating()
        showFloatingLists()
    }

    // ------------------------------------------------------------------ helpers

    private fun listView() = ListView(this).apply {
        divider = null
        isVerticalScrollBarEnabled = true
        setBackgroundColor(0x22FFFFFF)
        layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    private fun listAdapter(items: List<String>, selected: () -> Int = { -1 }) = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items) {
        override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
            val v = super.getView(position, convertView, parent) as TextView
            v.setBackgroundColor(if (position == selected()) 0x66D4AF37 else Color.TRANSPARENT) // the chosen album is shaded
            v.setTextColor(0xFFF3E9CF.toInt())
            v.textSize = 13f
            v.textDirection = View.TEXT_DIRECTION_ANY_RTL
            v.setSingleLine(false)
            v.maxLines = 2
            return v
        }
    }

    private fun chip(text: String, click: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 12f; gravity = Gravity.CENTER; setTextColor(gold)
        setPadding(dp(12), 0, dp(12), 0)
        paintChip(this, false)
        setOnClickListener { click() }
    }

    private fun paintChip(t: TextView, on: Boolean) {
        t.background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(if (on) gold else 0x33FFFFFF); setStroke(dp(1), gold) }
        t.setTextColor(if (on) 0xFF000000.toInt() else gold)
    }

    private fun fmt(ms: Int): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onStop() {
        super.onStop()
        try { exo?.pause() } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        if (::kit.isInitialized) kit.release()
        releasePlayer()
        super.onDestroy()
    }

}
