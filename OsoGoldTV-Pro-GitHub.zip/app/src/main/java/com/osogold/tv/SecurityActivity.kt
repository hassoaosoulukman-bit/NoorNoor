package com.osogold.tv

import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request

/**
 * Settings -> "الحماية والتشفير التام":
 *  - master switch + a live indicator (is the connection encrypted?)
 *  - DNS-over-HTTPS and TLS 1.3 (OkHttp, used by ExoPlayer too)
 *  - disguised identity (custom User-Agent) and AES-256 storage of the subscriptions
 *  - an encrypted SOCKS5 / HTTP proxy
 * "اختبار الاتصال" asks Cloudflare which TLS version and which IP address the request really used.
 */
class SecurityActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private lateinit var indicator: TextView
    private lateinit var master: TextView

    private val dohChips = ArrayList<TextView>()
    private val proxyChips = ArrayList<TextView>()
    private lateinit var tlsChip: TextView
    private lateinit var smartChip: TextView
    private val agentChips = ArrayList<TextView>()
    private lateinit var etHost: EditText
    private lateinit var etPort: EditText
    private lateinit var etUser: EditText
    private lateinit var etPass: EditText
    private lateinit var etAgent: EditText

    private var proxyType = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        proxyType = prefs.proxyType

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        root.addView(CosmicBackgroundView(this), FrameLayout.LayoutParams(-1, -1))
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(
            ScrollView(this).apply {
                isFillViewport = true
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(column, FrameLayout.LayoutParams(-1, -2))
            },
            FrameLayout.LayoutParams(-1, -1)
        )

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(title("الحماية والتشفير التام", 22f), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("رجوع", false) { finish() }, LinearLayout.LayoutParams(-2, dp(40)))
        column.addView(header)

        // ---------------------------------------------------------------- indicator + master switch
        indicator = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundResource(R.drawable.bg_chip)
        }
        column.addView(indicator, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        master = button("", true) {
            prefs.protectionOn = !prefs.protectionOn
            refresh()
            toast(if (prefs.protectionOn) "تم تشغيل الحماية" else "تم إيقاف الحماية")
        }
        column.addView(master, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) })

        // ---------------------------------------------------------------- A) DoH + TLS
        column.addView(section("أ)  التشفير التلقائي: DNS-over-HTTPS و TLS 1.3"))
        column.addView(label("DNS مشفّر (يخفي أسماء السيرفرات عن شركة الإنترنت ويمنع حظر الروابط عبر DNS):"))
        smartChip = chip("") {
            prefs.shieldAuto = !prefs.shieldAuto
            refresh()
        }
        column.addView(smartChip, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(4) })
        column.addView(note("⚡ التبديل التلقائي الذكي (افتراضي): يختار التطبيق الأسرع من خوادم DoH الستة ويبدّل بينها وبين بطاقات تعريف المشغل تلقائياً عند اكتشاف أي حظر أو فشل اتصال."))
        val names = listOf("إيقاف") + SmartShield.providers.map { it.name }
        for (rowStart in names.indices step 4) {
            val doh = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
            for (i in rowStart until minOf(rowStart + 4, names.size)) {
                val chip = chip(names[i]) {
                    prefs.dohProvider = i
                    refresh()
                }
                dohChips.add(chip)
                doh.addView(chip, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
            }
            column.addView(doh)
        }
        tlsChip = chip("") {
            prefs.tls13 = !prefs.tls13
            refresh()
        }
        column.addView(tlsChip, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(6) })
        column.addView(note("يُطبَّق على OkHttp وعلى ExoPlayer معاً. روابط http:// العادية لا تدعم TLS بطبيعتها؛ DNS المشفّر والبروكسي يحميانها من الحجب."))

        // ---------------------------------------------------------------- B) identity + storage
        column.addView(section("ب)  تمويه الهوية وتشفير البيانات المحفوظة"))
        etAgent = edit("User-Agent  مثال: IPTVSmartersPro", false).apply { setText(prefs.userAgent) }
        column.addView(etAgent)
        for (rowStart in SmartShield.agents.indices step 3) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
            for (i in rowStart until minOf(rowStart + 3, SmartShield.agents.size)) {
                val (label, value) = SmartShield.agents[i]
                val c = chip(label) {
                    prefs.userAgent = value
                    etAgent.setText(value)
                    refresh()
                }
                agentChips.add(c)
                row.addView(c, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
            }
            column.addView(row)
        }
        column.addView(
            button("حفظ هوية الاتصال", false) {
                val v = etAgent.text.toString().trim()
                if (v.isEmpty()) etAgent.error = "أدخل نصاً" else {
                    prefs.userAgent = v
                    toast("تم الحفظ")
                }
            },
            LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(6) }
        )
        column.addView(note("🔐 بيانات الاشتراكات (Xtream / Stalker / القوائم) والبروكسي ومفاتيح API محفوظة في الهاتف مشفّرة بـ AES-256 (Android Keystore) وتُنقل تلقائياً من النسخ القديمة."))

        // ---------------------------------------------------------------- C) proxy
        column.addView(section("ج)  بروكسي مشفّر (SOCKS5 / HTTP)"))
        val types = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        listOf("بدون", "SOCKS5", "HTTP").forEachIndexed { i, name ->
            val chip = chip(name) {
                proxyType = i
                refreshProxyChips()
            }
            proxyChips.add(chip)
            types.addView(chip, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
        }
        column.addView(types)
        etHost = edit("عنوان البروكسي  مثال: 192.168.1.5", false).apply { setText(prefs.proxyHost) }
        etPort = edit("المنفذ  مثال: 1080", false).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            if (prefs.proxyPort > 0) setText(prefs.proxyPort.toString())
        }
        etUser = edit("اسم المستخدم (اختياري)", false).apply { setText(prefs.proxyUser) }
        etPass = edit("كلمة المرور (اختياري)", true).apply { setText(prefs.proxyPass) }
        listOf(etHost, etPort, etUser, etPass).forEach { column.addView(it) }
        refreshProxyChips()

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
        actions.addView(button("حفظ", true) { saveProxy() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        actions.addView(View(this), LinearLayout.LayoutParams(dp(8), 1))
        actions.addView(button("اختبار الاتصال", false) { testConnection() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        column.addView(actions)

        setContentView(root)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        // the identity card may have been changed in Settings or by the automatic switching
        if (::etAgent.isInitialized && etAgent.text.toString() != prefs.userAgent) etAgent.setText(prefs.userAgent)
        if (::indicator.isInitialized) refresh()
    }

    // ------------------------------------------------------------------ state

    private fun refresh() {
        val on = prefs.protectionOn
        val s = NetConfig.status()
        master.text = if (on) "إيقاف الحماية" else "تشغيل الحماية"
        indicator.text = when {
            !on -> "⚠  الحماية متوقفة — الاتصال غير مشفّر"
            s.proxy && s.doh && s.tls13 -> "🔒  الاتصال مشفّر بالكامل (DoH + TLS 1.3 + بروكسي)"
            s.doh && s.tls13 -> "🔒  الاتصال مشفّر بالكامل (DoH + TLS 1.3)"
            s.doh || s.tls13 || s.proxy -> "🔓  حماية جزئية — فعّل DNS المشفّر و TLS 1.3"
            else -> "⚠  لا توجد طبقة حماية مفعّلة"
        }
        indicator.setTextColor(if (on && (s.doh || s.tls13 || s.proxy)) 0xFF7CFC9A.toInt() else 0xFFFF8A80.toInt())
        dohChips.forEachIndexed { i, chip -> mark(chip, i == prefs.dohProvider) }
        smartChip.text = "التبديل التلقائي الذكي:  " + if (prefs.shieldAuto) "مفعّل ✓" else "متوقف"
        mark(smartChip, prefs.shieldAuto)
        agentChips.forEachIndexed { i, c -> mark(c, SmartShield.agents[i].second == prefs.userAgent) }
        tlsChip.text = "TLS 1.3:  " + if (prefs.tls13) "مفعّل ✓" else "متوقف"
        mark(tlsChip, prefs.tls13)
    }

    private fun refreshProxyChips() {
        proxyChips.forEachIndexed { i, chip -> mark(chip, i == proxyType) }
    }

    private fun mark(chip: TextView, active: Boolean) {
        chip.setBackgroundResource(if (active) R.drawable.bg_chip_active else R.drawable.bg_chip)
        UiTheme.apply(chip)
    }

    private fun saveProxy() {
        val host = etHost.text.toString().trim()
        val port = etPort.text.toString().trim().toIntOrNull() ?: 0
        if (proxyType != 0) {
            if (host.isEmpty()) {
                etHost.error = "أدخل عنوان البروكسي"
                return
            }
            if (port !in 1..65535) {
                etPort.error = "منفذ غير صحيح"
                return
            }
        }
        prefs.proxyType = proxyType
        prefs.proxyHost = host
        prefs.proxyPort = port
        prefs.proxyUser = etUser.text.toString()
        prefs.proxyPass = etPass.text.toString()
        refresh()
        toast("تم الحفظ")
    }

    private fun testConnection() {
        toast("جارٍ اختبار الاتصال…")
        lifecycleScope.launch {
            val text = try {
                withContext(Dispatchers.IO) {
                    val request = Request.Builder().url("https://www.cloudflare.com/cdn-cgi/trace").build()
                    val body = NetConfig.client().newCall(request).execute().use { it.body?.string().orEmpty() }
                    val map = body.lines().filter { it.contains('=') }
                        .associate { it.substringBefore('=') to it.substringAfter('=') }
                    "عنوان IP الظاهر للإنترنت: ${map["ip"] ?: "—"}\n" +
                        "نسخة التشفير المستعملة: ${map["tls"] ?: "—"}\n" +
                        "البروكسي: " + (if (NetConfig.status().proxy) "يعمل" else "غير مفعّل") + "\n" +
                        "DNS مشفّر: " + (if (NetConfig.status().doh) "مفعّل" else "غير مفعّل")
                }
            } catch (e: Exception) {
                "فشل الاتصال: ${e.message ?: e.javaClass.simpleName}\nتحقق من إعدادات البروكسي."
            }
            val dialog = androidx.appcompat.app.AlertDialog.Builder(this@SecurityActivity, R.style.GoldDialog)
                .setTitle("نتيجة الاختبار")
                .setMessage(text)
                .setPositiveButton("حسناً", null)
                .create()
            showImmersive(dialog)
        }
    }

    // ------------------------------------------------------------------ small builders

    private fun title(text: String, size: Float) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(0xFFFFD86B.toInt())
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun section(text: String) = title(text, 16f).apply { setPadding(0, dp(18), 0, dp(4)) }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(0xFFF3E9CF.toInt())
        setPadding(0, dp(4), 0, 0)
    }

    private fun note(text: String) = TextView(this).apply {
        this.text = text
        textSize = 11f
        setTextColor(0xFFD4AF37.toInt())
        setPadding(0, dp(6), 0, 0)
    }

    private fun chip(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        gravity = Gravity.CENTER
        textSize = 14f
        setTextColor(0xFFFFD86B.toInt())
        setOnClickListener { onClick() }
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        gravity = Gravity.CENTER
        textSize = 15f
        setPadding(dp(16), 0, dp(16), 0)
        setTypeface(typeface, Typeface.BOLD)
        if (primary) {
            setBackgroundResource(R.drawable.bg_gold_button)
            setTextColor(0xFF1A1405.toInt())
        } else {
            setBackgroundResource(R.drawable.bg_chip)
            setTextColor(0xFFFFD86B.toInt())
        }
        setOnClickListener { onClick() }
    }

    private fun edit(hintText: String, password: Boolean) = EditText(this).apply {
        hint = hintText
        setTextColor(0xFFFFD86B.toInt())
        setHintTextColor(0x99D4AF37.toInt())
        setBackgroundResource(R.drawable.bg_input)
        setPadding(dp(14), dp(10), dp(14), dp(10))
        gravity = Gravity.CENTER
        maxLines = 1
        inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
