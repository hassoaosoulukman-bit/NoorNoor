package com.osogold.tv

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

/** Shares the installed APK of the app (WhatsApp, Telegram, Bluetooth ...) through a FileProvider. */
object ShareApp {

    fun share(context: Context) {
        try {
            val source = File(context.applicationInfo.sourceDir)
            val dir = File(context.cacheDir, "share").apply { mkdirs() }
            val target = File(dir, "OsoGoldTV.apk")
            source.copyTo(target, overwrite = true)
            val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", target)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "تطبيق OsoGold TV Pro")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(send, "مشاركة التطبيق").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            android.widget.Toast.makeText(context, "تعذّرت مشاركة التطبيق: ${e.message ?: e.javaClass.simpleName}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}
