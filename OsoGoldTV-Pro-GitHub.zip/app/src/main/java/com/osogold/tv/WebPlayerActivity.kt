package com.osogold.tv

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView

/** Full screen player of a YouTube video (free official movies). Back goes one step back. */
class WebPlayerActivity : BaseActivity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
        }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        val back = ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setBackgroundResource(R.drawable.bg_control_dark)
            val pad = (9 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
            setOnClickListener { finish() }
        }
        val size = (40 * resources.displayMetrics.density).toInt()
        val margin = (12 * resources.displayMetrics.density).toInt()
        root.addView(back, FrameLayout.LayoutParams(size, size).apply {
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            setMargins(margin, margin, margin, margin)
        })
        setContentView(root)

        val id = intent.getStringExtra(EXTRA_VIDEO_ID).orEmpty()
        val live = intent.getStringExtra(EXTRA_LIVE_CHANNEL).orEmpty()
        val src = if (live.isNotEmpty())
            "https://www.youtube.com/embed/live_stream?channel=$live&autoplay=1&controls=1&rel=0&playsinline=1&vq=hd2160&hl=ar"
        else
            "https://www.youtube.com/embed/$id?autoplay=1&controls=1&rel=0&playsinline=1&cc_load_policy=1&cc_lang_pref=ar&hl=ar&vq=hd2160"
        val html = """
            <html><body style="margin:0;background:#000">
            <iframe width="100%" height="100%" style="border:0;position:fixed;top:0;left:0;right:0;bottom:0"
              src="$src"
              allow="autoplay; encrypted-media; picture-in-picture" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
            </body></html>
        """.trimIndent()
        web.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onStop() {
        super.onStop()
        // no sound may stay behind when the app is left
        if (!AppState.inForeground) web.loadUrl("about:blank")
    }

    override fun onDestroy() {
        web.loadUrl("about:blank")
        web.destroy()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_VIDEO_ID = "video_id"
        const val EXTRA_LIVE_CHANNEL = "live_channel"

        /** Opens an official YouTube live channel / video in the app. [spec] = "youtube:live:<channelId>" or "youtube:<videoId>" or a youtube link. */
        fun open(context: android.content.Context, spec: String): Boolean {
            val intent = android.content.Intent(context, WebPlayerActivity::class.java)
            when {
                spec.startsWith("youtube:live:") -> intent.putExtra(EXTRA_LIVE_CHANNEL, spec.removePrefix("youtube:live:"))
                spec.startsWith("youtube:") -> intent.putExtra(EXTRA_VIDEO_ID, spec.removePrefix("youtube:"))
                else -> {
                    val id = Regex("(?:v=|youtu\\.be/|/live/|/embed/)([A-Za-z0-9_-]{11})").find(spec)?.groupValues?.get(1)
                        ?: return false
                    intent.putExtra(EXTRA_VIDEO_ID, id)
                }
            }
            context.startActivity(intent)
            return true
        }

        fun isYoutube(url: String): Boolean =
            url.startsWith("youtube:") || url.contains("youtube.com/watch") || url.contains("youtu.be/") ||
                url.contains("youtube.com/live/")
    }
}
