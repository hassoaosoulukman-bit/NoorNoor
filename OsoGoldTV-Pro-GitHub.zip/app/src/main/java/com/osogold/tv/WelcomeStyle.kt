package com.osogold.tv

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import java.io.File
import java.util.Random
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Fonts of the welcome message. Every entry is an Arabic capable system family; the last is a user file. */
object WelcomeStyle {

    val fontNames = listOf(
        "نسخ فخم", "نسخ عريض", "عصري", "عصري متوسط", "عصري مكثّف", "خفيف أنيق",
        "خط يدوي", "كاجوال", "ملف خط من الهاتف"
    )

    fun typeface(prefs: Prefs): Typeface {
        return when (prefs.welcomeFont) {
            0 -> Typeface.create("serif", Typeface.NORMAL)
            1 -> Typeface.create("serif", Typeface.BOLD)
            2 -> Typeface.create("sans-serif", Typeface.BOLD)
            3 -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
            4 -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
            5 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
            6 -> Typeface.create("cursive", Typeface.NORMAL)
            7 -> Typeface.create("casual", Typeface.NORMAL)
            else -> {
                val path = prefs.welcomeFontPath
                try {
                    if (path.isNotBlank() && File(path).exists()) Typeface.createFromFile(path)
                    else Typeface.create("serif", Typeface.BOLD)
                } catch (_: Exception) {
                    Typeface.create("serif", Typeface.BOLD)
                }
            }
        }
    }
}

/** Built-in backgrounds (drawn in code at any resolution, so they are sharp on every screen) + user pictures. */
object Backgrounds {

    val names = listOf(
        "ملكي ذهبي", "ليل ياقوتي", "زمرد", "بنفسجي ملكي", "غروب", "سماء النجوم", "زخرفة إسلامية", "شفق"
    )

    /** "" -> null, "builtin:N" -> procedural drawable, "file:<path>" -> the picture (down-sampled). */
    fun load(value: String, maxSide: Int = 2048): Drawable? {
        return when {
            value.startsWith("builtin:") -> value.removePrefix("builtin:").toIntOrNull()?.let { Procedural(it) }
            value.startsWith("file:") -> decode(File(value.removePrefix("file:")), maxSide)?.let { BitmapDrawable(null, it) }
            else -> null
        }
    }

    fun decode(file: File, maxSide: Int): Bitmap? {
        if (!file.exists()) return null
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
            BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (_: Throwable) {
            null
        }
    }

    /** Copies a picture of the gallery into the app (max 2560 px, JPEG 90) and returns "file:<path>". */
    fun importImage(context: Context, uri: Uri, prefix: String): String? {
        return try {
            val tmp = File(context.cacheDir, "import_${System.currentTimeMillis()}")
            context.contentResolver.openInputStream(uri)?.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                ?: return null
            val bitmap = decode(tmp, 2560)
            tmp.delete()
            if (bitmap == null) return null
            val target = File(context.filesDir, "${prefix}_${System.currentTimeMillis()}.jpg")
            target.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            "file:" + target.absolutePath
        } catch (_: Throwable) {
            null
        }
    }

    /** Deletes the stored picture of [value] (built-in designs have no file). */
    fun deleteFile(value: String) {
        if (value.startsWith("file:")) {
            try {
                File(value.removePrefix("file:")).delete()
            } catch (_: Exception) {
            }
        }
    }

    private class Procedural(private val kind: Int) : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (w <= 0f || h <= 0f) return
            canvas.save()
            canvas.translate(bounds.left.toFloat(), bounds.top.toFloat())
            when (kind) {
                0 -> radial(canvas, w, h, 0xFF4A3510.toInt(), 0xFF050403.toInt(), 0.9f)
                1 -> linear(canvas, w, h, 0xFF020B24.toInt(), 0xFF0B3D91.toInt(), 0xFF020617.toInt())
                2 -> radial(canvas, w, h, 0xFF0F6B45.toInt(), 0xFF02100A.toInt(), 0.85f)
                3 -> linear(canvas, w, h, 0xFF1A0733.toInt(), 0xFF5B21B6.toInt(), 0xFF0C0318.toInt())
                4 -> linear(canvas, w, h, 0xFF1B0B3A.toInt(), 0xFFE2582B.toInt(), 0xFFF6B04C.toInt())
                5 -> { linear(canvas, w, h, 0xFF010208.toInt(), 0xFF0A1236.toInt(), 0xFF000000.toInt()); stars(canvas, w, h) }
                6 -> { radial(canvas, w, h, 0xFF0B3B2E.toInt(), 0xFF03140F.toInt(), 1f); pattern(canvas, w, h) }
                else -> aurora(canvas, w, h)
            }
            canvas.restore()
        }

        private fun radial(c: Canvas, w: Float, h: Float, inner: Int, outer: Int, r: Float) {
            paint.shader = RadialGradient(w / 2, h / 2, max(w, h) * r, inner, outer, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, paint)
            paint.shader = null
        }

        private fun linear(c: Canvas, w: Float, h: Float, a: Int, b: Int, d: Int) {
            paint.shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(a, b, d), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, paint)
            paint.shader = null
        }

        private fun stars(c: Canvas, w: Float, h: Float) {
            val rnd = Random(7)
            paint.color = Color.WHITE
            repeat(260) {
                paint.alpha = 80 + rnd.nextInt(175)
                c.drawCircle(rnd.nextFloat() * w, rnd.nextFloat() * h, 0.6f + rnd.nextFloat() * 2.2f, paint)
            }
            paint.alpha = 255
        }

        /** Eight-pointed stars (rub el hizb) repeated over the screen. */
        private fun pattern(c: Canvas, w: Float, h: Float) {
            val cell = min(w, h) / 5f
            stroke.color = 0x66D4AF37
            stroke.strokeWidth = max(1.5f, cell / 40f)
            val path = Path()
            var y = cell / 2
            while (y < h + cell) {
                var x = cell / 2
                while (x < w + cell) {
                    path.reset()
                    val r = cell * 0.42f
                    for (i in 0 until 16) {
                        val radius = if (i % 2 == 0) r else r * 0.62f
                        val a = Math.PI / 8 * i
                        val px = x + (radius * cos(a)).toFloat()
                        val py = y + (radius * sin(a)).toFloat()
                        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                    }
                    path.close()
                    c.drawPath(path, stroke)
                    x += cell
                }
                y += cell
            }
        }

        private fun aurora(c: Canvas, w: Float, h: Float) {
            linear(c, w, h, 0xFF02060F.toInt(), 0xFF052C3A.toInt(), 0xFF000000.toInt())
            val colors = intArrayOf(0x5539FFB0, 0x5546A6FF, 0x55B26BFF)
            colors.forEachIndexed { i, col ->
                paint.shader = RadialGradient(w * (0.2f + 0.3f * i), h * (0.35f + 0.1f * i), w * 0.55f, col, 0x00000000, Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w, h, paint)
            }
            paint.shader = null
        }

        override fun setAlpha(alpha: Int) {}
        override fun setColorFilter(colorFilter: ColorFilter?) {}
        @Suppress("OVERRIDE_DEPRECATION")
        override fun getOpacity(): Int = PixelFormat.OPAQUE
    }
}

/** The app icon choices (activity-alias entries of the manifest). */
object AppIcons {

    val names = listOf("ذهبي ملكي", "ياقوتي", "زمردي", "بنفسجي", "ياقوت أحمر", "فضي")
    val drawables = listOf(
        R.drawable.ic_launcher_gold, R.drawable.ic_launcher_blue, R.drawable.ic_launcher_emerald,
        R.drawable.ic_launcher_purple, R.drawable.ic_launcher_ruby, R.drawable.ic_launcher_silver
    )
    private val aliases = listOf("IconGold", "IconBlue", "IconEmerald", "IconPurple", "IconRuby", "IconSilver")

    /** Enables exactly one alias, so the icon on the phone changes at once (the app is not restarted). */
    fun apply(context: Context, index: Int) {
        val pm = context.packageManager
        val namespace = SplashActivity::class.java.name.substringBeforeLast('.')
        aliases.forEachIndexed { i, name ->
            pm.setComponentEnabledSetting(
                ComponentName(context.packageName, "$namespace.alias.$name"),
                if (i == index) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        }
    }
}
