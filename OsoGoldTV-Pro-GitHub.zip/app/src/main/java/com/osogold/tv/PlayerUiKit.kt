package com.osogold.tv

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.io.File

/**
 * The interface settings of a music / Quran player that live INSIDE the player (no trip to Settings):
 *  - 12 backgrounds (6 still + 6 live) or a picture from the phone gallery (saved, can be deleted);
 *  - the panel: always visible / hides after 5 s and returns on touch;
 *  - show / hide the spinning disc (and for the Quran the verses text);
 *  - panel size in 5 levels and the opacity of the background shade (0 clear .. 100 dark).
 * Everything is saved per player ([key] = "song" or "quran").
 */
class PlayerUiKit(
    private val activity: Activity,
    private val key: String,
    private val religious: Boolean,
    /** Opens the gallery picker (the activity registers the launcher and calls [onImagePicked]). */
    private val requestPick: () -> Unit,
    /** Something changed: the player applies size / visibility again. */
    private val onChanged: () -> Unit
) {
    private val sp = activity.getSharedPreferences("player_ui", Context.MODE_PRIVATE)
    private val gold = 0xFFD4AF37.toInt()

    /** Bottom layer of the player: the scene or the picture + the dark shade whose opacity the user chooses. */
    val background = FrameLayout(activity)
    private val sceneHolder = FrameLayout(activity)
    private val shade = View(activity).apply { setBackgroundColor(Color.BLACK) }

    init {
        background.addView(sceneHolder, FrameLayout.LayoutParams(-1, -1))
        background.addView(shade, FrameLayout.LayoutParams(-1, -1))
        applyBackground()
    }

    var bgId: Int
        get() = sp.getInt("${key}_bg", -1)
        set(v) { sp.edit().putInt("${key}_bg", v).apply() }
    var sizeLevel: Int
        get() = sp.getInt("${key}_size", 3)
        set(v) { sp.edit().putInt("${key}_size", v.coerceIn(0, 4)).apply() }
    var opacity: Int
        get() = sp.getInt("${key}_opacity", 45)
        set(v) { sp.edit().putInt("${key}_opacity", v.coerceIn(0, 100)).apply() }
    var autoHide: Boolean
        get() = sp.getBoolean("${key}_autohide", false)
        set(v) { sp.edit().putBoolean("${key}_autohide", v).apply() }
    var discVisible: Boolean
        get() = sp.getBoolean("${key}_disc", true)
        set(v) { sp.edit().putBoolean("${key}_disc", v).apply() }
    var textVisible: Boolean
        get() = sp.getBoolean("${key}_text", true)
        set(v) { sp.edit().putBoolean("${key}_text", v).apply() }

    private fun customFile() = File(activity.filesDir, "bg_$key.jpg")
    fun hasCustom(): Boolean = customFile().exists()

    private fun dp(v: Int) = (v * activity.resources.displayMetrics.density).toInt()

    /** Size of the player panel as a fraction of the screen for the 5 levels. */
    fun sizeFraction(): Float = floatArrayOf(0.5f, 0.65f, 0.8f, 0.92f, 1f)[sizeLevel.coerceIn(0, 4)]

    fun applyBackground() {
        sceneHolder.removeAllViews()
        val id = bgId
        when {
            id == 100 && hasCustom() -> {
                val bmp = try { BitmapFactory.decodeFile(customFile().absolutePath) } catch (_: Throwable) { null }
                if (bmp != null) {
                    sceneHolder.addView(ImageView(activity).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(bmp) }, FrameLayout.LayoutParams(-1, -1))
                } else sceneHolder.addView(Scenes.create(activity, 0, religious), FrameLayout.LayoutParams(-1, -1))
            }
            id in 0 until Scenes.TOTAL -> sceneHolder.addView(Scenes.create(activity, id, religious), FrameLayout.LayoutParams(-1, -1))
            else -> sceneHolder.addView(Scenes.create(activity, 0, religious), FrameLayout.LayoutParams(-1, -1))
        }
        shade.alpha = opacity / 100f
    }

    /** The picture chosen in the gallery: scaled to the screen, saved inside the app and used at once. */
    fun onImagePicked(uri: Uri) {
        try {
            val dm = activity.resources.displayMetrics
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            activity.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= dm.widthPixels && bounds.outHeight / (sample * 2) >= dm.heightPixels) sample *= 2
            val bmp = activity.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return
            customFile().outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
            bgId = 100
            applyBackground()
        } catch (_: Throwable) {
        }
    }

    fun deleteCustom() {
        customFile().delete()
        if (bgId == 100) bgId = -1
        applyBackground()
    }

    private fun chip(text: String, on: Boolean = false, click: () -> Unit) = TextView(activity).apply {
        this.text = text; textSize = 12f; gravity = Gravity.CENTER
        minHeight = dp(40)
        setPadding(dp(12), 0, dp(12), 0)
        background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(if (on) gold else 0x55000000); setStroke(dp(1), gold) }
        setTextColor(if (on) Color.BLACK else gold)
        setOnClickListener { click() }
    }

    /** A small bar at the bottom of [host]: one tap switches between the 12 backgrounds; also the gallery picture. */
    fun showBackgroundStrip(host: ViewGroup) {
        hideBackgroundStrip(host)
        val names = if (religious) Scenes.quranNames else Scenes.songNames
        val strip = HorizontalScrollView(activity).apply {
            tag = "bgstrip"
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(0xCC000000.toInt())
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        strip.addView(row)
        fun add(text: String, on: Boolean, click: () -> Unit) =
            row.addView(chip(text, on) { click(); showBackgroundStrip(host) }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(4), 0, dp(4), 0) })
        names.forEachIndexed { i, n -> add((if (i < Scenes.STILL_COUNT) "🖼 " else "✨ ") + n, bgId == i) { bgId = i; applyBackground() } }
        add("📷 صورة من الاستوديو", bgId == 100) { requestPick() }
        if (hasCustom()) add("🗑 حذف الصورة", false) { deleteCustom() }
        add("↺ الافتراضي", bgId == -1) { bgId = -1; applyBackground() }
        row.addView(chip("✕") { hideBackgroundStrip(host) }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(8), 0, dp(4), 0) })
        host.addView(strip, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
    }

    fun hideBackgroundStrip(host: ViewGroup) {
        for (i in host.childCount - 1 downTo 0) if (host.getChildAt(i).tag == "bgstrip") host.removeViewAt(i)
    }

    /** Panel size (5 levels), shade opacity, auto-hide and the show / hide switches. */
    fun showControlsDialog(withText: Boolean) {
        val dialog = Dialog(activity)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_overlay)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = android.widget.ScrollView(activity).apply { addView(box) }
        fun title(t: String) = TextView(activity).apply { text = t; setTextColor(gold); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(8), 0, dp(4)) }
        box.addView(TextView(activity).apply { text = "واجهة المشغل"; setTextColor(gold); textSize = 17f; gravity = Gravity.CENTER })

        box.addView(title("ظهور لوحة المشغل"))
        val modeRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        lateinit var always: TextView
        lateinit var auto: TextView
        fun paintMode() {
            for ((v, on) in listOf(always to !autoHide, auto to autoHide)) {
                (v.background as GradientDrawable).setColor(if (on) gold else 0x55000000); v.setTextColor(if (on) Color.BLACK else gold)
            }
        }
        always = chip("ظاهر دائماً") { autoHide = false; paintMode(); onChanged() }
        auto = chip("يختفي بعد 5 ثوانٍ ويظهر باللمس") { autoHide = true; paintMode(); onChanged() }
        modeRow.addView(always, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        modeRow.addView(auto, LinearLayout.LayoutParams(0, -2, 1.6f).apply { setMargins(dp(3), 0, dp(3), 0) })
        box.addView(modeRow); paintMode()

        box.addView(title("حجم لوحة المشغل"))
        val sizeRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        val sizeChips = ArrayList<TextView>()
        listOf("أصغر", "صغير", "كبير", "أكبر", "ممتلئ").forEachIndexed { i, n ->
            val c = chip(n) { sizeLevel = i; sizeChips.forEachIndexed { k, v -> (v.background as GradientDrawable).setColor(if (k == i) gold else 0x55000000); v.setTextColor(if (k == i) Color.BLACK else gold) }; onChanged() }
            sizeChips.add(c)
            sizeRow.addView(c, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        sizeChips.forEachIndexed { k, v -> (v.background as GradientDrawable).setColor(if (k == sizeLevel) gold else 0x55000000); v.setTextColor(if (k == sizeLevel) Color.BLACK else gold) }
        box.addView(sizeRow)

        val label = TextView(activity).apply { setTextColor(Color.WHITE); textSize = 13f; text = "شفافية خلفية المشغل: ${100 - opacity}% شفاف  /  ${opacity}% داكن" }
        box.addView(title("درجة الشفافية"))
        box.addView(label)
        box.addView(SeekBar(activity).apply {
            max = 100; progress = opacity
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    opacity = p; shade.alpha = p / 100f
                    label.text = "شفافية خلفية المشغل: ${100 - p}% شفاف  /  $p% داكن"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        box.addView(title("العناصر"))
        val toggles = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        lateinit var discChip: TextView
        fun discText() = if (discVisible) "💿 إخفاء الأسطوانة الدوارة" else "💿 إظهار الأسطوانة الدوارة"
        discChip = chip(discText()) { discVisible = !discVisible; discChip.text = discText(); onChanged() }
        toggles.addView(discChip, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        if (withText) {
            lateinit var textChip: TextView
            fun textLabel() = if (textVisible) "📖 وضع الاستماع الصافي (بدون نص)" else "📖 إظهار نص القرآن والآيات"
            textChip = chip(textLabel()) { textVisible = !textVisible; textChip.text = textLabel(); onChanged() }
            toggles.addView(textChip, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        box.addView(toggles)
        box.addView(chip("تم") { dialog.dismiss() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        dialog.setContentView(scroll)
        dialog.window?.setLayout((activity.resources.displayMetrics.widthPixels * 0.9f).toInt().coerceAtMost(dp(560)), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
    }

    /** Auto-hide helper: call [touch] on every touch; the [panel] fades after 5 s when auto-hide is on. */
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var panelRef: View? = null
    private val hideRunnable = Runnable { panelRef?.animate()?.alpha(0f)?.setDuration(300)?.withEndAction { if (autoHide) panelRef?.visibility = View.INVISIBLE }?.start() }

    fun bindPanel(panel: View) { panelRef = panel; touch() }

    /** Returns true when the touch only brought the hidden panel back (the caller should not open anything else). */
    fun touch(): Boolean {
        val p = panelRef ?: return false
        handler.removeCallbacks(hideRunnable)
        val wasHidden = p.visibility != View.VISIBLE || p.alpha < 0.5f
        p.animate().cancel()
        p.visibility = View.VISIBLE
        p.alpha = 1f
        if (autoHide) handler.postDelayed(hideRunnable, 5000L)
        return wasHidden && autoHide
    }

    fun release() { handler.removeCallbacksAndMessages(null) }
}
