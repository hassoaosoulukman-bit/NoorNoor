package com.osogold.tv

import okhttp3.Request
import java.net.URLEncoder

/** Test of an API key and the shared names of the services that support reserve keys. */
object ApiKeys {

    const val TMDB = "tmdb"
    const val YOUTUBE = "youtube"
    const val AI = "ai"

    /** HTTP answers that mean "this key is finished or refused": the next reserve key is tried. */
    fun isKeyProblem(code: Int): Boolean = code == 401 || code == 403 || code == 429

    /** Checks a key against the real service. Blocking (call from a background thread). Returns null when it works. */
    fun test(service: String, key: String): String? {
        if (key.isBlank()) return "المفتاح فارغ"
        return try {
            val url: String
            val builder = Request.Builder()
            when (service) {
                TMDB -> {
                    if (key.length > 40) {
                        url = "https://api.themoviedb.org/3/configuration"
                        builder.header("Authorization", "Bearer $key")
                    } else {
                        url = "https://api.themoviedb.org/3/configuration?api_key=" + URLEncoder.encode(key, "UTF-8")
                    }
                }
                YOUTUBE -> url = "https://www.googleapis.com/youtube/v3/videos?part=id&id=dQw4w9WgXcQ&key=" +
                    URLEncoder.encode(key, "UTF-8")
                else -> {
                    url = "https://generativelanguage.googleapis.com/v1beta/models"
                    builder.header("x-goog-api-key", key)
                }
            }
            NetConfig.client().newCall(builder.url(url).build()).execute().use { r ->
                when {
                    r.isSuccessful -> null
                    r.code == 401 -> "المفتاح غير صحيح (401)"
                    r.code == 403 -> "المفتاح مرفوض أو انتهت حصته (403)"
                    r.code == 429 -> "انتهت الحصة المجانية مؤقتاً (429)"
                    r.code == 400 -> "المفتاح غير صالح (400)"
                    else -> "خطأ من الخدمة: HTTP ${r.code}"
                }
            }
        } catch (e: Exception) {
            "تعذر الاتصال: " + (e.message ?: e.javaClass.simpleName)
        }
    }
}
