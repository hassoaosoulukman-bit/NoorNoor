package com.osogold.tv

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * Up to five AI keys (Settings -> API keys -> AI). The provider is recognised from the key itself:
 * Gemini (AIza...), Groq (gsk_...), OpenRouter (sk-or-...), OpenAI (sk-...). When the free quota of one
 * key ends, the next active key is used automatically.
 */
object AiKeys {

    const val SLOTS = 5

    const val GEMINI = "gemini"
    const val GROQ = "groq"
    const val OPENROUTER = "openrouter"
    const val OPENAI = "openai"

    fun provider(key: String): String? {
        val k = key.trim()
        return when {
            k.startsWith("AIza") -> GEMINI
            k.startsWith("gsk_") -> GROQ
            k.startsWith("sk-or-") -> OPENROUTER
            k.startsWith("sk-") -> OPENAI
            else -> null
        }
    }

    fun label(provider: String?): String = when (provider) {
        GEMINI -> "Gemini"
        GROQ -> "Groq"
        OPENROUTER -> "OpenRouter"
        OPENAI -> "OpenAI"
        else -> "غير معروف"
    }

    /** key -> time (ms) until which it is skipped (its quota is finished). */
    private val coolDown = HashMap<String, Long>()

    @Synchronized
    private fun isCooling(key: String): Boolean = (coolDown[key] ?: 0L) > System.currentTimeMillis()

    @Synchronized
    private fun cool(key: String) {
        coolDown[key] = System.currentTimeMillis() + 10 * 60_000L
    }

    fun slots(prefs: Prefs): List<String> {
        val list = (0 until SLOTS).map { prefs.aiSlot(it) }
        if (list.all { it.isBlank() } && prefs.aiKey.isNotBlank()) return listOf(prefs.aiKey) + List(SLOTS - 1) { "" }
        return list
    }

    /** Active keys of the five lines (saved + marked as working), in order. */
    fun active(prefs: Prefs): List<String> {
        val s = slots(prefs)
        return s.indices.filter { s[it].isNotBlank() && prefs.aiSlotOk(it) != "0" && provider(s[it]) != null }.map { s[it] }
    }

    fun geminiKeys(prefs: Prefs): List<String> = active(prefs).filter { provider(it) == GEMINI }

    fun hasGemini(prefs: Prefs): Boolean = geminiKeys(prefs).isNotEmpty()

    fun hasAny(prefs: Prefs): Boolean = active(prefs).isNotEmpty()

    fun markKeyProblem(key: String) = cool(key)

    fun usable(keys: List<String>): List<String> {
        val fresh = keys.filter { !isCooling(it) }
        return if (fresh.isEmpty()) keys else fresh
    }

    /** Checks a key against its real service. Null = it works. Blocking. */
    fun test(key: String): String? {
        val p = provider(key) ?: return "لم يُتعرَّف على نوع المفتاح (Gemini AIza / Groq gsk_ / OpenRouter sk-or- / OpenAI sk-)"
        return try {
            val b = Request.Builder()
            when (p) {
                GEMINI -> b.url("https://generativelanguage.googleapis.com/v1beta/models").header("x-goog-api-key", key)
                GROQ -> b.url("https://api.groq.com/openai/v1/models").header("Authorization", "Bearer $key")
                OPENROUTER -> b.url("https://openrouter.ai/api/v1/auth/key").header("Authorization", "Bearer $key")
                else -> b.url("https://api.openai.com/v1/models").header("Authorization", "Bearer $key")
            }
            NetConfig.client().newCall(b.build()).execute().use { r ->
                when {
                    r.isSuccessful -> null
                    r.code == 401 -> "المفتاح غير صحيح (401)"
                    r.code == 403 -> "المفتاح مرفوض أو منتهي (403)"
                    r.code == 429 -> "انتهت الحصة (429)"
                    else -> "HTTP ${r.code}"
                }
            }
        } catch (e: Exception) {
            "تعذر الاتصال: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    /**
     * A plain text answer from the first working key (rotating through the five when a quota ends).
     * Blocking. Null when no key works.
     */
    fun complete(prefs: Prefs, prompt: String): String? {
        for (key in usable(active(prefs))) {
            val p = provider(key) ?: continue
            try {
                val text = when (p) {
                    GEMINI -> geminiText(key, prompt)
                    else -> chat(p, key, prompt)
                }
                if (!text.isNullOrBlank()) return text
            } catch (e: java.io.IOException) {
                markKeyProblem(key)
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun geminiText(key: String, prompt: String): String? {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("temperature", 0.3))
            .toString()
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent")
            .header("x-goog-api-key", key)
            .post(body.toRequestBody("application/json".toMediaType())).build()
        NetConfig.client().newCall(request).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw java.io.IOException("HTTP ${r.code}")
            val parts = JSONObject(text).optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text").orEmpty())
            return sb.toString()
        }
    }

    private fun chat(provider: String, key: String, prompt: String): String? {
        val (url, model) = when (provider) {
            GROQ -> "https://api.groq.com/openai/v1/chat/completions" to "llama-3.3-70b-versatile"
            OPENROUTER -> "https://openrouter.ai/api/v1/chat/completions" to "meta-llama/llama-3.3-70b-instruct:free"
            else -> "https://api.openai.com/v1/chat/completions" to "gpt-4o-mini"
        }
        val body = JSONObject()
            .put("model", model)
            .put("temperature", 0.3)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            .toString()
        val request = Request.Builder().url(url).header("Authorization", "Bearer $key")
            .post(body.toRequestBody("application/json".toMediaType())).build()
        NetConfig.client().newCall(request).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw java.io.IOException("HTTP ${r.code}")
            return JSONObject(text).optJSONArray("choices")?.optJSONObject(0)
                ?.optJSONObject("message")?.optString("content")
        }
    }
}
