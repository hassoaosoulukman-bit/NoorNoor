package com.osogold.tv

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin

/** Golden audio visualizer: real FFT data of the player when available, a soft animated wave otherwise. */
class GoldWaveView(context: Context) : View(context) {

    private val bars = 56
    private val levels = FloatArray(bars)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var lastReal = 0L
    var playing = false

    /** FFT bytes of android.media.audiofx.Visualizer (re, im pairs). */
    fun setFft(fft: ByteArray) {
        val pairs = fft.size / 2
        if (pairs < 4) return
        lastReal = SystemClock.uptimeMillis()
        val usable = (pairs * 0.6f).toInt().coerceAtLeast(bars)
        for (b in 0 until bars) {
            val from = 1 + b * usable / bars
            val to = (1 + (b + 1) * usable / bars).coerceAtLeast(from + 1)
            var peak = 0f
            for (k in from until to.coerceAtMost(pairs)) {
                val re = fft[2 * k].toFloat()
                val im = fft[2 * k + 1].toFloat()
                peak = maxOf(peak, hypot(re, im))
            }
            val target = (peak / 90f).coerceIn(0f, 1f)
            levels[b] = if (target > levels[b]) target else levels[b] * 0.82f + target * 0.18f
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        paint.shader = LinearGradient(0f, h.toFloat(), 0f, 0f, 0xFF8A6A1E.toInt(), 0xFFFFE08A.toInt(), Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val real = now - lastReal < 400
        val w = width.toFloat()
        val h = height.toFloat()
        val slot = w / bars
        for (i in 0 until bars) {
            if (!real) {
                val t = now / 380.0
                val synthetic = if (playing) (0.25 + 0.2 * abs(sin(t + i * 0.45)) + 0.15 * abs(sin(t * 0.63 + i * 0.9))).toFloat() else 0.04f
                levels[i] = levels[i] * 0.8f + synthetic * 0.2f
            }
            val barH = (levels[i] * h).coerceAtLeast(3f)
            rect.set(i * slot + slot * 0.2f, h - barH, (i + 1) * slot - slot * 0.2f, h)
            canvas.drawRoundRect(rect, slot * 0.3f, slot * 0.3f, paint)
        }
        postInvalidateOnAnimation()
    }
}
