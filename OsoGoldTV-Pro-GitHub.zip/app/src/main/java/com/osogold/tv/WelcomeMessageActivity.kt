package com.osogold.tv

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView

/**
 * First screen of the opening sequence:
 *     welcome message + picture (this screen, for the chosen seconds)
 *  -> welcome video (WelcomeVideoActivity)
 *  -> main screen.
 * "تخطي" is on screen all the time. When neither a message nor a picture is set this screen is skipped.
 */
class WelcomeMessageActivity : BaseActivity() {

    override val floatingBackEnabled: Boolean get() = false

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var skip: TextView
    private var remaining = 0
    private var finished = false

    private val tick = object : Runnable {
        override fun run() {
            remaining--
            if (remaining <= 0) {
                next()
            } else {
                skip.text = "تخطي  ($remaining)"
                handler.postDelayed(this, 1000L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)
        if (prefs.welcomeText.isBlank() && prefs.welcomeBg.isBlank()) {
            next()
            return
        }

        val root = FrameLayout(this).apply {
            setBackgroundColor(0xFF000000.toInt())
            layoutDirection = View.LAYOUT_DIRECTION_LTR // right / left mean the real sides of the screen
        }
        val background = Backgrounds.load(prefs.welcomeBg)
        if (background != null) {
            root.addView(
                ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setImageDrawable(background)
                },
                ViewGroup.LayoutParams(-1, -1)
            )
        } else {
            root.addView(CosmicBackgroundView(this), ViewGroup.LayoutParams(-1, -1))
        }

        val text = TextView(this).apply {
            this.text = prefs.welcomeText
            setTextColor(prefs.welcomeColor)
            textSize = prefs.welcomeSize.toFloat()
            typeface = WelcomeStyle.typeface(prefs)
            gravity = Gravity.CENTER
            setShadowLayer(12f, 0f, 2f, 0xCC000000.toInt())
            setLineSpacing(0f, 1.15f)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            val pad = (24 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
        }
        val gravity = when (prefs.welcomePos) {
            0 -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
            1 -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            2 -> Gravity.END or Gravity.CENTER_VERTICAL
            3 -> Gravity.START or Gravity.CENTER_VERTICAL
            else -> Gravity.CENTER
        }
        val maxWidth = (resources.displayMetrics.widthPixels * if (prefs.welcomePos >= 2 && prefs.welcomePos != 4) 0.45f else 0.9f).toInt()
        text.maxWidth = maxWidth
        root.addView(text, FrameLayout.LayoutParams(-2, -2).apply { this.gravity = gravity })

        skip = TextView(this).apply {
            setBackgroundResource(R.drawable.bg_skip)
            setTextColor(getColor(R.color.gold_light))
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            this.gravity = Gravity.CENTER
            minWidth = (96 * resources.displayMetrics.density).toInt()
            val h = (20 * resources.displayMetrics.density).toInt()
            setPadding(h, 0, h, 0)
            isClickable = true
            isFocusable = true
            setOnClickListener { next() }
        }
        val margin = (16 * resources.displayMetrics.density).toInt()
        root.addView(
            skip,
            FrameLayout.LayoutParams(-2, (40 * resources.displayMetrics.density).toInt()).apply {
                this.gravity = Gravity.TOP or Gravity.END
                setMargins(margin, margin, margin, margin)
            }
        )
        setContentView(root)

        remaining = prefs.welcomeSeconds
        skip.text = "تخطي  ($remaining)"
        handler.postDelayed(tick, 1000L)
    }

    override fun onBackPressed() {
        next()
    }

    private fun next() {
        if (finished) return
        finished = true
        handler.removeCallbacksAndMessages(null)
        startActivity(Intent(this, WelcomeVideoActivity::class.java))
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
