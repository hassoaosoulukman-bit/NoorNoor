package com.osogold.tv

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Finds the FULL song as a direct audio stream (no 30 second preview, no YouTube page).
 *
 * iTunes / Deezer only give the singer, the cover, the album and the title. For the sound itself the open
 * Piped and Invidious APIs are asked (several public servers, the first one that answers wins and is
 * remembered): search the song, then read the direct audio stream address that Media3 plays from start to end.
 * All calls are blocking: use Dispatchers.IO.
 */
object SongStream {

    private val piped = listOf(
        "https://pipedapi.kavin.rocks",
        "https://pipedapi.adminforge.de",
        "https://api.piped.private.coffee",
        "https://pipedapi.r4fo.com",
        "https://pipedapi.leptons.xyz"
    )
    private val invidious = listOf(
        "https://inv.nadeko.net",
        "https://yewtu.be",
        "https://invidious.nerdvpn.de",
        "https://invidious.privacyredirect.com",
        "https://inv.tux.pizza"
    )

    private val cache = HashMap<String, String>()

    /** Direct audio address of "[artist] [title]" or null when no server could provide it. */
    fun resolve(artist: String, title: String): String? {
        val key = "$artist|$title"
        synchronized(cache) { cache[key]?.let { return it } }
        val query = "$artist $title".trim()
        val url = fromPiped(query) ?: fromInvidious(query)
        if (url != null) synchronized(cache) { cache[key] = url }
        return url
    }

    private fun get(url: String): String = NetConfig.getText(url)

    private fun fromPiped(query: String): String? {
        val q = URLEncoder.encode(query, "UTF-8")
        for (base in piped) {
            try {
                var videoId: String? = null
                for (filter in listOf("music_songs", "videos")) {
                    val items = JSONObject(get("$base/search?q=$q&filter=$filter")).optJSONArray("items") ?: continue
                    videoId = firstVideoId(items)
                    if (videoId != null) break
                }
                if (videoId == null) continue
                val streams = JSONObject(get("$base/streams/$videoId")).optJSONArray("audioStreams") ?: continue
                best(streams, "url", "bitrate", "mimeType")?.let { return it }
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun firstVideoId(items: JSONArray): String? {
        for (i in 0 until items.length()) {
            val o = items.optJSONObject(i) ?: continue
            val u = o.optString("url")
            val duration = o.optLong("duration", 0L)
            if (!u.contains("watch?v=")) continue
            if (duration in 1..45) continue // a short clip / preview, not the song
            return u.substringAfter("watch?v=").substringBefore('&')
        }
        return null
    }

    private fun fromInvidious(query: String): String? {
        val q = URLEncoder.encode(query, "UTF-8")
        for (base in invidious) {
            try {
                val results = JSONArray(get("$base/api/v1/search?q=$q&type=video"))
                var id: String? = null
                for (i in 0 until results.length()) {
                    val o = results.optJSONObject(i) ?: continue
                    if (o.optLong("lengthSeconds", 0L) in 1..45) continue
                    id = o.optString("videoId").ifBlank { null }
                    if (id != null) break
                }
                if (id == null) continue
                val formats = JSONObject(get("$base/api/v1/videos/$id")).optJSONArray("adaptiveFormats") ?: continue
                val audio = JSONArray()
                for (i in 0 until formats.length()) {
                    val f = formats.optJSONObject(i) ?: continue
                    if (f.optString("type").startsWith("audio/")) {
                        audio.put(JSONObject().put("url", f.optString("url")).put("bitrate", f.optString("bitrate").toLongOrNull() ?: 0L)
                            .put("mimeType", f.optString("type")))
                    }
                }
                best(audio, "url", "bitrate", "mimeType")?.let { return it }
            } catch (_: Exception) {
            }
        }
        return null
    }

    /** The best audio stream: m4a / AAC first (plays everywhere), then the highest bitrate. */
    private fun best(list: JSONArray, urlKey: String, bitrateKey: String, mimeKey: String): String? {
        var bestUrl: String? = null
        var bestScore = -1L
        for (i in 0 until list.length()) {
            val o = list.optJSONObject(i) ?: continue
            val url = o.optString(urlKey)
            if (!url.startsWith("http")) continue
            val mime = o.optString(mimeKey)
            val bitrate = o.optLong(bitrateKey, 0L)
            val score = bitrate + if (mime.contains("mp4") || mime.contains("m4a") || mime.contains("aac")) 1_000_000L else 0L
            if (score > bestScore) {
                bestScore = score
                bestUrl = url
            }
        }
        return bestUrl
    }

    // ------------------------------------------------------------------ video (movie trailers)

    private val videoCache = HashMap<String, String>()

    /**
     * Direct playable address (video + sound) of a YouTube [videoId] through Piped / Invidious, for
     * the movie trailer: Media3 plays it inside the app, so no YouTube page / WebView (error 152-4).
     * Null when no server answered. Blocking: use Dispatchers.IO.
     */
    fun resolveVideo(videoId: String): String? {
        synchronized(videoCache) { videoCache[videoId]?.let { return it } }
        val url = videoFromPiped(videoId) ?: videoFromInvidious(videoId)
        if (url != null) synchronized(videoCache) { videoCache[videoId] = url }
        return url
    }

    private fun videoFromPiped(id: String): String? {
        for (base in piped) {
            try {
                val o = JSONObject(get("$base/streams/$id"))
                val streams = o.optJSONArray("videoStreams")
                var bestUrl: String? = null
                var bestH = -1
                if (streams != null) for (i in 0 until streams.length()) {
                    val v = streams.optJSONObject(i) ?: continue
                    if (v.optBoolean("videoOnly", false)) continue // needs a separate audio track
                    val u = v.optString("url")
                    if (!u.startsWith("http")) continue
                    val h = v.optInt("height", 0).takeIf { it > 0 } ?: v.optString("quality").filter { c -> c.isDigit() }.take(4).toIntOrNull() ?: 0
                    val score = if (h in 1..1080) h else 0
                    if (score > bestH) { bestH = score; bestUrl = u }
                }
                if (bestUrl != null) return bestUrl
                val hls = o.optString("hls")
                if (hls.startsWith("http")) return hls
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun videoFromInvidious(id: String): String? {
        for (base in invidious) {
            try {
                val o = JSONObject(get("$base/api/v1/videos/$id"))
                val formats = o.optJSONArray("formatStreams") ?: continue // muxed (video + audio) streams
                var bestUrl: String? = null
                var bestH = -1
                for (i in 0 until formats.length()) {
                    val f = formats.optJSONObject(i) ?: continue
                    val u = f.optString("url")
                    if (!u.startsWith("http")) continue
                    val h = f.optString("size").substringAfter('x', "").toIntOrNull()
                        ?: f.optString("qualityLabel").filter { c -> c.isDigit() }.take(4).toIntOrNull() ?: 0
                    if (h > bestH) { bestH = h; bestUrl = u }
                }
                if (bestUrl != null) return bestUrl
            } catch (_: Exception) {
            }
        }
        return null
    }

    /** Subtitle tracks (language code -> address) of a video, from Piped, then Invidious. Blocking. */
    fun subtitles(videoId: String): List<Pair<String, String>> {
        for (base in piped) {
            try {
                val arr = JSONObject(get("$base/streams/$videoId")).optJSONArray("subtitles") ?: continue
                val out = ArrayList<Pair<String, String>>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val u = o.optString("url")
                    if (u.startsWith("http")) out.add(o.optString("code") to u)
                }
                if (out.isNotEmpty()) return out
            } catch (_: Exception) {
            }
        }
        for (base in invidious) {
            try {
                val arr = JSONObject(get("$base/api/v1/captions/$videoId")).optJSONArray("captions") ?: continue
                val out = ArrayList<Pair<String, String>>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val u = o.optString("url")
                    if (u.isNotBlank()) out.add(o.optString("language_code") to (if (u.startsWith("http")) u else base + u))
                }
                if (out.isNotEmpty()) return out
            } catch (_: Exception) {
            }
        }
        return emptyList()
    }

    fun fetchText(url: String): String? = try { get(url) } catch (_: Exception) { null }
}
