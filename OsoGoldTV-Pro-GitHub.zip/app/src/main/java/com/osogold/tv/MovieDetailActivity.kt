package com.osogold.tv

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import coil.load
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * One full screen page for a movie or a series: the full poster (blurred cinematic background for a
 * series), the trailer button (played inside the app through Piped / Media3, never a YouTube WebView),
 * the name, the story, "Play", "Add to favourites" and the watched eye.
 *
 * The information comes from TMDB (Arabic story, poster, rating, trailer) when the TMDB key was added
 * in Settings, completed by the provider (Xtream). "Play" first checks that the title really plays in
 * the current subscription; when it does not it searches the other saved lists and then the free open
 * sources (Archive.org, official YouTube channels). In a series every watched episode gets a small
 * check icon and the second where the user stopped is remembered ("continue watching").
 */
class MovieDetailActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private lateinit var poster: ImageView
    private lateinit var scrim: View
    private lateinit var panel: View
    private lateinit var btnFav: TextView
    private lateinit var btnEpisodes: TextView
    private lateinit var btnPlay: TextView
    private lateinit var btnTrailer: TextView
    private lateinit var btnWatched: TextView
    private lateinit var status: TextView

    private lateinit var base: Channel
    private var detail = MovieDetail()
    private var infoShown = true
    private var isSeries = false
    private var playJob: Job? = null

    /** Episodes from another list (found by the search) replace the ones of the provider. */
    private var episodes: List<Channel> = emptyList()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_detail)
        prefs = Prefs(this)

        base = Channel(
            name = intent.getStringExtra(EXTRA_NAME).orEmpty(),
            url = intent.getStringExtra(EXTRA_URL).orEmpty(),
            logo = intent.getStringExtra(EXTRA_LOGO).orEmpty(),
            seriesId = intent.getStringExtra(EXTRA_SERIES_ID).orEmpty(),
            infoId = intent.getStringExtra(EXTRA_INFO_ID).orEmpty()
        )
        isSeries = base.seriesId.isNotEmpty() || intent.getStringExtra(EXTRA_KIND) == "series"

        poster = findViewById(R.id.detailPoster)
        scrim = findViewById(R.id.detailScrim)
        panel = findViewById(R.id.infoPanel)
        btnFav = findViewById(R.id.btnDetailFav)
        btnEpisodes = findViewById(R.id.btnDetailEpisodes)
        btnPlay = findViewById(R.id.btnDetailPlay)
        status = findViewById(R.id.detailStatus)
        btnTrailer = findViewById(R.id.btnDetailTrailer)
        btnWatched = findViewById(R.id.btnDetailWatched)

        findViewById<View>(R.id.btnDetailBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnToggleInfo).setOnClickListener {
            infoShown = !infoShown
            panel.visibility = if (infoShown) View.VISIBLE else View.GONE
        }
        btnPlay.setOnClickListener { play() }
        btnFav.setOnClickListener { toggleFavorite() }
        btnEpisodes.setOnClickListener { showEpisodes() }
        btnTrailer.setOnClickListener { playTrailer() }
        btnWatched.setOnClickListener {
            prefs.setWatched(base.url, !prefs.isWatched(base.url))
            updateWatchedButton()
        }
        // a series has its watched marks on every episode, so the page-level eye is only for films
        if (isSeries) btnWatched.visibility = View.GONE

        findViewById<TextView>(R.id.detailTitle).text = base.name
        if (base.logo.isNotBlank()) showPicture(base.logo.trim())
        updateFavoriteButton()
        updateWatchedButton()
        loadDetail()
    }

    override fun onResume() {
        super.onResume()
        updateWatchedButton()
        if (episodes.isNotEmpty() || !isSeries) updatePlayButton()
    }

    override fun onStop() {
        super.onStop()
        // the trailer must not keep playing after the page was left
        trailerDialog?.dismiss()
    }

    override fun onDestroy() {
        trailerDialog?.dismiss()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ pictures

    private var shownPicture = ""

    /**
     * Full high resolution picture. A series gets a blurred, darkened copy as its cinematic background
     * (real blur on Android 12+, a tiny up-scaled copy on older versions, which looks blurred too).
     */
    private fun showPicture(url: String) {
        if (url.isBlank() || url == shownPicture) return
        shownPicture = url
        if (isSeries) {
            if (Build.VERSION.SDK_INT >= 31) {
                poster.setRenderEffect(RenderEffect.createBlurEffect(26f, 26f, Shader.TileMode.CLAMP))
                poster.load(url)
            } else {
                poster.load(url) { size(48, 72) }
            }
            poster.alpha = 0.6f
        } else {
            poster.load(url)
            poster.alpha = 1f
        }
    }

    private fun bestPicture(): String {
        val landscape = resources.displayMetrics.widthPixels > resources.displayMetrics.heightPixels
        val first = if (landscape) detail.backdrop.ifBlank { detail.poster } else detail.poster.ifBlank { detail.backdrop }
        return first.trim()
    }

    // ------------------------------------------------------------------ data

    private fun loadDetail() {
        lifecycleScope.launch {
            val provider = try {
                withContext(Dispatchers.IO) {
                    when {
                        base.seriesId.isNotEmpty() && prefs.xtreamConfigured() ->
                            XtreamClient.seriesDetail(prefs, base.seriesId)
                        base.infoId.isNotEmpty() && prefs.xtreamConfigured() ->
                            XtreamClient.vodDetail(prefs, base.infoId)
                        else -> MovieDetail()
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                MovieDetail()
            }
            // show what the provider has right away, then improve it with TMDB
            detail = provider
            episodes = provider.episodes
            show()

            if (TmdbClient.configured(prefs)) {
                val tmdb = try {
                    withContext(Dispatchers.IO) { TmdbClient.detail(prefs, base.name, isSeries) }
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    null
                }
                if (tmdb != null) {
                    detail = merge(provider, tmdb)
                    show()
                }
            }
        }
    }

    private fun hasArabic(text: String) = text.any { it in '؀'..'ۿ' }

    private fun merge(provider: MovieDetail, tmdb: MovieDetail): MovieDetail {
        // the Arabic story wins; an English TMDB story is only used when the provider has nothing Arabic
        val plot = when {
            tmdb.plot.isBlank() -> provider.plot
            hasArabic(tmdb.plot) || !hasArabic(provider.plot) -> tmdb.plot
            else -> provider.plot
        }
        return MovieDetail(
            title = tmdb.title.ifBlank { provider.title },
            plot = plot,
            trailerId = tmdb.trailerId.ifBlank { provider.trailerId },
            poster = tmdb.poster.ifBlank { provider.poster },
            backdrop = tmdb.backdrop,
            genre = tmdb.genre.ifBlank { provider.genre },
            year = tmdb.year.ifBlank { provider.year },
            rating = tmdb.rating.ifBlank { provider.rating },
            episodes = provider.episodes
        )
    }

    private fun show() {
        findViewById<TextView>(R.id.detailTitle).text = detail.title.ifBlank { base.name }
        val meta = listOf(detail.year, detail.genre, if (detail.rating.isNotBlank()) "★ ${detail.rating}" else "")
            .filter { it.isNotBlank() }.joinToString("   •   ")
        findViewById<TextView>(R.id.detailMeta).text = meta
        findViewById<TextView>(R.id.detailPlot).text =
            detail.plot.ifBlank { "لا يتوفر شرح للقصة لهذا العمل." }
        bestPicture().takeIf { it.isNotBlank() }?.let { showPicture(it) }
        updateWatchedButton()
        // the trailer starts by itself when the page opens (TMDB id -> Piped / Invidious stream -> Media3)
        if (!autoTrailerStarted && detail.trailerId.isNotBlank()) {
            autoTrailerStarted = true
            playTrailer()
        }

        if (isSeries && episodes.isNotEmpty()) {
            btnEpisodes.visibility = View.VISIBLE
            findViewById<View>(R.id.spaceEpisodes).visibility = View.VISIBLE
            updatePlayButton()
        }

    }

    private fun updateWatchedButton() {
        if (isSeries) return
        val watched = prefs.isWatched(base.url)
        btnWatched.text = if (watched) "👁 تمت المشاهدة ✓" else "👁 تمت المشاهدة"
        btnWatched.setBackgroundResource(if (watched) R.drawable.bg_chip_active else R.drawable.bg_chip)
    }

    // ------------------------------------------------------------------ trailer

    private var trailerDialog: android.app.Dialog? = null
    private var trailerPlayer: ExoPlayer? = null
    private var trailerJob: Job? = null
    private var autoTrailerStarted = false

    /**
     * The trailer id comes from TMDB; the picture and the sound come from Piped / Invidious and play in
     * Media3 inside the app. When no server answers the trailer opens in the YouTube app / browser,
     * without any error message.
     */
    private fun playTrailer() {
        val id = detail.trailerId
        if (id.isBlank()) {
            openTrailerExternally("")
            return
        }
        trailerJob?.cancel()
        trailerJob = lifecycleScope.launch {
            setStatus("جارٍ تحميل الإعلان الترويجي…")
            val url = try {
                withContext(Dispatchers.IO) { SongStream.resolveVideo(id) }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                null
            }
            setStatus(null)
            if (url == null) openTrailerExternally(id) else showTrailerPlayer(url, id)
        }
    }

    private fun showTrailerPlayer(url: String, id: String) {
        trailerDialog?.dismiss()
        val dialog = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val view = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        }
        frame.addView(view, FrameLayout.LayoutParams(-1, -1))
        val back = ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setBackgroundResource(R.drawable.bg_control_dark)
            setPadding(dp(11), dp(11), dp(11), dp(11))
            contentDescription = getString(R.string.back)
            isFocusable = true
            setOnClickListener { dialog.dismiss() }
        }
        frame.addView(back, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.START).apply { setMargins(dp(14), dp(16), 0, 0) })
        val skip = TextView(this).apply {
            text = "تخطي الإعلان ⏭"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            setBackgroundResource(R.drawable.bg_gold_button)
            minHeight = dp(48)
            setPadding(dp(18), dp(8), dp(18), dp(8))
            isFocusable = true
            setOnClickListener { dialog.dismiss() }
        }
        frame.addView(skip, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(18), dp(70)) })
        dialog.setContentView(frame)
        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(NetConfig.dataSourceFactory(this)))
            .build()
        trailerPlayer = player
        view.player = player
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                // the stream failed: fall back to the external app, quietly
                dialog.dismiss()
                openTrailerExternally(id)
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) dialog.dismiss()
            }
        })
        dialog.setOnDismissListener {
            try { player.release() } catch (_: Throwable) {}
            if (trailerPlayer === player) trailerPlayer = null
            if (trailerDialog === dialog) trailerDialog = null
        }
        trailerDialog = dialog
        dialog.show()
        player.setMediaItem(MediaItem.fromUri(url))
        player.prepare()
        player.playWhenReady = true
        loadArabicSubtitle(player, url, id)
    }

    /**
     * Arabic subtitles for the trailer: the Arabic track of the video when it has one; otherwise the first track
     * (English preferred) is translated to Arabic by the AI keys (Groq / Gemini) and attached.
     */
    private fun loadArabicSubtitle(player: ExoPlayer, url: String, id: String) {
        lifecycleScope.launch {
            val file = withContext(Dispatchers.IO) {
                try {
                    val tracks = SongStream.subtitles(id)
                    val ar = tracks.firstOrNull { it.first.startsWith("ar", true) }
                    val pick = ar ?: tracks.firstOrNull { it.first.startsWith("en", true) } ?: tracks.firstOrNull()
                        ?: return@withContext null
                    val vtt = SongStream.fetchText(pick.second) ?: return@withContext null
                    val out = java.io.File(cacheDir, "trailer_ar.vtt")
                    if (ar != null) { out.writeText(vtt); out } else translateVtt(vtt, out)
                } catch (_: Throwable) { null }
            } ?: return@launch
            if (trailerPlayer !== player) return@launch
            try {
                val sub = MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(file))
                    .setMimeType(androidx.media3.common.MimeTypes.TEXT_VTT)
                    .setLanguage("ar")
                    .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                    .build()
                val pos = player.currentPosition
                player.setMediaItem(MediaItem.Builder().setUri(url).setSubtitleConfigurations(listOf(sub)).build(), pos)
                player.prepare()
                player.playWhenReady = true
            } catch (_: Throwable) {
            }
        }
    }

    /** Translates the cues of a WebVTT text to Arabic with the user's AI keys; null when there is no key / no answer. */
    private fun translateVtt(vtt: String, out: java.io.File): java.io.File? {
        val cue = Regex("(\\d{1,2}:)?\\d{2}:\\d{2}\\.\\d{3}\\s*-->\\s*(\\d{1,2}:)?\\d{2}:\\d{2}\\.\\d{3}[^\\n]*\\n((?:.+\\n?)+)")
        val cues = cue.findAll(vtt.replace("\r", "")).take(90).toList()
        if (cues.isEmpty()) return null
        val numbered = cues.mapIndexed { i, m -> "${i + 1}|" + m.groupValues[3].replace(Regex("<[^>]+>"), "").replace("\n", " ").trim() }
        val prompt = "ترجم الأسطر المرقمة التالية (ترجمة فيديو ترويجي لفيلم) إلى العربية الفصحى البسيطة. " +
            "أعد نفس الترقيم بالشكل رقم|النص فقط وسطراً بسطر دون أي شرح:\n" + numbered.joinToString("\n")
        val answer = AiKeys.complete(prefs, prompt) ?: return null
        val map = HashMap<Int, String>()
        for (line in answer.lines()) {
            val k = line.substringBefore('|', "").trim().toIntOrNull() ?: continue
            map[k] = line.substringAfter('|').trim()
        }
        if (map.isEmpty()) return null
        val sb = StringBuilder("WEBVTT\n\n")
        cues.forEachIndexed { i, m ->
            val text = map[i + 1] ?: return@forEachIndexed
            sb.append(m.value.substringBefore('\n').trim()).append('\n').append(text).append("\n\n")
        }
        out.writeText(sb.toString())
        return out
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun openTrailerExternally(id: String) {
        val intents = ArrayList<Intent>()
        if (id.isNotBlank()) {
            intents.add(Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$id")))
            intents.add(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$id")))
        } else {
            val query = Uri.encode((detail.title.ifBlank { base.name }) + " trailer اعلان رسمي")
            intents.add(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$query")))
        }
        for (i in intents) {
            try {
                startActivity(i)
                return
            } catch (_: Exception) {
            }
        }
        // nothing could open it: no message, the page simply stays as it is
    }

    // ------------------------------------------------------------------ continue watching

    /** The episode "Play" should start: the one in progress, else the first not watched, else the first. */
    private fun nextEpisode(): Channel? {
        val list = episodes
        if (list.isEmpty()) return null
        return list.lastOrNull { prefs.resumePosition(it.url) > 0L }
            ?: list.firstOrNull { !prefs.isWatched(it.url) }
            ?: list.first()
    }

    private fun updatePlayButton() {
        if (!isSeries) {
            if (prefs.resumePosition(base.url) > 0L) btnPlay.text = "▶  استكمال المشاهدة"
            return
        }
        val next = nextEpisode() ?: return
        btnPlay.text = if (prefs.resumePosition(next.url) > 0L) "▶  استكمال: ${next.name.substringBefore(" —")}"
        else if (prefs.isWatched(episodes.first().url)) "▶  الحلقة التالية: ${next.name.substringBefore(" —")}"
        else getString(R.string.play_now)
    }

    private fun clock(ms: Long): String {
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
    }

    // ------------------------------------------------------------------ buttons

    private fun play() {
        if (isSeries) {
            val next = nextEpisode()
            if (next == null) {
                // the provider gave no episodes: look in the other lists and the open sources
                launchPlayback(base, 0L)
                return
            }
            startItem(next)
        } else {
            startItem(base)
        }
    }

    /**
     * Smart Resume: when a second is saved for this film / episode it starts from that exact moment by
     * itself (a short note tells where). Nothing is asked.
     */
    private fun startItem(channel: Channel) {
        val saved = prefs.resumePosition(channel.url)
        if (saved >= 10_000L && !prefs.isWatched(channel.url)) {
            toast("استكمال المشاهدة من ${clock(saved)}")
            launchPlayback(channel, saved)
        } else {
            launchPlayback(channel, 0L)
        }
    }

    private fun setStatus(text: String?) {
        status.visibility = if (text.isNullOrBlank()) View.GONE else View.VISIBLE
        status.text = text.orEmpty()
    }

    /**
     * Plays [channel]. When it does not answer in the current subscription the other saved lists are
     * searched, then Archive.org and the official YouTube channels, so the work still plays full screen.
     */
    private fun launchPlayback(channel: Channel, startMs: Long) {
        playJob?.cancel()
        playJob = lifecycleScope.launch {
            btnPlay.isEnabled = false
            try {
                setStatus("جارٍ التحقق من توفر العمل في اشتراكك…")
                val available = withContext(Dispatchers.IO) {
                    val resolved = try {
                        Catalog.resolve(prefs, channel)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Exception) {
                        ""
                    }
                    resolved.isNotBlank() && (!resolved.startsWith("http", true) || NetConfig.isReachable(resolved))
                }
                if (available) {
                    setStatus(null)
                    startPlayer(channel.url, titleOf(channel), startMs, progressKey = channel.url)
                    return@launch
                }

                setStatus("غير متوفر في اشتراكك الحالي — جارٍ البحث في قوائمك المحفوظة…")
                val query = base.name
                var found = OpenSources.inUserLists(prefs, query, isSeries, base.url)
                if (found == null) {
                    setStatus("جارٍ البحث في المصادر المفتوحة (Archive.org)…")
                    found = OpenSources.inArchive(query, detail.title)
                }
                if (found == null) {
                    setStatus("جارٍ البحث في القنوات الرسمية على يوتيوب…")
                    found = OpenSources.onYoutube(prefs, detail.title.ifBlank { query })
                }
                val result = found
                if (result == null) {
                    setStatus(null)
                    val hint = if (prefs.youtubeKey.isBlank())
                        "\n\nلتفعيل البحث في يوتيوب أضف مفتاح YouTube Data API من الإعدادات ← إضافة مفتاح API."
                    else ""
                    showMessage("غير متوفر", "لم يُعثر على هذا العمل في اشتراكك ولا في قوائمك ولا في المصادر المجانية الرسمية.$hint")
                } else if (result.youtubeId.isNotBlank()) {
                    setStatus("تم العثور عليه: ${result.source}")
                    startActivity(
                        Intent(this@MovieDetailActivity, WebPlayerActivity::class.java)
                            .putExtra(WebPlayerActivity.EXTRA_VIDEO_ID, result.youtubeId)
                    )
                } else {
                    setStatus("تم العثور عليه في: ${result.source}")
                    val target = if (isSeries) {
                        // the same episode when the other list has it, otherwise its first one
                        result.channels.firstOrNull { it.name.contains(channel.name.substringBefore(" —"), true) }
                            ?: result.channels.first()
                    } else {
                        result.channels.first()
                    }
                    if (isSeries && episodes.isEmpty() && result.channels.size > 1) episodes = result.channels
                    // the watched mark / saved second stay on the original episode
                    startPlayer(target.url, titleOf(channel), startMs, progressKey = channel.url)
                }
            } finally {
                btnPlay.isEnabled = true
            }
        }
    }

    private fun titleOf(channel: Channel): String =
        if (channel === base || channel.url == base.url) detail.title.ifBlank { base.name }
        else detail.title.ifBlank { base.name } + " — " + channel.name

    private fun showMessage(title: String, message: String) {
        val dialog = AlertDialog.Builder(this, R.style.GoldDialog)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("حسناً", null)
            .create()
        showImmersive(dialog)
    }

    private fun startPlayer(url: String, name: String, startMs: Long, progressKey: String) {
        // when the player is closed with "back" the user returns to this page (movies list -> this page)
        val moviesIntent = Intent(this, MoviesActivity::class.java)
            .putExtra(MoviesActivity.EXTRA_KIND, if (isSeries) "series" else "movies")
        val detailIntent = Intent(this, MovieDetailActivity::class.java).putExtras(intent)
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(MainActivity.EXTRA_PLAY_URL, url)
                .putExtra(MainActivity.EXTRA_PLAY_NAME, name)
                .putExtra(MainActivity.EXTRA_PLAY_LOGO, base.logo)
                .putExtra(MainActivity.EXTRA_PLAY_START, startMs)
                .putExtra(MainActivity.EXTRA_PROGRESS_KEY, progressKey)
                .putExtra(MainActivity.EXTRA_RETURN_MOVIES, moviesIntent)
                .putExtra(MainActivity.EXTRA_RETURN_DETAIL, detailIntent)
        )
        finish()
    }

    // ------------------------------------------------------------------ episodes (cinematic page)

    private fun durationOf(ep: Channel): String {
        val secs = ep.infoId.removePrefix("dur:").toLongOrNull() ?: return ""
        val min = (secs / 60).toInt()
        return if (min >= 60) "⏱ ${min / 60} س ${min % 60} د" else "⏱ $min د"
    }

    private fun seasonNames(): List<String> = episodes.map { it.group }.distinct()

    /**
     * Full screen page: the blurred poster as the background, elegant season cards on the top and the
     * episodes of the chosen season below (picture, length, the saved second and the watched eye).
     */
    private fun showEpisodes() {
        val seasons = seasonNames()
        if (seasons.isEmpty()) return
        val dialog = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialogRef = dialog
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0.5f }
        val bgUrl = (detail.poster.ifBlank { detail.backdrop }.ifBlank { base.logo }).trim()
        if (bgUrl.isNotBlank()) {
            if (Build.VERSION.SDK_INT >= 31) {
                bg.setRenderEffect(RenderEffect.createBlurEffect(30f, 30f, Shader.TileMode.CLAMP))
                bg.load(bgUrl)
            } else {
                bg.load(bgUrl) { size(48, 72) }
            }
        }
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))
        root.addView(View(this).apply { setBackgroundResource(R.drawable.bg_scrim) }, FrameLayout.LayoutParams(-1, -1))

        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        // title row with the round gold back button
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(14), dp(16), dp(14), dp(6))
        }
        val back = ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setBackgroundResource(R.drawable.bg_control_dark)
            setPadding(dp(11), dp(11), dp(11), dp(11))
            contentDescription = getString(R.string.back)
            isFocusable = true
            setOnClickListener { dialog.dismiss() }
        }
        header.addView(back, LinearLayout.LayoutParams(dp(46), dp(46)))
        header.addView(TextView(this).apply {
            text = detail.title.ifBlank { base.name }
            setTextColor(getColor(R.color.gold_light))
            textSize = 19f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(10), 0, dp(56), 0) })
        column.addView(header)

        val list = ListView(this).apply {
            divider = null
            setSelector(android.R.color.transparent)
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
        }
        var selected = seasons.indexOf(episodes.firstOrNull { it.url == nextEpisode()?.url }?.group).coerceAtLeast(0)
        var shown: List<Channel> = emptyList()
        lateinit var adapter: ArrayAdapter<Channel>
        val cards = ArrayList<TextView>()

        fun seasonText(i: Int): String {
            val eps = episodes.filter { it.group == seasons[i] }
            val seen = eps.count { prefs.isWatched(it.url) }
            return seasons[i] + "\n" + eps.size + " حلقة  •  👁 " + seen
        }
        fun loadSeason(i: Int) {
            selected = i
            shown = episodes.filter { it.group == seasons[i] }
            cards.forEachIndexed { k, c -> c.setBackgroundResource(if (k == i) R.drawable.bg_chip_active else R.drawable.bg_chip); c.text = seasonText(k) }
            adapter.clear()
            adapter.addAll(shown)
            adapter.notifyDataSetChanged()
        }

        adapter = object : ArrayAdapter<Channel>(this, 0, ArrayList<Channel>()) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val ep = getItem(position)!!
                val row = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_episode, parent, false)
                row.findViewById<TextView>(R.id.epName).text = ep.name
                row.findViewById<TextView>(R.id.epDuration).text = durationOf(ep)
                val thumb = row.findViewById<ImageView>(R.id.epThumb)
                val pic = ep.logo.trim().ifBlank { detail.backdrop.ifBlank { detail.poster } }.trim()
                if (pic.isNotBlank()) thumb.load(pic) else thumb.setImageDrawable(null)
                val watched = prefs.isWatched(ep.url)
                val saved = prefs.resumePosition(ep.url)
                row.findViewById<TextView>(R.id.epResume).text = if (saved > 0L) "⏵ استكمال من ${clock(saved)}" else ""
                row.findViewById<ProgressBar>(R.id.epProgress).progress = (prefs.progressFraction(ep.url) * 1000).toInt()
                val eye = row.findViewById<TextView>(R.id.epWatched)
                eye.text = if (watched) "👁\nتمت" else "👁"
                eye.setTextColor(if (watched) getColor(R.color.gold) else 0x66FFFFFF)
                eye.alpha = if (watched) 1f else 0.6f
                eye.setOnClickListener {
                    prefs.setWatched(ep.url, !prefs.isWatched(ep.url))
                    loadSeasonKeepScroll(list, ::loadSeason, selected)
                }
                return row
            }
        }
        list.adapter = adapter

        val strip = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val cardRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(10), dp(4), dp(10), dp(8)) }
        seasons.forEachIndexed { i, _ ->
            val card = TextView(this).apply {
                gravity = Gravity.CENTER
                textSize = 13f
                setTextColor(getColor(R.color.gold_light))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(dp(18), dp(10), dp(18), dp(10))
                minWidth = dp(120)
                minHeight = dp(56)
                isFocusable = true
                setOnClickListener { loadSeason(i) }
            }
            cards.add(card)
            cardRow.addView(card, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        strip.addView(cardRow)
        column.addView(strip, LinearLayout.LayoutParams(-1, -2))
        column.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(column, FrameLayout.LayoutParams(-1, -1))

        list.setOnItemClickListener { _, _, position, _ ->
            val ep = adapter.getItem(position) ?: return@setOnItemClickListener
            dialog.dismiss()
            startItem(ep)
        }
        dialog.setContentView(root)
        dialog.setOnDismissListener { dialogRef = null; updatePlayButton() }
        loadSeason(selected)
        dialog.show()
        // open on the episode the user is watching
        val current = nextEpisode()
        val index = shown.indexOfFirst { it.url == current?.url }
        if (index > 0) list.post { list.setSelection((index - 1).coerceAtLeast(0)) }
    }

    /** Refreshes the rows after the eye was tapped, without jumping back to the top of the list. */
    private fun loadSeasonKeepScroll(list: ListView, load: (Int) -> Unit, season: Int) {
        val first = list.firstVisiblePosition
        val top = list.getChildAt(0)?.top ?: 0
        load(season)
        list.setSelectionFromTop(first, top)
    }

    private var dialogRef: android.app.Dialog? = null

    private fun toggleFavorite() {
        prefs.toggleFavorite(base, if (isSeries) "series" else "movie")
        updateFavoriteButton()
    }

    private fun updateFavoriteButton() {
        btnFav.setText(if (prefs.isFavorite(base.url)) R.string.fav_remove else R.string.fav_add)
    }

    companion object {
        const val EXTRA_KIND = "kind"
        const val EXTRA_NAME = "name"
        const val EXTRA_URL = "url"
        const val EXTRA_LOGO = "logo"
        const val EXTRA_SERIES_ID = "series_id"
        const val EXTRA_INFO_ID = "info_id"
    }
}
