package com.osogold.tv

/** The playback engines the user can choose (Settings -> Player, or the engine button of the player). */
object Engines {

    val ids: List<String> = listOf(Prefs.ENGINE_EXO, Prefs.ENGINE_VLC, Prefs.ENGINE_NATIVE, Prefs.ENGINE_EXTERNAL)

    fun title(id: String): String = when (id) {
        Prefs.ENGINE_VLC -> "LibVLC"
        Prefs.ENGINE_NATIVE -> "Android MediaPlayer (الأصلي)"
        Prefs.ENGINE_EXTERNAL -> "مشغل خارجي (MX / VLC / mpv ...)"
        else -> "Media3 (ExoPlayer) — الافتراضي"
    }

    fun next(id: String): String = ids[(ids.indexOf(id) + 1).mod(ids.size)]
}
