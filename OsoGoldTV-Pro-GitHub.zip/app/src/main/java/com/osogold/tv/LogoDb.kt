package com.osogold.tv

import android.util.JsonReader
import android.widget.ImageView
import coil.load
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStreamReader
import java.util.Locale

/**
 * Channel logos at 100%:
 *  - every address is trimmed (a space / new line at the end of an M3U logo is the most common reason for no logo);
 *  - http:// logos load (cleartext allowed, proper User-Agent through the app OkHttp client; on failure https:// is tried);
 *  - a channel WITHOUT a logo (or whose logo fails) gets it from the open global databases of the iptv-org project
 *    (the same logos as the tv-logos collection), found by the channel NAME (Arabic / English aliases included).
 */
object LogoDb {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var map: HashMap<String, String>? = null
    @Volatile private var loading = false
    private val waiting = ArrayList<() -> Unit>()

    private const val LOGOS = "https://iptv-org.github.io/api/logos.json"
    private const val CHANNELS = "https://iptv-org.github.io/api/channels.json"
    private const val MAX_AGE = 14L * 24 * 3600 * 1000

    private fun JsonReader.str(): String =
        if (peek() == android.util.JsonToken.STRING) nextString() else { skipValue(); "" }

    fun clean(raw: String): String = raw.trim().replace("\n", "").replace("\r", "").replace(" ", "%20")

    /** Name without quality words / symbols, lower case; Arabic letters unified. */
    fun norm(name: String): String {
        var s = name.lowercase(Locale.ROOT)
        s = s.replace(Regex("\\b(hd|fhd|uhd|4k|sd|hevc|h265|h264|raw|plus\\+?|vip|ᴴᴰ|ᶠᴴᴰ)\\b"), " ")
        s = s.replace(Regex("[\\[\\(][^\\]\\)]*[\\]\\)]"), " ")
        s = s.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي').replace('ة', 'ه')
        s = s.replace(Regex("[^\\p{L}\\p{N}]+"), "")
        return s
    }

    private fun file() = File(NetConfig.app.filesDir, "json_cache/logo_db.tsv")

    private fun ensureLoaded(done: () -> Unit) {
        map?.let { done(); return }
        synchronized(waiting) {
            waiting.add(done)
            if (loading) return
            loading = true
        }
        scope.launch {
            val m = try { build() } catch (_: Throwable) { HashMap() }
            map = m
            val callbacks = synchronized(waiting) { loading = false; ArrayList(waiting).also { waiting.clear() } }
            withContext(Dispatchers.Main) { callbacks.forEach { try { it() } catch (_: Throwable) {} } }
        }
    }

    private fun build(): HashMap<String, String> {
        val f = file()
        f.parentFile?.mkdirs()
        if (ChannelCache.isFresh(f, MAX_AGE)) {
            val m = HashMap<String, String>()
            f.forEachLine { line ->
                val i = line.indexOf('\t')
                if (i > 0) m[line.substring(0, i)] = line.substring(i + 1)
            }
            if (m.isNotEmpty()) return m
        }
        // 1) channel id -> logo address
        val byId = HashMap<String, String>()
        NetConfig.client().newCall(okhttp3.Request.Builder().url(LOGOS).header("User-Agent", NetConfig.userAgent()).build()).execute().use { r ->
            if (!r.isSuccessful) return HashMap()
            JsonReader(InputStreamReader(r.body!!.byteStream(), Charsets.UTF_8)).use { rd ->
                rd.beginArray()
                while (rd.hasNext()) {
                    var ch = ""; var url = ""
                    rd.beginObject()
                    while (rd.hasNext()) {
                        when (rd.nextName()) {
                            "channel" -> ch = rd.str()
                            "url" -> url = rd.str()
                            else -> rd.skipValue()
                        }
                    }
                    rd.endObject()
                    if (ch.isNotEmpty() && url.startsWith("http") && !byId.containsKey(ch)) byId[ch] = url
                }
                rd.endArray()
            }
        }
        // 2) names and alternative names -> logo
        val m = HashMap<String, String>()
        NetConfig.client().newCall(okhttp3.Request.Builder().url(CHANNELS).header("User-Agent", NetConfig.userAgent()).build()).execute().use { r ->
            if (!r.isSuccessful) return HashMap()
            JsonReader(InputStreamReader(r.body!!.byteStream(), Charsets.UTF_8)).use { rd ->
                rd.beginArray()
                while (rd.hasNext()) {
                    var id = ""; var name = ""; val alts = ArrayList<String>()
                    rd.beginObject()
                    while (rd.hasNext()) {
                        when (rd.nextName()) {
                            "id" -> id = rd.str()
                            "name" -> name = rd.str()
                            "alt_names" -> if (rd.peek() == android.util.JsonToken.BEGIN_ARRAY) {
                                rd.beginArray(); while (rd.hasNext()) alts.add(rd.str()); rd.endArray()
                            } else rd.skipValue()
                            else -> rd.skipValue()
                        }
                    }
                    rd.endObject()
                    val logo = byId[id] ?: continue
                    for (n in listOf(name) + alts) {
                        val k = norm(n)
                        if (k.length >= 3 && !m.containsKey(k)) m[k] = logo
                    }
                }
                rd.endArray()
            }
        }
        try {
            val tmp = File(f.parentFile, "logo_db.tmp")
            tmp.bufferedWriter().use { w -> for ((k, v) in m) { w.write(k); w.write("\t"); w.write(v); w.write("\n") } }
            f.delete(); tmp.renameTo(f)
        } catch (_: Throwable) {}
        return m
    }

    /** Logo address of [name] from the global databases (needs the databases loaded: see [ensureLoaded]). */
    private fun lookup(name: String): String? {
        val m = map ?: return null
        val k = norm(name)
        if (k.length < 3) return null
        m[k]?.let { return it }
        // the alias dictionary (bein / mbc / ad sport ...) gives more spellings of the same name
        for (alt in Aliases.spellings(name)) m[norm(alt)]?.let { return it }
        return null
    }

    /**
     * Loads the logo of a channel into [view]: the given address first (trimmed), then https:// when http://
     * failed, then the global logo databases by the channel name; [placeholder] while nothing is found.
     */
    fun ImageView.loadLogo(name: String, logo: String, placeholder: Int, fade: Boolean = true) {
        val view = this
        val key = name + "|" + logo
        view.setTag(R.id.logo_tag, key)
        val url = clean(logo)

        fun fromDb() {
            if (name.isBlank()) return
            ensureLoaded {
                if (view.getTag(R.id.logo_tag) != key) return@ensureLoaded
                val found = lookup(name)
                if (found != null && found != url) view.load(found) { crossfade(fade); error(placeholder) }
            }
        }
        if (url.isEmpty()) {
            view.setImageResource(placeholder)
            fromDb()
            return
        }
        view.load(url) {
            crossfade(fade)
            placeholder(placeholder)
            error(placeholder)
            listener(onError = { _, _ ->
                if (view.getTag(R.id.logo_tag) == key) {
                    if (url.startsWith("http://", true)) {
                        view.load("https://" + url.substring(7)) {
                            crossfade(fade); error(placeholder)
                            listener(onError = { _, _ -> fromDb() })
                        }
                    } else fromDb()
                }
            })
        }
    }
}
