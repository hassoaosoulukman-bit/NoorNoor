package com.osogold.tv

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Local SQLite database (on the storage disk, not in RAM) for the big lists of channels / movies / series.
 * The screen only ever reads the 30 rows it needs ([PagedRows]); the previous pages are dropped while scrolling.
 * Blocking calls: [replace] must run on Dispatchers.IO; a single [page] read of 30 rows is a millisecond.
 */
object ChannelDb {

    private class Helper(context: Context) : SQLiteOpenHelper(context, "lists.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE ch (k TEXT NOT NULL, pos INTEGER NOT NULL, name TEXT, url TEXT, logo TEXT, grp TEXT, sid TEXT, iid TEXT, PRIMARY KEY (k, pos))")
            db.execSQL("CREATE TABLE meta (k TEXT PRIMARY KEY, total INTEGER, t INTEGER)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            db.execSQL("DROP TABLE IF EXISTS ch"); db.execSQL("DROP TABLE IF EXISTS meta"); onCreate(db)
        }
    }

    @Volatile private var helper: Helper? = null

    private fun db(): SQLiteDatabase {
        val h = helper ?: synchronized(this) { helper ?: Helper(NetConfig.app).also { helper = it } }
        h.setWriteAheadLoggingEnabled(true) // readers (the screen) are never blocked by a writer
        return h.writableDatabase
    }

    fun key(catalog: String, pkg: String): String = "l_" + Integer.toHexString((catalog + "|" + pkg).hashCode())

    /** Stores [list] under [key] (in one transaction) and keeps only the 6 newest lists. */
    fun replace(key: String, list: List<Channel>) {
        val d = db()
        d.beginTransaction()
        try {
            d.delete("ch", "k = ?", arrayOf(key))
            val stmt = d.compileStatement("INSERT INTO ch (k,pos,name,url,logo,grp,sid,iid) VALUES (?,?,?,?,?,?,?,?)")
            list.forEachIndexed { i, c ->
                stmt.clearBindings()
                stmt.bindString(1, key); stmt.bindLong(2, i.toLong())
                stmt.bindString(3, c.name); stmt.bindString(4, c.url); stmt.bindString(5, c.logo)
                stmt.bindString(6, c.group); stmt.bindString(7, c.seriesId); stmt.bindString(8, c.infoId)
                stmt.executeInsert()
            }
            d.insertWithOnConflict("meta", null, ContentValues().apply { put("k", key); put("total", list.size); put("t", System.currentTimeMillis()) }, SQLiteDatabase.CONFLICT_REPLACE)
            d.execSQL("DELETE FROM ch WHERE k IN (SELECT k FROM meta ORDER BY t DESC LIMIT -1 OFFSET 6)")
            d.execSQL("DELETE FROM meta WHERE k NOT IN (SELECT k FROM meta ORDER BY t DESC LIMIT 6)")
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }

    fun page(key: String, offset: Int, limit: Int): List<Channel> {
        val out = ArrayList<Channel>(limit)
        db().rawQuery("SELECT name,url,logo,grp,sid,iid FROM ch WHERE k = ? AND pos >= ? AND pos < ? ORDER BY pos", arrayOf(key, offset.toString(), (offset + limit).toString())).use { c ->
            while (c.moveToNext()) out.add(Channel(name = c.getString(0) ?: "", url = c.getString(1) ?: "", logo = c.getString(2) ?: "", group = c.getString(3) ?: "", seriesId = c.getString(4) ?: "", infoId = c.getString(5) ?: ""))
        }
        return out
    }

    /** Names that contain any of [terms] (the Arabic / English spellings), at most [limit] rows. */
    fun search(key: String, terms: List<String>, limit: Int = 400): List<Channel> {
        val t = terms.filter { it.isNotBlank() }.distinct().take(12)
        if (t.isEmpty()) return emptyList()
        val where = t.joinToString(" OR ") { "name LIKE ? OR grp LIKE ?" }
        val args = ArrayList<String>().apply { add(key); t.forEach { add("%$it%"); add("%$it%") } }
        val out = ArrayList<Channel>()
        db().rawQuery("SELECT name,url,logo,grp,sid,iid FROM ch WHERE k = ? AND ($where) ORDER BY pos LIMIT $limit", args.toTypedArray()).use { c ->
            while (c.moveToNext()) out.add(Channel(name = c.getString(0) ?: "", url = c.getString(1) ?: "", logo = c.getString(2) ?: "", group = c.getString(3) ?: "", seriesId = c.getString(4) ?: "", infoId = c.getString(5) ?: ""))
        }
        return out
    }

    fun clearAll() {
        try { db().execSQL("DELETE FROM ch"); db().execSQL("DELETE FROM meta") } catch (_: Throwable) {}
    }
}

/**
 * A read-only list of rows that lives in the database: only the 30 rows of the page being shown (plus the 3
 * latest pages) are in memory; scrolling loads the next page and drops the oldest.
 */
class PagedRows(val key: String, override val size: Int) : AbstractList<Row>() {
    private val pageSize = 30
    private val pages = object : LinkedHashMap<Int, List<Row>>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Int, List<Row>>?): Boolean = size > 4
    }

    @Synchronized
    override fun get(index: Int): Row {
        val p = index / pageSize
        val rows = pages.getOrPut(p) {
            ChannelDb.page(key, p * pageSize, pageSize).map { Row(title = it.name, subtitle = it.group, leading = "", channel = it) }
        }
        return rows.getOrNull(index - p * pageSize) ?: Row(title = "")
    }
}
