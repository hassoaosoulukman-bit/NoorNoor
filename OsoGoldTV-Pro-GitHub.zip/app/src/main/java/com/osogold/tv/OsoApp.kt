package com.osogold.tv

import android.app.Activity
import android.app.Application
import android.os.Bundle

/**
 * Application class: makes the application context available to the network layer, loads the
 * colour theme, and stops EVERY player the moment the user leaves the app (no sound in the background).
 */
class OsoApp : Application(), coil.ImageLoaderFactory {

    /**
     * Every picture of the app (logos, posters) goes through the app OkHttp client: http:// (cleartext) is allowed
     * and every request carries the User-Agent chosen in Settings, because many IPTV logo servers refuse the default one.
     */
    override fun newImageLoader(): coil.ImageLoader {
        val http = NetConfig.client().newBuilder()
            .addInterceptor { chain ->
                chain.proceed(chain.request().newBuilder().header("User-Agent", NetConfig.userAgent()).build())
            }
            .build()
        return coil.ImageLoader.Builder(this)
            .okHttpClient(http)
            .respectCacheHeaders(false)
            .crossfade(false)
            // memory cache limited to 15% of the app memory; big posters are decoded at a reduced size: no OutOfMemoryError
            .memoryCache { coil.memory.MemoryCache.Builder(this).maxSizePercent(0.15).build() }
            .allowRgb565(true)
            .build()
    }


    /**
     * Crash shield: an uncaught error is written to a log file and swallowed, so the app never closes by itself.
     * A background thread just continues; on the main thread the message loop is restarted. If it keeps failing
     * (4 crashes within 10 seconds) the normal Android handler takes over so the app cannot loop forever.
     */
    private fun installCrashShield() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        val times = ArrayDeque<Long>()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                java.io.File(filesDir, "crash.log").appendText(
                    java.util.Date().toString() + " [" + thread.name + "] " + android.util.Log.getStackTraceString(error) + "\n"
                )
            } catch (_: Throwable) {}
            val now = System.currentTimeMillis()
            times.addLast(now)
            while (times.isNotEmpty() && now - times.first() > 10_000L) times.removeFirst()
            if (times.size >= 4) {
                previous?.uncaughtException(thread, error)
                return@setDefaultUncaughtExceptionHandler
            }
            if (thread === android.os.Looper.getMainLooper().thread) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    while (true) {
                        try { android.os.Looper.loop() } catch (e: Throwable) {
                            try { java.io.File(filesDir, "crash.log").appendText("loop: " + android.util.Log.getStackTraceString(e) + "\n") } catch (_: Throwable) {}
                        }
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        installCrashShield()
        NetConfig.init(this)
        SoundFx.init(this)
        UiTheme.load(this)
        // the AES-256 storage (Keystore) is slow to open the first time: do it in the background now,
        // so the main screen never waits for it on the UI thread
        Thread({ try { SecureStore.prefs(this) } catch (_: Throwable) {} }, "secure-warmup").start()
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                AppState.started++
            }

            override fun onActivityStopped(activity: Activity) {
                AppState.started = (AppState.started - 1).coerceAtLeast(0)
                // the last screen went away (home button, another app, app closed) and it is not a rotation
                if (AppState.started == 0 && !activity.isChangingConfigurations && !AppState.keepAudio) {
                    AppState.stopEverything()
                }
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
    }
}

/** Foreground state of the app and the global "stop all sound" switch. */
object AppState {

    @Volatile
    var started = 0

    /** Audio-only mode: the sound continues in the background instead of being stopped. */
    @Volatile
    var keepAudio = false

    val inForeground: Boolean get() = started > 0

    /** Listeners (the main screen) that must stop ExoPlayer / LibVLC themselves. */
    val stopListeners = java.util.concurrent.CopyOnWriteArrayList<() -> Unit>()

    fun stopEverything() {
        for (listener in stopListeners) {
            try {
                listener()
            } catch (_: Exception) {
            }
        }
        try {
            PlaybackService.instance?.stopPlayback()
            PlaybackService.instance?.stopSelf()
        } catch (_: Exception) {
        }
    }
}
