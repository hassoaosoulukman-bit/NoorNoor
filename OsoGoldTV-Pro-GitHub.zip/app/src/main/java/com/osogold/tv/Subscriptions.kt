package com.osogold.tv

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Draft of a subscription form: everything typed is kept (AES-256 encrypted) while the user leaves to another
 * app to copy a password; the dialog is re-opened with the same text. Cleared on save / cancel.
 */
class FormDraft(context: Context, private val kind: String) {

    private val sp = SecureStore.prefs(context)

    fun bind(field: String, edit: EditText) {
        val saved = sp.getString("draft.$kind.$field", null)
        if (saved != null) edit.setText(saved)
        edit.doAfterTextChanged {
            sp.edit().putString("draft.$kind.$field", it?.toString().orEmpty()).putString(OPEN_KEY, kind).apply()
        }
    }

    fun clear() {
        val e = sp.edit()
        for (key in sp.all.keys) if (key.startsWith("draft.$kind.")) e.remove(key)
        if (sp.getString(OPEN_KEY, "") == kind) e.remove(OPEN_KEY)
        e.apply()
    }

    companion object {
        private const val OPEN_KEY = "draft.open"

        /** The kind of the form that was left open ("xtream", "stalker", "m3u") or "". */
        fun pending(context: Context): String = SecureStore.prefs(context).getString(OPEN_KEY, "") ?: ""
    }
}

/** "My subscription / servers": the active subscription, its status and expiry, one-tap switching, edit and delete. */
class SubscriptionsActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val root = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#FF050403"))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(24))
        }
        root.addView(list)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun button(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 13f
        gravity = Gravity.CENTER
        setTextColor(Color.parseColor("#FFD4AF37"))
        setBackgroundResource(R.drawable.bg_chip)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { marginEnd = dp(8); topMargin = dp(8) }
    }

    private fun card(title: String, active: Boolean, status: TextView?, buttons: List<TextView>): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(if (active) R.drawable.bg_chip_active else R.drawable.bg_chip)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(10) }
        }
        c.addView(text((if (active) "✔  " else "") + title, 16f, Color.WHITE, true))
        status?.let { c.addView(it) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.forEach { row.addView(it) }
        c.addView(row)
        return c
    }

    private fun statusText(t: String, color: Int = Color.parseColor("#FFB8A878")) = text(t, 12f, color)

    private fun activate(id: String, catalog: String) {
        prefs.activeSub = id
        prefs.pendingCatalog = catalog
        toast("تم التبديل — ستفتح الشاشة الرئيسية على هذا الاشتراك")
        render()
    }

    private fun openEditor(kind: String) {
        startActivity(Intent(this, SettingsActivity::class.java).putExtra(SettingsActivity.EXTRA_OPEN_DIALOG, kind))
    }

    private fun render() {
        list.removeAllViews()
        list.addView(text("اشتراكي / السيرفرات", 22f, Color.parseColor("#FFF3D98B"), true))
        list.addView(text("الاشتراك النشط الآن يُفتح مباشرة في الشاشة الرئيسية. اضغط «تفعيل» للتبديل بين الاشتراكات.", 12f, Color.parseColor("#FFB8A878")))

        val active = prefs.activeSub

        // built-in free subscription
        list.addView(card("الاشتراك المجاني المدمج", active == "free",
            statusText("القنوات والأفلام والراديو والقرآن المجانية — تعمل دائماً"),
            listOf(button("تفعيل") { activate("free", "live") })))

        // Xtream
        if (prefs.xtreamConfigured()) {
            val status = statusText("جارٍ فحص الاشتراك…")
            list.addView(card(prefs.xtreamName.ifBlank { "اشتراك Xtream" }, active == "xtream", status, listOf(
                button("تفعيل") { activate("xtream", "x_live") },
                button("تعديل") { openEditor("xtream") },
                button("حذف") { confirmDelete("اشتراك Xtream") { prefs.clearXtreamAccount(); if (prefs.activeSub == "xtream") prefs.activeSub = "free"; render() } }
            )))
            lifecycleScope.launch {
                try {
                    val info = withContext(Dispatchers.IO) { XtreamClient.accountInfo(prefs) }
                    status.text = "🟢 يعمل\n$info"
                } catch (e: Exception) {
                    status.text = "🔴 ${e.message ?: e.javaClass.simpleName}"
                }
            }
        }

        // Stalker
        if (prefs.stalkerConfigured()) {
            val status = statusText("جارٍ فحص البوابة…")
            list.addView(card(prefs.stalkerName.ifBlank { "Stalker Portal" }, active == "stalker", status, listOf(
                button("تفعيل") { activate("stalker", "stalker") },
                button("تعديل") { openEditor("stalker") },
                button("حذف") { confirmDelete("بوابة Stalker") { prefs.clearStalker(); if (prefs.activeSub == "stalker") prefs.activeSub = "free"; render() } }
            )))
            lifecycleScope.launch {
                try {
                    val msg = withContext(Dispatchers.IO) { StalkerClient.test(prefs) }
                    status.text = "🟢 $msg"
                } catch (e: Exception) {
                    status.text = "🔴 ${e.message ?: e.javaClass.simpleName}"
                }
            }
        }

        // M3U lists
        for (item in prefs.customLists()) {
            list.addView(card(item.name, active == "m3u:${item.id}", statusText(item.value.take(60)), listOf(
                button("تفعيل") { activate("m3u:${item.id}", "m3u:${item.id}") },
                button("حذف") { confirmDelete(item.name) { prefs.removeCustomList(item.id); if (prefs.activeSub == "m3u:${item.id}") prefs.activeSub = "free"; render() } }
            )))
        }

        list.addView(text("إضافة اشتراك جديد", 14f, Color.parseColor("#FFF3D98B"), true).apply { setPadding(0, dp(18), 0, 0) })
        val add = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        add.addView(button("Xtream Codes") { openEditor("xtream") })
        add.addView(button("Stalker Portal") { openEditor("stalker") })
        add.addView(button("قائمة M3U") { openEditor("m3u") })
        list.addView(add)
    }

    private fun confirmDelete(name: String, action: () -> Unit) {
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this, R.style.GoldDialog)
            .setTitle("حذف $name؟")
            .setPositiveButton("حذف") { _, _ -> action() }
            .setNegativeButton("إلغاء", null)
            .create()
        showImmersive(dialog)
    }
}

/** Reads the clipboard text (for the "Paste" buttons). */
object Clip {
    fun text(context: Context): String {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
    }
}
