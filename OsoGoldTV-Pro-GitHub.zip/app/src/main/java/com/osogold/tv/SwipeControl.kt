package com.osogold.tv

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Vertical swipe on a player surface:
 *  - right half: raises / lowers the real system volume (AudioManager) with a percentage indicator;
 *  - left half: raises / lowers the screen brightness (window.attributes.screenBrightness) with an indicator.
 * A tap is NOT consumed (the touch is only taken once a vertical swipe starts), so buttons and
 * "touch to show the controls" keep working. Call [onTouch] from the touch listener of the player surface.
 */
class SwipeControl(private val activity: Activity, private val indicatorHost: FrameLayout) {

    private val audio = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val slop = ViewConfiguration.get(activity).scaledTouchSlop * 2
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val indicator = TextView(activity).apply {
        setTextColor(0xFFD4AF37.toInt()); textSize = 18f; gravity = Gravity.CENTER
        setBackgroundResource(R.drawable.bg_control_dark)
        setPadding(40, 24, 40, 24)
        visibility = View.GONE
    }
    private val hideRunnable = Runnable { indicator.visibility = View.GONE }

    private var downX = 0f
    private var downY = 0f
    private var lastY = 0f
    private var mode = 0 // 0 undecided, 1 volume, 2 brightness, -1 not a swipe
    private var level = 0f

    init {
        indicatorHost.addView(indicator, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
    }

    fun onTouch(v: View, e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastY = e.y; mode = 0
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == -1) return false
                if (mode == 0) {
                    val dx = abs(e.x - downX); val dy = abs(e.y - downY)
                    if (dy > slop && dy > dx * 1.4f) {
                        mode = if (downX > v.width / 2f) 1 else 2
                        level = if (mode == 1) currentVolume() else currentBrightness()
                        v.cancelLongPress(); v.isPressed = false
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                    } else if (dx > slop) { mode = -1; return false }
                    else return false
                }
                val h = v.height.coerceAtLeast(1).toFloat()
                level = (level + (lastY - e.y) / h * 1.2f).coerceIn(0f, 1f) // a swipe of ~85% of the height = 0..100%
                lastY = e.y
                if (mode == 1) setVolume(level) else setBrightness(level)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val swiped = mode > 0
                mode = 0
                return swiped
            }
        }
        return mode > 0
    }

    private fun currentVolume(): Float =
        audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)

    private fun setVolume(f: Float) {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (f * max).toInt().coerceIn(0, max), 0)
        show("🔊 " + (f * 100).toInt() + "%")
    }

    private fun currentBrightness(): Float {
        val b = activity.window.attributes.screenBrightness
        if (b >= 0f) return b
        return try { Settings.System.getInt(activity.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f } catch (_: Throwable) { 0.5f }
    }

    private fun setBrightness(f: Float) {
        val lp = activity.window.attributes
        lp.screenBrightness = f.coerceIn(0.02f, 1f)
        activity.window.attributes = lp
        show("☀ " + (f * 100).toInt() + "%")
    }

    private fun show(text: String) {
        indicator.text = text
        indicator.visibility = View.VISIBLE
        indicator.bringToFront()
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, 800L)
    }
}
