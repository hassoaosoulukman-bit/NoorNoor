package com.osogold.tv

import android.content.Context
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

/**
 * Colour themes of the interface. Every theme is the original black / gold design with the hue
 * turned to another colour (saturation 0 gives silver), so every drawable, icon and text of the
 * app follows the chosen theme.
 */
object UiTheme {

    class Theme(val name: String, val hue: Float, val saturation: Float = 1f, val swatch: Int)

    /** Hue of the base gold (0xFFD4AF37). */
    private const val BASE_HUE = 46f

    val all: List<Theme> = listOf(
        Theme("ذهبي ملكي", 46f, 1f, 0xFFD4AF37.toInt()),
        Theme("ياقوتي أزرق", 215f, 1f, 0xFF3B82F6.toInt()),
        Theme("زمردي أخضر", 145f, 1f, 0xFF22C55E.toInt()),
        Theme("أرجواني", 280f, 1f, 0xFFA855F7.toInt()),
        Theme("وردي", 330f, 1f, 0xFFEC4899.toInt()),
        Theme("قرمزي", 356f, 1f, 0xFFEF4444.toInt()),
        Theme("برتقالي", 24f, 1f, 0xFFF97316.toInt()),
        Theme("سماوي", 190f, 1f, 0xFF06B6D4.toInt()),
        Theme("فيروزي", 168f, 1f, 0xFF14B8A6.toInt()),
        Theme("ليموني", 78f, 1f, 0xFF84CC16.toInt()),
        Theme("نيلي", 245f, 1f, 0xFF6366F1.toInt()),
        Theme("بنفسجي ملكي", 262f, 0.9f, 0xFF8B5CF6.toInt()),
        Theme("خوخي", 12f, 0.7f, 0xFFFB8F7A.toInt()),
        Theme("فضي", 46f, 0f, 0xFFC0C0C0.toInt())
    )

    @Volatile
    var index: Int = 0
        private set

    val current: Theme get() = all[index.coerceIn(0, all.size - 1)]

    private var matrix: ColorMatrix = ColorMatrix()
    private var filter: ColorFilter? = null

    fun load(context: Context) {
        select(Prefs(context).themeIndex)
    }

    fun select(i: Int) {
        index = i.coerceIn(0, all.size - 1)
        val t = current
        val cm = ColorMatrix()
        if (index != 0) {
            cm.setSaturation(t.saturation)
            val rotate = hueMatrix(t.hue - BASE_HUE)
            cm.postConcat(rotate)
        }
        matrix = cm
        filter = if (index == 0) null else ColorMatrixColorFilter(cm)
    }

    private fun hueMatrix(degrees: Float): ColorMatrix {
        val rad = Math.toRadians(degrees.toDouble())
        val c = Math.cos(rad).toFloat()
        val s = Math.sin(rad).toFloat()
        val lr = 0.213f
        val lg = 0.715f
        val lb = 0.072f
        return ColorMatrix(
            floatArrayOf(
                lr + c * (1 - lr) + s * -lr, lg + c * -lg + s * -lg, lb + c * -lb + s * (1 - lb), 0f, 0f,
                lr + c * -lr + s * 0.143f, lg + c * (1 - lg) + s * 0.140f, lb + c * -lb + s * -0.283f, 0f, 0f,
                lr + c * -lr + s * -(1 - lr), lg + c * -lg + s * lg, lb + c * (1 - lb) + s * lb, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }

    /** The colour as it looks in the chosen theme (alpha is kept). */
    fun t(color: Int): Int {
        if (index == 0) return color
        val m = matrix.array
        val r = Color.red(color).toFloat()
        val g = Color.green(color).toFloat()
        val b = Color.blue(color).toFloat()
        fun ch(row: Int): Int {
            val v = m[row * 5] * r + m[row * 5 + 1] * g + m[row * 5 + 2] * b + m[row * 5 + 4]
            return v.toInt().coerceIn(0, 255)
        }
        return Color.argb(Color.alpha(color), ch(0), ch(1), ch(2))
    }

    /** Applies the theme to a whole view tree (static layouts). Safe to call many times. */
    fun apply(root: View) {
        tint(root)
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) apply(root.getChildAt(i))
        }
    }

    private fun tint(v: View) {
        if (filter == null) return // the default gold theme: nothing to change
        val bg = v.background
        if (bg != null && v.getTag(R.id.tag_theme_bg) != false) {
            // custom painted views (orbit, logo, background) read UiTheme.t() themselves
            if (v !is OrbitLayout && v !is CosmicBackgroundView && v !is RoyalLogoView && v !is GoldIconButton) {
                bg.mutate().colorFilter = filter
            }
        }
        // only vector icons are recoloured, never posters / photos
        if (v is ImageView && v.drawable is android.graphics.drawable.VectorDrawable) {
            v.colorFilter = filter
        }
        if (v is TextView) {
            // remember the colour the layout / adapter chose, so the theme can be changed again later
            val last = v.getTag(R.id.tag_theme_last) as? Int
            val stored = v.getTag(R.id.tag_theme_text) as? Int
            val original = if (last != null && stored != null && v.currentTextColor == last) stored else v.currentTextColor
            val applied = t(original)
            v.setTag(R.id.tag_theme_text, original)
            v.setTag(R.id.tag_theme_last, applied)
            v.setTextColor(applied)
        }
    }
}
