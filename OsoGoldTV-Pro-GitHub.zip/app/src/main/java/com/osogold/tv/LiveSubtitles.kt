package com.osogold.tv

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * Taps the PCM audio that ExoPlayer is about to play (before the speakers), converts it to 16 kHz mono
 * and hands it to [sink]. The audio itself passes through untouched.
 */
class PcmTap(private val enabled: () -> Boolean = { true }, private val sink: (ShortArray) -> Unit) : BaseAudioProcessor() {

    private var rate = 48000
    private var channels = 2
    private val buffer = ShortArray(1600)
    private var filled = 0
    private var acc = 0.0
    private var count = 0
    private var phase = 0.0

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) return AudioProcessor.AudioFormat.NOT_SET
        rate = inputAudioFormat.sampleRate.coerceAtLeast(8000)
        channels = inputAudioFormat.channelCount.coerceAtLeast(1)
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        if (!enabled()) {
            // translation is off: the audio just passes through (no work at all, 0% extra CPU)
            val out = replaceOutputBuffer(size)
            out.put(inputBuffer)
            out.flip()
            return
        }
        val view = inputBuffer.duplicate().order(ByteOrder.nativeOrder()).asShortBuffer()
        try {
            val frames = view.remaining() / channels
            val step = 16000.0 / rate
            for (f in 0 until frames) {
                var sum = 0
                for (c in 0 until channels) sum += view.get()
                acc += sum.toDouble() / channels
                count++
                phase += step
                if (phase >= 1.0) {
                    phase -= 1.0
                    buffer[filled++] = (acc / count).toInt().coerceIn(-32768, 32767).toShort()
                    acc = 0.0
                    count = 0
                    if (filled == buffer.size) {
                        sink(buffer.copyOf())
                        filled = 0
                    }
                }
            }
        } catch (_: Throwable) {
        }
        val out = replaceOutputBuffer(size)
        out.put(inputBuffer)
        out.flip()
    }
}

/**
 * Direct tap on the audio of the MAIN player (Media3). The processor is part of the player's audio sink, but it
 * converts nothing until the live translation is switched on ([sink] != null).
 */
object PcmBridge {
    @Volatile
    var sink: ((ShortArray) -> Unit)? = null

    fun newProcessor(): PcmTap = PcmTap({ sink != null }) { pcm -> sink?.invoke(pcm) }
}

/** A muted, video-less second player at the live edge whose only job is to feed the translator. */
class TapPlayer(private val context: Context, private val tap: PcmTap) {

    var player: ExoPlayer? = null
        private set

    fun start(url: String, startAtMs: Long) {
        release()
        val renderers = object : DefaultRenderersFactory(context) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink? = DefaultAudioSink.Builder(context)
                .setAudioProcessors(arrayOf<AudioProcessor>(tap))
                .build()
        }
        val p = ExoPlayer.Builder(context, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(NetConfig.dataSourceFactory(context)))
            .setAudioAttributes(
                androidx.media3.common.AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_SPEECH).build(),
                false
            )
            .build()
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
            .setForceLowestBitrate(true)
            .build()
        p.volume = 0f
        p.setMediaItem(MediaItem.fromUri(url))
        if (startAtMs > 0) p.seekTo(startAtMs)
        p.prepare()
        p.playWhenReady = true
        player = p
    }

    fun release() {
        try { player?.release() } catch (_: Throwable) {}
        player = null
    }
}

/**
 * AI Live subtitles (translation to Arabic).
 *
 * How the lip-sync works: the picture the user sees is played [delay] seconds behind the live edge
 * (the buffer lives only in RAM), while a hidden audio-only copy of the stream runs at the live edge
 * and feeds the speech engine. The translation therefore has [delay] seconds to be produced, and it is
 * shown exactly when the same words are heard on screen. Nothing is written to the phone.
 *
 * Engines: free = on-device Android speech recognition + Google ML Kit translation (tr, de, en, fr, es);
 * high accuracy = Gemini (key saved in Settings) - any language incl. Kurdish, Modern Standard Arabic.
 * Any failure only affects the subtitles: the video is never touched.
 */
class LiveSubtitleManager(
    private val context: Context,
    private val prefs: Prefs,
    private val host: Host
) {

    interface Host {
        fun mainPlayer(): Player?
        fun streamUrl(): String?
        fun isVlc(): Boolean
        fun overlayRoot(): FrameLayout
        fun toast(text: String)

        /** The settings window opened / closed (the side lists hide while it is open). */
        fun onPanelVisibility(open: Boolean) {}

        /** Lowers / restores the original channel sound while the dubbing speaks (1f = normal). */
        fun setChannelVolume(volume: Float) {}
    }

    private val dubber = LiveDubber(context, prefs) { host.setChannelVolume(it) }
    private val main = Handler(Looper.getMainLooper())
    private val net = Executors.newSingleThreadExecutor()
    private val pipeExec = Executors.newSingleThreadExecutor()
    private val pipeQueue = AtomicInteger(0)

    var active = false
        private set
    private var subsPaused = false
    private var shiftMs = 0L
    private var lastCcAt = 0L
    private var overlay: TextView? = null
    private var tapPlayer: TapPlayer? = null
    private var generation = 0
    private var measuredDelayMs = -1L
    private var usingKey = false

    // chunk collector (key engine)
    private val chunk = ByteArrayOutputStream()
    private var chunkStart = 0L
    private var quietSamples = 0

    // free engine
    private var recognizer: SpeechRecognizer? = null
    private var pipeOut: OutputStream? = null
    private var freeLang = "en"
    private var lastPartial = ""
    private var lastPartialAt = 0L

    private val translators = HashMap<String, Translator>()

    // ------------------------------------------------------------------ start / stop

    fun toggle() {
        if (active) stop() else start()
    }

    fun start() {
        if (active) return
        val url = host.streamUrl()
        if (url.isNullOrBlank()) {
            host.toast("شغّل قناة أو فيلماً أولاً")
            return
        }
        active = true
        subsPaused = false
        keyErrorShown = false
        usingKey = hasAudioAi()
        ensureOverlay()
        if (prefs.dubEnabled) dubber.start()
        host.toast(if (usingKey) (if (groqKeys().isNotEmpty()) "الترجمة الفورية: Groq Whisper + Llama 3.3" else "الترجمة الفورية فائقة الدقة (Gemini)") else "الترجمة الفورية المجانية (Google ML Kit)")
        launchPipeline(url)
    }

    fun stop() {
        active = false
        PcmBridge.sink = null
        directTap = false
        dubber.stop()
        generation++
        main.removeCallbacksAndMessages(null)
        tapPlayer?.release()
        tapPlayer = null
        stopFree()
        chunk.reset()
        overlay?.visibility = View.GONE
        for (t in translators.values) try { t.close() } catch (_: Throwable) {}
        translators.clear()
        // bring the picture back to the live edge
        try {
            host.mainPlayer()?.let { if (it.isCurrentMediaItemLive) it.seekToDefaultPosition() }
        } catch (_: Throwable) {}
    }

    /** The channel / movie changed: restart the hidden player on the new address. */
    fun onStreamChanged() {
        if (!active) return
        val url = host.streamUrl() ?: return
        generation++
        PcmBridge.sink = null
        tapPlayer?.release()
        stopFree()
        chunk.reset()
        launchPipeline(url)
    }

    private fun delayMs(): Long = prefs.liveSubDelay * 1000L

    private fun launchPipeline(url: String) {
        val gen = generation
        measuredDelayMs = -1L
        try {
            val m = host.mainPlayer()
            val d = delayMs()
            var tapStart = 0L
            if (m != null) {
                if (m.isCurrentMediaItemLive) {
                    val offset = m.currentLiveOffset
                    if (offset != C.TIME_UNSET && offset < d) {
                        m.seekTo((m.currentPosition - (d - offset)).coerceAtLeast(0L))
                    }
                } else {
                    tapStart = m.currentPosition + d
                }
            }
            if (!usingKey) startFree(sourceLanguage())
            if (!host.isVlc() && m != null) {
                // the channel sound is taken DIRECTLY from the main player (AudioProcessor): no second download
                directTap = true
                PcmBridge.sink = { pcm -> if (gen == generation) onPcm(pcm) }
                return
            }
            directTap = false
            val tap = PcmTap { pcm -> if (gen == generation) onPcm(pcm) }
            val tp = TapPlayer(context, tap)
            tapPlayer = tp
            tp.start(url, tapStart)
            tp.player?.addListener(object : Player.Listener {
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    if (gen == generation) host.toast("تعذّر تحليل الصوت لهذه القناة — يستمر الفيديو بدون ترجمة")
                }
            })
            main.postDelayed(object : Runnable {
                override fun run() {
                    if (gen != generation || !active) return
                    calibrate()
                    main.postDelayed(this, 2000L)
                }
            }, 3000L)
        } catch (e: Throwable) {
            host.toast("تعذّر تشغيل الترجمة: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** Real distance between the picture and the hidden live-edge copy. */
    private fun calibrate() {
        try {
            val m = host.mainPlayer() ?: return
            val t = tapPlayer?.player ?: return
            // the VOD copy pauses together with the movie
            if (!m.isCurrentMediaItemLive) {
                val moving = m.isPlaying || m.playbackState == Player.STATE_BUFFERING
                if (t.playWhenReady != moving) t.playWhenReady = moving
            }
            val a = m.currentLiveOffset
            val b = t.currentLiveOffset
            measuredDelayMs = if (a != C.TIME_UNSET && b != C.TIME_UNSET) (a - b).coerceAtLeast(0L) else -1L
        } catch (_: Throwable) {
        }
    }

    /** true = the sound comes straight from the main player: no hidden second player, no picture delay. */
    private var directTap = false

    private fun groqKeys(): List<String> = AiKeys.active(prefs).filter { AiKeys.provider(it) == AiKeys.GROQ }

    private fun hasAudioAi(): Boolean = groqKeys().isNotEmpty() || AiKeys.hasGemini(prefs)

    private fun effectiveDelay(): Long = if (directTap) 0L else if (measuredDelayMs >= 0) measuredDelayMs else delayMs()

    // ------------------------------------------------------------------ audio in

    private fun onPcm(pcm: ShortArray) {
        if (prefs.dubEnabled) dubber.observe(pcm)
        if (usingKey) feedChunk(pcm) else feedFree(pcm)
    }

    // ---- high accuracy engine: chunks of speech -> Gemini

    private fun feedChunk(pcm: ShortArray) {
        if (chunk.size() == 0) {
            chunkStart = SystemClock.elapsedRealtime()
            quietSamples = 0
        }
        var energy = 0.0
        val bytes = ByteArray(pcm.size * 2)
        for (i in pcm.indices) {
            val v = pcm[i].toInt()
            bytes[i * 2] = (v and 0xFF).toByte()
            bytes[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
            energy += (v * v).toDouble()
        }
        chunk.write(bytes)
        val rms = Math.sqrt(energy / pcm.size)
        quietSamples = if (rms < 350) quietSamples + pcm.size else 0
        val seconds = chunk.size() / 32000.0
        val cut = (seconds >= 4.0 && quietSamples >= 5000) || seconds >= 9.0
        if (cut) {
            val data = chunk.toByteArray()
            val start = chunkStart
            chunk.reset() // the buffer is wiped every few seconds
            val gen = generation
            val loud = data.size > 32000 && averageRms(data) > 250
            if (loud) {
                net.execute { if (gen == generation) translateChunk(data, start, seconds, gen) }
            }
        }
    }

    private fun averageRms(data: ByteArray): Double {
        var e = 0.0
        var n = 0
        var i = 0
        while (i + 1 < data.size) {
            val v = ((data[i + 1].toInt() shl 8) or (data[i].toInt() and 0xFF)).toShort().toInt()
            e += (v * v).toDouble()
            n++
            i += 20
        }
        return if (n == 0) 0.0 else Math.sqrt(e / n)
    }

    private fun translateChunk(pcm: ByteArray, startWall: Long, seconds: Double, gen: Int) {
        try {
            val wav = wav(pcm)
            if (groqKeys().isNotEmpty()) {
                val arabic = groqTranslate(wav)
                if (gen != generation || arabic.isNullOrBlank()) return
                scheduleText(arabic.trim(), startWall, (seconds * 1000).toLong())
                return
            }
            val prompt = "Listen to this audio. The speech may be German, Turkish, English, French, Spanish, " +
                "Kurdish (Kurmanji or Sorani) or any other language or dialect. Translate EVERYTHING that is said " +
                "into complete, correct Modern Standard Arabic (العربية الفصحى), keeping every word and meaning, " +
                "without omitting, shortening or summarising anything. " + dialectNote() +
                "Output ONLY the Arabic translation. " +
                "If there is no speech, output nothing."
            val text = gemini(
                JSONArray()
                    .put(JSONObject().put("text", prompt))
                    .put(JSONObject().put("inline_data", JSONObject()
                        .put("mime_type", "audio/wav")
                        .put("data", Base64.encodeToString(wav, Base64.NO_WRAP))))
            )
            if (gen != generation || text.isNullOrBlank()) return
            scheduleText(text.trim(), startWall, (seconds * 1000).toLong())
        } catch (e: Throwable) {
            keyFailed(e)
        }
    }

    /**
     * Groq: Whisper large-v3-turbo writes down what is said (any language), then Llama 3.3 70B translates it
     * into Arabic (Modern Standard or Syrian dialect). The five keys rotate when a quota ends.
     */
    private fun groqTranslate(wav: ByteArray): String? {
        var lastError: java.io.IOException? = null
        for (key in AiKeys.usable(groqKeys())) {
            try {
                val form = MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("model", "whisper-large-v3-turbo")
                    .addFormDataPart("response_format", "json")
                    .addFormDataPart("temperature", "0")
                    .apply { if (prefs.liveSubLang != "auto") addFormDataPart("language", prefs.liveSubLang) }
                    .addFormDataPart("file", "chunk.wav", wav.toRequestBody("audio/wav".toMediaType()))
                    .build()
                val heard = NetConfig.client().newCall(
                    Request.Builder().url("https://api.groq.com/openai/v1/audio/transcriptions")
                        .header("Authorization", "Bearer $key").post(form).build()
                ).execute().use { r ->
                    val body = r.body?.string().orEmpty()
                    if (!r.isSuccessful) {
                        AiKeys.markKeyProblem(key)
                        throw java.io.IOException("HTTP ${r.code}")
                    }
                    JSONObject(body).optString("text").trim()
                }
                if (heard.length < 2) return null
                val system = "You are a live TV subtitle translator. Translate the user's text into complete, correct " +
                    "Modern Standard Arabic, keeping every word and meaning. " + dialectNote() +
                    "Output ONLY the Arabic translation, nothing else. If the text is already Arabic, return it unchanged."
                val chat = JSONObject()
                    .put("model", "llama-3.3-70b-versatile")
                    .put("temperature", 0.2)
                    .put("messages", JSONArray()
                        .put(JSONObject().put("role", "system").put("content", system))
                        .put(JSONObject().put("role", "user").put("content", heard)))
                return NetConfig.client().newCall(
                    Request.Builder().url("https://api.groq.com/openai/v1/chat/completions")
                        .header("Authorization", "Bearer $key")
                        .post(chat.toString().toRequestBody("application/json".toMediaType())).build()
                ).execute().use { r ->
                    val body = r.body?.string().orEmpty()
                    if (!r.isSuccessful) {
                        AiKeys.markKeyProblem(key)
                        throw java.io.IOException("HTTP ${r.code}")
                    }
                    JSONObject(body).optJSONArray("choices")?.optJSONObject(0)
                        ?.optJSONObject("message")?.optString("content")
                }
            } catch (e: java.io.IOException) {
                lastError = e
            }
        }
        throw lastError ?: java.io.IOException("no key")
    }

    private var keyErrorShown = false
    private fun dialectNote(): String =
        if (prefs.dubEnabled && prefs.dubDialect == 1)
            "Write it in natural Syrian Levantine (Shami) dialect, like a Syrian TV drama dub, instead of Modern Standard Arabic. "
        else ""

    private fun keyFailed(e: Throwable) {
        val code = (e as? java.io.IOException)?.message.orEmpty()
        if (code.contains("401") || code.contains("403") || code.contains("400")) {
            if (!keyErrorShown) {
                keyErrorShown = true
                main.post { host.toast("مفتاح الذكاء الاصطناعي غير صالح — راجع الإعدادات. تم التحويل للترجمة المجانية") }
            }
            main.post {
                if (active) {
                    usingKey = false
                    startFree(sourceLanguage())
                }
            }
        }
    }

    private fun wav(pcm: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        fun int(v: Int) { out.write(v and 0xFF); out.write((v shr 8) and 0xFF); out.write((v shr 16) and 0xFF); out.write((v shr 24) and 0xFF) }
        fun short(v: Int) { out.write(v and 0xFF); out.write((v shr 8) and 0xFF) }
        out.write("RIFF".toByteArray()); int(36 + pcm.size); out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray()); int(16); short(1); short(1); int(16000); int(32000); short(2); short(16)
        out.write("data".toByteArray()); int(pcm.size); out.write(pcm)
        return out.toByteArray()
    }

    /** One Gemini call. [parts] is the "parts" array. Throws IOException("HTTP code") on failure. */
    private fun gemini(parts: JSONArray): String? {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .put("generationConfig", JSONObject().put("temperature", 0.2))
            .toString()
        var lastError: java.io.IOException? = null
        for (key in AiKeys.usable(AiKeys.geminiKeys(prefs))) {
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent")
                .header("x-goog-api-key", key)
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()
            try {
                return NetConfig.client().newCall(request).execute().use { r ->
                    val text = r.body?.string().orEmpty()
                    if (!r.isSuccessful) {
                        // free quota finished / key refused -> the next of the five keys, automatically
                        AiKeys.markKeyProblem(key)
                        throw java.io.IOException("HTTP ${r.code}")
                    }
                    val parts = JSONObject(text).optJSONArray("candidates")?.optJSONObject(0)
                        ?.optJSONObject("content")?.optJSONArray("parts")
                    if (parts == null) null
                    else {
                        val sb = StringBuilder()
                        for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text").orEmpty())
                        sb.toString()
                    }
                }
            } catch (e: java.io.IOException) {
                lastError = e
            }
        }
        throw lastError ?: java.io.IOException("no key")
    }

    // ---- free engine: Android speech recognition + ML Kit

    private fun sourceLanguage(): String {
        val chosen = prefs.liveSubLang
        if (chosen != "auto") return chosen
        val fromTrack = try { PlaybackService.instance?.exo()?.audioFormat?.language } catch (_: Throwable) { null }
        val code = fromTrack?.lowercase()?.take(2)
        return if (code in setOf("tr", "de", "en", "fr", "es")) code!! else "en"
    }

    private fun mlLang(code: String): String? = when (code) {
        "tr" -> TranslateLanguage.TURKISH
        "de" -> TranslateLanguage.GERMAN
        "en" -> TranslateLanguage.ENGLISH
        "fr" -> TranslateLanguage.FRENCH
        "es" -> TranslateLanguage.SPANISH
        else -> null
    }

    private fun tag(code: String) = when (code) {
        "tr" -> "tr-TR"
        "de" -> "de-DE"
        "fr" -> "fr-FR"
        "es" -> "es-ES"
        else -> "en-US"
    }

    private fun startFree(lang: String) {
        stopFree()
        freeLang = if (lang == "ku") "en" else lang
        if (Build.VERSION.SDK_INT < 33 || !SpeechRecognizer.isRecognitionAvailable(context)) {
            host.toast("الترجمة المجانية تحتاج أندرويد 13+ ومحرك تعرّف صوتي، أو أضف مفتاح AI في الإعدادات")
            return
        }
        listenFree()
    }

    private fun listenFree() {
        if (!active || usingKey) return
        try {
            val pipe = ParcelFileDescriptor.createPipe()
            pipeOut = ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])
            val rec = SpeechRecognizer.createSpeechRecognizer(context)
            recognizer = rec
            rec.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onPartialResults(partial: Bundle?) = handleFree(partial, false)
                override fun onResults(results: Bundle?) {
                    handleFree(results, true)
                    restartFree()
                }
                override fun onError(error: Int) = restartFree()
            })
            val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag(freeLang))
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra("android.speech.extra.AUDIO_SOURCE", pipe[0])
                .putExtra("android.speech.extra.AUDIO_SOURCE_SAMPLING_RATE", 16000)
                .putExtra("android.speech.extra.AUDIO_SOURCE_CHANNEL_COUNT", 1)
                .putExtra("android.speech.extra.AUDIO_SOURCE_ENCODING", android.media.AudioFormat.ENCODING_PCM_16BIT)
            rec.startListening(intent)
        } catch (e: Throwable) {
            host.toast("تعذّر تشغيل التعرف الصوتي المجاني")
        }
    }

    private fun restartFree() {
        val gen = generation
        main.postDelayed({
            if (gen == generation && active && !usingKey) {
                closeRecognizer()
                listenFree()
            }
        }, 250L)
    }

    private fun closeRecognizer() {
        try { recognizer?.destroy() } catch (_: Throwable) {}
        recognizer = null
        try { pipeOut?.close() } catch (_: Throwable) {}
        pipeOut = null
    }

    private fun stopFree() {
        closeRecognizer()
    }

    private fun feedFree(pcm: ShortArray) {
        val out = pipeOut ?: return
        if (pipeQueue.get() > 40) return
        val bytes = ByteArray(pcm.size * 2)
        for (i in pcm.indices) {
            bytes[i * 2] = (pcm[i].toInt() and 0xFF).toByte()
            bytes[i * 2 + 1] = ((pcm[i].toInt() shr 8) and 0xFF).toByte()
        }
        pipeQueue.incrementAndGet()
        pipeExec.execute {
            try { out.write(bytes) } catch (_: Throwable) {} finally { pipeQueue.decrementAndGet() }
        }
    }

    private fun handleFree(bundle: Bundle?, final: Boolean) {
        val text = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
        if (text.isEmpty()) return
        val now = SystemClock.elapsedRealtime()
        if (!final && (text == lastPartial || now - lastPartialAt < 800)) return
        lastPartial = if (final) "" else text
        lastPartialAt = now
        translateFree(text, now)
    }

    private fun translateFree(text: String, wall: Long) {
        val lang = mlLang(freeLang) ?: return
        val key = freeLang
        try {
            val translator = translators.getOrPut(key) {
                Translation.getClient(
                    TranslatorOptions.Builder().setSourceLanguage(lang).setTargetLanguage(TranslateLanguage.ARABIC).build()
                )
            }
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
                .addOnSuccessListener {
                    translator.translate(text)
                        .addOnSuccessListener { ar -> if (active) scheduleText(ar, wall, 3500L) }
                        .addOnFailureListener { }
                }
                .addOnFailureListener { host.toast("تعذّر تحميل نموذج الترجمة المجانية — تحقق من الإنترنت") }
        } catch (_: Throwable) {
        }
    }

    // ------------------------------------------------------------------ embedded captions (CC / DVB)

    /** Text of a closed caption / DVB subtitle of the channel: translated and shown at once (it is already in sync). */
    fun onEmbeddedCue(text: String) {
        if (!active || subsPaused || text.isBlank()) return
        lastCcAt = SystemClock.elapsedRealtime()
        val clean = text.trim()
        net.execute {
            try {
                val ar = if (AiKeys.hasAny(prefs)) AiKeys.complete(
                    prefs,
                    "Translate to " + (if (prefs.dubEnabled && prefs.dubDialect == 1) "natural Syrian Levantine (Shami) dialect as spoken in Syrian drama" else "complete correct Modern Standard Arabic") + ", no omissions. Output only the translation:\n$clean"
                ) else null
                if (ar != null) main.post { showNow(ar.trim(), 4500L) }
                else main.post { translateEmbeddedFree(clean) }
            } catch (_: Throwable) {
                main.post { translateEmbeddedFree(clean) }
            }
        }
    }

    private fun translateEmbeddedFree(text: String) {
        val lang = mlLang(sourceLanguage()) ?: return
        try {
            val translator = translators.getOrPut("cc_" + sourceLanguage()) {
                Translation.getClient(
                    TranslatorOptions.Builder().setSourceLanguage(lang).setTargetLanguage(TranslateLanguage.ARABIC).build()
                )
            }
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).addOnSuccessListener {
                translator.translate(text).addOnSuccessListener { showNow(it, 4500L) }
            }
        } catch (_: Throwable) {
        }
    }

    // ------------------------------------------------------------------ showing

    /** Shows [text] when its words are heard on screen: capture time + delay + manual shift. */
    private fun scheduleText(text: String, captureWall: Long, spanMs: Long) {
        if (SystemClock.elapsedRealtime() - lastCcAt < 10_000L) return // real captions win
        val pieces = splitPieces(text)
        val total = pieces.sumOf { it.length }.coerceAtLeast(1)
        var offset = 0L
        for (piece in pieces) {
            val share = (spanMs * piece.length / total).coerceAtLeast(1800L)
            val showAt = captureWall + effectiveDelay() + shiftMs + offset
            val wait = (showAt - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
            val gen = generation
            main.postDelayed({ if (gen == generation && active && !subsPaused) showNow(piece, share + 400L) }, wait)
            offset += share
        }
    }

    private fun splitPieces(text: String): List<String> {
        val sentences = text.split(Regex("(?<=[.!?؟،,;])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        var current = ""
        for (s in sentences) {
            if (current.isNotEmpty() && (current.length + s.length) > 90) {
                out.add(current)
                current = s
            } else {
                current = if (current.isEmpty()) s else "$current $s"
            }
        }
        if (current.isNotEmpty()) out.add(current)
        return if (out.isEmpty()) listOf(text) else out
    }

    private val hideTask = Runnable { overlay?.visibility = View.GONE }

    private fun showNow(text: String, holdMs: Long) {
        if (prefs.dubEnabled && active) dubber.speak(text)
        val tv = ensureOverlay()
        tv.text = text
        styleOverlay(tv)
        tv.visibility = View.VISIBLE
        tv.bringToFront()
        main.removeCallbacks(hideTask)
        main.postDelayed(hideTask, holdMs.coerceIn(2500L, 12000L))
    }

    private fun ensureOverlay(): TextView {
        overlay?.let { return it }
        val tv = TextView(context).apply {
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
            setBackgroundColor(0x88000000.toInt())
            val d = context.resources.displayMetrics.density
            setPadding((10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt())
            visibility = View.GONE
            elevation = 60f
        }
        host.overlayRoot().addView(
            tv,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        overlay = tv
        styleOverlay(tv)
        return tv
    }

    fun styleOverlay(tv: TextView? = overlay) {
        val v = tv ?: return
        v.textSize = when (prefs.liveSubSize) { 0 -> 14f; 2 -> 26f; else -> 19f }
        v.setTextColor(prefs.liveSubColor)
        val d = context.resources.displayMetrics.density
        val lp = v.layoutParams as FrameLayout.LayoutParams
        lp.gravity = (if (prefs.liveSubPos == 1) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        lp.topMargin = (28 * d).toInt()
        lp.bottomMargin = (28 * d).toInt()
        v.layoutParams = lp
    }

    // ------------------------------------------------------------------ manual controls

    fun togglePauseSubs(): Boolean {
        subsPaused = !subsPaused
        if (subsPaused) overlay?.visibility = View.GONE
        return subsPaused
    }

    fun nudge(ms: Long) {
        shiftMs += ms
        host.toast("إزاحة الترجمة: " + String.format("%+.1f", shiftMs / 1000.0) + " ث")
    }

    fun toggleLivePause() {
        val m = host.mainPlayer() ?: return
        if (m.isPlaying || m.playWhenReady) m.pause() else m.play()
    }

    // ------------------------------------------------------------------ quick panel

    fun showPanel(ctx: Context) {
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val gold = Color.parseColor("#FFD4AF37")
        val dialog = Dialog(ctx)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setGravity(Gravity.CENTER)
        }

        // ---- the choices are only a DRAFT until "Save and apply" is pressed
        var wantOn = active
        var size = prefs.liveSubSize
        var pos = prefs.liveSubPos
        var color = prefs.liveSubColor
        var lang = prefs.liveSubLang
        var dubOn = prefs.dubEnabled
        var dialect = prefs.dubDialect
        var duck = prefs.dubDuck
        var delay = prefs.liveSubDelay

        val outer = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_overlay)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        // EVERYTHING lives inside a vertical ScrollView: no setting is ever cut off at the bottom
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val scroll = ScrollView(ctx).apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = true
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(box)
        }
        outer.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        fun label(t: String) = TextView(ctx).apply {
            text = t; setTextColor(ctx.getColor(R.color.gold_light)); textSize = 13f
            setPadding(0, dp(10), 0, dp(3))
        }

        /**
         * Exclusive (radio) selection: exactly one chip of the group is lit, selecting another switches the
         * first one off. Two chips can never be lit together and none can stay stuck.
         */
        fun <T> radio(options: List<Pair<T, String>>, current: T, onPick: (T) -> Unit): View {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            val chips = ArrayList<Pair<T, TextView>>()
            fun paint(selected: T) {
                for ((value, tv) in chips) {
                    val on = value == selected
                    tv.setTextColor(if (on) Color.BLACK else Color.WHITE)
                    tv.setBackgroundColor(if (on) gold else 0x33FFFFFF)
                    tv.isSelected = on
                }
            }
            for ((value, name) in options) {
                val tv = TextView(ctx).apply {
                    text = name; textSize = 13f; gravity = Gravity.CENTER
                    minHeight = dp(40)
                    setPadding(dp(12), dp(6), dp(12), dp(6))
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                        .apply { setMargins(dp(3), dp(2), dp(3), dp(2)) }
                }
                tv.setOnClickListener { paint(value); onPick(value) }
                chips.add(value to tv)
                row.addView(tv)
            }
            paint(current)
            return HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(row) }
        }

        val status = TextView(ctx).apply {
            textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            text = (if (active) "● الترجمة تعمل — " else "○ الترجمة متوقفة — ") + when {
                groqKeys().isNotEmpty() -> "Groq Whisper + Llama 3.3"
                AiKeys.hasGemini(prefs) -> "محرك Gemini فائق الدقة"
                else -> "محرك Google ML Kit المجاني"
            }
        }
        box.addView(status)

        box.addView(label("الترجمة الفورية"))
        box.addView(radio(listOf(true to "▶ تشغيل الترجمة", false to "⏹ إيقاف الترجمة"), wantOn) { wantOn = it })

        box.addView(label("حجم الخط"))
        box.addView(radio(listOf(0 to "صغير", 1 to "متوسط", 2 to "كبير"), size) { size = it })

        box.addView(label("موقع الترجمة"))
        box.addView(radio(listOf(1 to "أعلى", 0 to "أسفل"), pos) { pos = it })

        box.addView(label("لون الترجمة"))
        val colorRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val swatches = ArrayList<Pair<Int, TextView>>()
        fun paintColors() { for ((c, tv) in swatches) tv.text = if (c == color) "✔" else "" }
        listOf("#FFFFFF", "#FFD700", "#FFEB3B", "#4FC3F7", "#81C784", "#FF8A65", "#F48FB1", "#CE93D8").forEach { hex ->
            val c = Color.parseColor(hex)
            val tv = TextView(ctx).apply {
                setBackgroundColor(c); gravity = Gravity.CENTER; setTextColor(Color.BLACK); textSize = 16f
                setOnClickListener { color = c; paintColors() }
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(dp(4), dp(2), dp(4), dp(2)) }
            }
            swatches.add(c to tv)
            colorRow.addView(tv)
        }
        paintColors()
        box.addView(HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(colorRow) })

        box.addView(label("لغة الصوت — الذكاء الاصطناعي يكتشفها تلقائياً"))
        box.addView(radio(
            listOf("auto" to "تلقائي", "tr" to "التركية", "de" to "الألمانية", "en" to "الإنجليزية", "fr" to "الفرنسية", "es" to "الإسبانية"),
            lang
        ) { lang = it })

        val syncLabel = label("مزامنة الشفاه (للمشغل الثاني فقط): $delay ثانية (5 – 60)")
        box.addView(syncLabel)
        box.addView(SeekBar(ctx).apply {
            max = 55; progress = delay - 5
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            minimumHeight = dp(40)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    delay = v + 5
                    syncLabel.text = "مزامنة الشفاه (للمشغل الثاني فقط): $delay ثانية (5 – 60)"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        box.addView(label("الدبلجة الفورية الذكية (AI Dubbing)"))
        box.addView(radio(listOf(true to "الدبلجة: تشغيل", false to "الدبلجة: إيقاف"), dubOn) { dubOn = it })
        box.addView(label("نوع الدبلجة"))
        box.addView(radio(listOf(0 to "العربية الفصحى", 1 to "اللهجة السورية الشامية"), dialect) { dialect = it })
        val duckLabel = label("صوت القناة الأصلي أثناء الدبلجة: $duck%")
        box.addView(duckLabel)
        box.addView(SeekBar(ctx).apply {
            max = 100; progress = duck
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            minimumHeight = dp(40)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    duck = v; duckLabel.text = "صوت القناة الأصلي أثناء الدبلجة: $v%"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        box.addView(label("أدوات أثناء التشغيل"))
        val tools = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun tool(t: String, onClick: () -> Unit) = TextView(ctx).apply {
            text = t; textSize = 13f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setBackgroundColor(0x33FFFFFF); minHeight = dp(40)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(dp(3), dp(2), dp(3), dp(2)) }
        }
        tools.addView(tool(if (subsPaused) "▶ استئناف الترجمة" else "⏸ إيقاف مؤقت للترجمة") {
            val p = togglePauseSubs(); host.toast(if (p) "الترجمة متوقفة مؤقتاً" else "الترجمة تعمل")
        })
        tools.addView(tool("⏯ تجميد/تشغيل البث") { toggleLivePause() })
        tools.addView(tool("−0.5 ث") { nudge(-500) })
        tools.addView(tool("+0.5 ث") { nudge(500) })
        box.addView(HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(tools) })

        box.addView(TextView(ctx).apply {
            text = "الصوت المستخدم الآن: " + dubber.currentVoice().label +
                "\nلا يُكتب أي ملف على الهاتف: الصوت يُحلَّل في الذاكرة فقط ويُمسح تلقائياً."
            setTextColor(0xAAFFFFFF.toInt()); textSize = 10f; gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        })

        // ---- "Save and apply": always visible under the scroll area
        val save = TextView(ctx).apply {
            text = "✔  حفظ وتطبيق"
            textSize = 16f; gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#FF1A1204"))
            setBackgroundResource(R.drawable.bg_gold_button)
            minHeight = dp(48)
            isClickable = true
            setOnClickListener {
                prefs.liveSubSize = size
                prefs.liveSubPos = pos
                prefs.liveSubColor = color
                val langChanged = prefs.liveSubLang != lang
                prefs.liveSubLang = lang
                prefs.dubEnabled = dubOn
                prefs.dubDialect = dialect
                prefs.dubDuck = duck
                val delayChanged = prefs.liveSubDelay != delay
                prefs.liveSubDelay = delay
                styleOverlay()
                when {
                    wantOn && !active -> start()
                    !wantOn && active -> stop()
                    active && (langChanged || delayChanged) -> onStreamChanged()
                }
                if (active) {
                    if (dubOn) dubber.start() else dubber.stop()
                    preview("نص تجريبي للترجمة")
                }
                host.toast("✓ تم الحفظ والتطبيق")
                dialog.dismiss()
            }
        }
        outer.addView(
            save,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(dp(12), dp(6), dp(12), dp(10)) }
        )

        dialog.setContentView(outer)
        dialog.setOnDismissListener { host.onPanelVisibility(false) }
        val screen = ctx.resources.displayMetrics
        dialog.window?.setLayout(minOf(dp(560), screen.widthPixels - dp(16)), (screen.heightPixels * 0.92f).toInt())
        host.onPanelVisibility(true) // the side channel lists hide while this window is open
        dialog.show()
    }

    private fun preview(text: String) {
        if (active) showNow(text, 2500L)
    }
}
