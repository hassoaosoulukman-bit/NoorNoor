package com.osogold.tv

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import java.util.Locale

/**
 * Main screen ("Cosmic Radar"):
 *   left 68%  : big rectangular live screen (Media3 or LibVLC) with the orbit of glowing icons
 *               (live, favourites, movies, series, Quran, radio, my lists, search, update, AI, settings)
 *   right 32% : two separate vertical lists side by side - channels (left) and sections (right)
 *
 * Touching the screen only shows / hides the player bar (it hides again after 5 seconds).
 * Play / pause exists ONLY as a dedicated button of the player bar.
 *
 * Also hosts: the full screen stage with the dual screen ([StageController]), the luxury audio
 * player of the radio and Quran sections ([AudioPanel]), subtitles, recording, the automatic
 * background update and the commands of the AI assistant.
 */
class MainActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private lateinit var stage: StageController
    private lateinit var audio: AudioPanel
    private lateinit var extras: PlayerExtras
    private var prevChannel: Channel? = null
    private lateinit var subtitles: SubtitleController

    private lateinit var orbit: OrbitLayout
    private lateinit var panelsRoot: FrameLayout
    private lateinit var listPanel: View
    private lateinit var playerFrame: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var vlcView: VLCVideoLayout
    private lateinit var controlsLayer: View
    private lateinit var btnPlay: ImageView
    private lateinit var btnRecord: ImageView
    private lateinit var btnQuality: ImageView
    private lateinit var btnEngine: ImageView
    private lateinit var btnSub: ImageView
    private lateinit var btnDual: ImageView
    private lateinit var btnFullscreen: ImageView
    private lateinit var tvRec: TextView
    private lateinit var tvIndicator: TextView
    private lateinit var tvNowPlaying: TextView
    private lateinit var tvListTitle: TextView
    private lateinit var tvSectionTitle: TextView
    private lateinit var searchBar: View
    private lateinit var etSearch: EditText
    private lateinit var btnBack: View
    private lateinit var list: RecyclerView
    private lateinit var sectionList: RecyclerView
    private lateinit var adapter: RowAdapter
    private lateinit var sectionAdapter: RowAdapter

    private val vlc: VlcEngine by lazy { VlcEngine(this) }

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var pendingChannel: Channel? = null
    private var nowPlaying: Channel? = null
    private var nowUrl: String? = null
    private var nowAudio = false
    private var vlcActive = false
    private var playJob: Job? = null

    /** Where the next movie / episode must start (milliseconds); set by "continue watching". */
    private var startPositionMs = 0L
    private var lastBackPress = 0L

    // ---- instant alternative channel (zero-downtime auto switch)
    private val triedAlternatives = HashSet<String>()
    private var switching = false
    private var playedOnce = false
    private var altSearchedFor: String? = null
    private var pill: TextView? = null
    private val watchdog = Runnable { onStreamStalled() }

    /** Key under which the second / watched mark of the playing movie is saved (the original episode). */
    private var progressKey: String? = null
    private var pendingProgressKey: String? = null

    /** Pages to open again when the user presses back while a movie started from its page is playing. */
    private var returnIntents: List<Intent> = emptyList()

    /** The app was left (home / another app): the playing channel is started again when the user comes back. */
    private var stoppedByBackground = false
    private var filterJob: Job? = null

    private val stopListener: () -> Unit = {
        runOnUiThread {
            if (nowPlaying != null) stoppedByBackground = true
            stopAllPlayers()
        }
    }
    private val progressTick = object : Runnable {
        override fun run() {
            saveProgressNow()
            handler.postDelayed(this, 5000L)
        }
    }

    /** The catalog shown in the two lists: live, radio, quran, a subscription id ... */
    private var catalogId = "live"
    private var catalogTitle = "البث المباشر"
    private var currentPkgTag: String? = null
    private var currentRows: List<Row> = emptyList()
    private var sectionJob: Job? = null
    private var channelJob: Job? = null

    /** Restore actions for the "back" button (episodes, search results). */
    private val backStack = ArrayList<() -> Unit>()

    private var autoSkipRemaining = 0
    private var reconnectAttempts = 0
    private var firstAutoPlayDone = false
    private var listsSignature = ""

    private val handler = Handler(Looper.getMainLooper())
    private var recLocalStart = 0L
    private var recShown = false
    private val recTick = object : Runnable {
        override fun run() {
            updateRecordingTimer()
            if (recShown) handler.postDelayed(this, 1000L)
        }
    }
    private val hideControlsRunnable = Runnable { controlsLayer.visibility = View.GONE }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    private val bgImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && ::audio.isInitialized) audio.onImagePicked(uri)
    }

    private val subtitleLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) importSubtitle(uri)
    }

    // ================================================================== lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        bindViews()
        AppState.stopListeners.add(stopListener)
        panelsRoot.post { applyLayoutPrefs() }
        panelsRoot.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) applyLayoutPrefs()
        }
        setupStage()
        setupAudio()
        setupSubtitles()
        setupGestures()
        setupOrbit()
        setupLists()
        setupButtons()
        setupExtras()
        setupBackHandling()
        vlc.onError = { onPlayError() }
        vlc.onVout = {
            if (redrawOnFirstFrame) {
                redrawOnFirstFrame = false
                refreshVideoSurface()
            }
        }
        SoundFx.vlcSink = { gains, pre -> vlc.setEqualizer(gains, pre) }
        vlc.onPlaying = {
            SoundFx.reapplyVlc()
            autoSkipRemaining = 0
            reconnectAttempts = 0
            handler.removeCallbacks(watchdog)
            playedOnce = true
            prefetchNeighbours()
            updatePlayIcon()
        }

        listsSignature = prefs.listsSignature()

        val missing = Permissions.missing(this)
        if (missing.isNotEmpty()) permissionLauncher.launch(missing)

        // the section and the channel of the last session come back; the chosen subscription stays the source
        val startId = restorableCatalog(prefs.lastCatalogId) ?: homeCatalogId()
        val startTitle = if (startId == prefs.lastCatalogId && prefs.lastCatalogTitle.isNotBlank()) prefs.lastCatalogTitle
        else homeCatalogTitle()
        orbit.selectedId = orbitIdFor(startId)
        openCatalog(
            startId, startTitle, autoPlay = true,
            selectTag = if (startId == prefs.lastCatalogId) prefs.lastPkgTag.ifEmpty { null } else null
        )
        showControls()
        startAutoUpdater()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        connectController()
        stage.onHostStart()
        if (vlcActive) {
            attachVlc()
            vlc.resume()
        }
        RecordingService.listener = { recording, path -> onRecordingState(recording, path) }
        if (RecordingService.active) showRecording(true)
        handler.removeCallbacks(progressTick)
        handler.postDelayed(progressTick, 5000L)
        if (stoppedByBackground) {
            // back from the background: the same channel / movie / station continues at once
            stoppedByBackground = false
            val channel = nowPlaying
            if (channel != null) {
                val key = progressKey ?: channel.url
                if (!nowAudio && prefs.resumePosition(key) > 0L && !prefs.isWatched(key)) startPositionMs = prefs.resumePosition(key)
                else if (nowAudio) prefs.quranResume()?.takeIf { it.url == channel.url }?.let { startPositionMs = it.positionMs }
                pendingProgressKey = progressKey
                handler.post { if (!isFinishing && !isDestroyed) play(channel, audioOverride = nowAudio) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        panelsRoot.post { applyLayoutPrefs() }
        applyMainBackground()
        // came back from Settings / My lists: reload when a list, an account or the User-Agent changed
        val pending = prefs.pendingCatalog
        if (pending.isNotEmpty()) {
            // a subscription was activated in "My subscription": open it
            prefs.pendingCatalog = ""
            listsSignature = prefs.listsSignature()
            PlaylistRepository.clearCache()
            val title = Catalog.sections(prefs).firstOrNull { it.id == pending }?.title ?: "البث المباشر"
            openCatalog(pending, title)
        }
        val signature = prefs.listsSignature()
        if (signature != listsSignature) {
            listsSignature = signature
            PlaylistRepository.clearCache()
            openCatalog(catalogId, catalogTitle, selectTag = currentPkgTag)
        }
        // the player engine was changed in Settings
        val url = nowUrl
        val channel = nowPlaying
        if (!nowAudio && url != null && channel != null && (prefs.useVlc || isVodContent(channel)) != vlcActive) {
            startOnEngine(channel, url)
        }
        subtitles.applyStyle()
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(progressTick)
        saveProgressNow()
        // the app was left (home button, another app, closed): no sound may stay behind
        if (!AppState.inForeground && !isChangingConfigurations && !AppState.keepAudio) {
            if (nowPlaying != null) stoppedByBackground = true
            stopAllPlayers()
        }
        playerView.player = null
        stage.bigView.player = null
        stage.onHostStop()
        if (vlcActive) {
            vlc.pause()
            vlc.attach(null)
        }
        RecordingService.listener = null
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
    }

    override fun onDestroy() {
        AppState.stopListeners.remove(stopListener)
        handler.removeCallbacksAndMessages(null)
        if (isFinishing) {
            // closing the app: stop and free ExoPlayer, LibVLC and the background service player
            stopAllPlayers()
            PlaybackService.instance?.stopPlayback()
        }
        if (::extras.isInitialized) extras.release()
        audio.release()
        stage.release()
        vlc.release()
        super.onDestroy()
    }

    /** Picture chosen in Settings instead of the black star background ("" = the default look). */
    private fun applyMainBackground() {
        val image = findViewById<ImageView>(R.id.mainBg)
        val cosmic = findViewById<View>(R.id.cosmicBg)
        val scrim = findViewById<View>(R.id.mainBgScrim)
        val value = prefs.mainBg
        if (value == shownMainBg) return
        shownMainBg = value
        val drawable = Backgrounds.load(value)
        if (drawable == null) {
            image.visibility = View.GONE
            scrim.visibility = View.GONE
            cosmic.visibility = View.VISIBLE
        } else {
            image.setImageDrawable(drawable)
            image.visibility = View.VISIBLE
            scrim.visibility = View.VISIBLE
            cosmic.visibility = View.GONE
        }
    }

    private var shownMainBg: String? = null

    /** Stops every video / audio player of the app at once (ExoPlayer, the dual screen and LibVLC). */
    private fun stopAllPlayers() {
        handler.removeCallbacks(watchdog)
        saveProgressNow()
        try {
            controller?.let {
                it.playWhenReady = false
                it.stop()
                it.clearMediaItems()
            }
        } catch (_: Exception) {
        }
        try {
            vlc.stop()
        } catch (_: Exception) {
        }
        try {
            stage.onHostStop()
        } catch (_: Exception) {
        }
        try {
            playerView.player?.stop()
        } catch (_: Exception) {
        }
        updatePlayIcon()
    }

    /** Remembers the second of the running movie / episode (live channels and audio are not saved). */
    private fun saveProgressNow() {
        val channel = nowPlaying ?: return
        if (nowAudio) return
        val position: Long
        val duration: Long
        if (vlcActive) {
            position = vlc.position()
            duration = vlc.duration()
        } else {
            val c = controller ?: return
            if (c.isCurrentMediaItemLive || c.mediaItemCount == 0) return
            position = c.currentPosition
            duration = if (c.duration == C.TIME_UNSET) 0L else c.duration
        }
        if (duration < 120_000L || position < 5_000L) return
        prefs.saveProgress(progressKey ?: channel.url, position, duration)
    }

    /**
     * Applies the size and the place of the two blocks chosen in Settings -> Customise the main
     * screen: the live screen with its orbit, and the sections + channels lists.
     */
    private fun applyLayoutPrefs() {
        val w = panelsRoot.width - panelsRoot.paddingLeft - panelsRoot.paddingRight
        val h = panelsRoot.height - panelsRoot.paddingTop - panelsRoot.paddingBottom
        if (w <= 0 || h <= 0) return
        val sw = (w * prefs.stageWidthPct / 100f).toInt()
        val sh = (h * prefs.stageHeightPct / 100f).toInt()
        val lw = (w * prefs.listWidthPct / 100f).toInt()
        val lh = (h * prefs.listHeightPct / 100f).toInt()
        fun x(side: Int, width: Int): Int = when (side) {
            0 -> 0
            2 -> w - width
            else -> (w - width) / 2
        }
        val sx = x(prefs.stageSide, sw)
        var lx = x(prefs.listSide, lw)
        // both blocks asked for the same place: the lists go next to the live screen
        if (sx < lx + lw && lx < sx + sw) {
            lx = if (w - (sx + sw) >= sx) (sx + sw).coerceAtMost(w - lw) else (sx - lw).coerceAtLeast(0)
        }
        place(orbit, sx, (h - sh) / 2, sw, sh)
        place(listPanel, lx, (h - lh) / 2, lw, lh)
        listPanel.background?.mutate()?.alpha = (255 * prefs.listAlphaPct / 100f).toInt()
    }

    private fun place(view: View, left: Int, top: Int, width: Int, height: Int) {
        val lp = (view.layoutParams as? FrameLayout.LayoutParams) ?: FrameLayout.LayoutParams(width, height)
        if (lp.width == width && lp.height == height && lp.leftMargin == left && lp.topMargin == top) return
        lp.width = width
        lp.height = height
        lp.leftMargin = left
        lp.topMargin = top
        lp.gravity = android.view.Gravity.TOP or android.view.Gravity.START
        view.layoutParams = lp
    }

    /** A touch on the player keeps its bar open; every touch keeps the dual screen overlay open. */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean = try { safeDispatch(ev) } catch (_: Throwable) { true }

    private fun safeDispatch(ev: MotionEvent): Boolean {
        stage.touch()
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && controlsLayer.visibility == View.VISIBLE) {
            val rect = Rect()
            if (playerFrame.getGlobalVisibleRect(rect) && rect.contains(ev.rawX.toInt(), ev.rawY.toInt())) {
                showControls()
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    // ================================================================== setup

    private fun bindViews() {
        orbit = findViewById(R.id.orbit)
        panelsRoot = findViewById(R.id.panelsRoot)
        listPanel = findViewById(R.id.listPanel)
        playerFrame = findViewById(R.id.playerFrame)
        playerView = findViewById(R.id.playerView)
        vlcView = findViewById(R.id.vlcView)
        controlsLayer = findViewById(R.id.controlsLayer)
        btnPlay = findViewById(R.id.btnPlay)
        btnRecord = findViewById(R.id.btnRecord)
        btnQuality = findViewById(R.id.btnQuality)
        btnEngine = findViewById(R.id.btnEngine)
        btnSub = findViewById(R.id.btnSub)
        btnDual = findViewById(R.id.btnDual)
        btnFullscreen = findViewById(R.id.btnFullscreen)
        tvRec = findViewById(R.id.tvRec)
        tvIndicator = findViewById(R.id.tvIndicator)
        tvNowPlaying = findViewById(R.id.tvNowPlaying)
        findViewById<View>(R.id.btnSource).setOnClickListener { showSourceDialog() }
        sourceChipLive = findViewById<TextView>(R.id.btnSourceLive).also { chip ->
            chip.setOnClickListener { showSourceDialog() }
        }
        tvListTitle = findViewById(R.id.tvListTitle)
        tvSectionTitle = findViewById(R.id.tvSectionTitle)
        searchBar = findViewById(R.id.searchBar)
        etSearch = findViewById(R.id.etSearch)
        btnBack = findViewById(R.id.btnBack)
        list = findViewById(R.id.list)
        sectionList = findViewById(R.id.sectionList)
    }

    /** Length of the running movie in ms (0 = live stream / unknown). */
    private fun vodDurationMs(): Long {
        if (vlcActive) return vlc.duration()
        val c = controller ?: return 0L
        if (c.isCurrentMediaItemLive) return 0L
        val d = c.duration
        return if (d == androidx.media3.common.C.TIME_UNSET || d < 0L) 0L else d
    }

    private fun vodPositionMs(): Long =
        if (vlcActive) vlc.position() else (controller?.currentPosition ?: 0L)

    /** Movies and series (not live TV): played by LibVLC, whose audio decoder handles AC3 / EAC3 / DTS cleanly. */
    private fun isVodContent(channel: Channel): Boolean {
        if (nowAudio) return false
        if (progressKey != null) return true
        if (catalogId == "x_vod" || catalogId == "x_series") return true
        if (channel.seriesId.isNotEmpty() || channel.infoId.isNotEmpty()) return true
        val u = channel.url.lowercase()
        return u.contains("/movie/") || u.contains("/series/") || Regex("\\.(mp4|mkv|avi|mov)(\\?|$)").containsMatchIn(u)
    }

    private fun setupStage() {
        stage = StageController(
            activity = this,
            root = findViewById(R.id.stageRoot),
            prefs = prefs,
            indicator = tvIndicator,
            host = object : StageController.Host {
                override fun bigChannel(): Channel? = nowPlaying

                override fun playBig(channel: Channel) {
                    play(channel)
                }

                override fun moveBig(toStage: Boolean) {
                    setFloatingBackVisible(!toStage) // full screen video: no back button except the toolbar one
                    if (vlcActive) {
                        attachVlc()
                    } else {
                        val c = controller ?: return
                        if (toStage) {
                            PlayerView.switchTargetView(c, playerView, stage.bigView)
                        } else {
                            PlayerView.switchTargetView(c, stage.bigView, playerView)
                        }
                    }
                }

                override fun qualityEntries(): List<Pair<String, () -> Unit>> = buildQualityEntries()

                override fun autoQuality() {
                    this@MainActivity.autoQuality()
                }

                override fun toggleEngine(): String = switchEngine()

                override fun onAspectChanged(mode: Int) {
                    vlc.applyAspect(mode, resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
                }

                override fun togglePlayPause() {
                    this@MainActivity.togglePlayPause()
                }

                override fun recordPause() {
                    if (RecordingService.active && !RecordingService.paused) { RecordingService.pause(this@MainActivity); toast("⏸ أُوقف التسجيل مؤقتاً") }
                    handler.postDelayed({ updateRecordingTimer() }, 300L)
                }

                override fun recordResume() {
                    if (RecordingService.paused) { RecordingService.resume(this@MainActivity); toast("● استؤنف التسجيل في الملف نفسه") }
                    handler.postDelayed({ updateRecordingTimer() }, 300L)
                }

                override fun recordStop() {
                    if (RecordingService.active) { RecordingService.stop(this@MainActivity); toast("جارٍ إيقاف التسجيل وحفظ الفيديو المدمج…") }
                }

                override fun toggleRecording() {
                    this@MainActivity.toggleRecording()
                }

                override fun openSubtitles() {
                    subtitles.show()
                }

                override fun onStageClosed() {
                    enterImmersive()
                }

                override fun openSourceSwitcher() {
                    showSourceDialog()
                }

                override fun isVod(): Boolean = !nowAudio && nowPlaying != null && vodDurationMs() > 0L

                override fun positionMs(): Long = vodPositionMs()

                override fun durationMs(): Long = vodDurationMs()

                override fun seekToMs(ms: Long) {
                    if (vlcActive) vlc.seekTo(ms) else controller?.seekTo(ms)
                }
            }
        )
    }

    private fun setupAudio() {
        audio = AudioPanel(
            root = findViewById(R.id.audioRoot),
            host = object : AudioPanel.Host {
                override fun controller(): Player? = this@MainActivity.controller
                override fun requestImagePick() { bgImageLauncher.launch("image/*") }
                override fun next() = playRelative(+1)
                override fun previous() = playRelative(-1)
                override fun toggleRecord() = this@MainActivity.toggleRecording()
                override fun onMuteChanged(muted: Boolean) {
                    controller?.volume = if (muted) 0f else 1f
                }

                override fun onClosed() {
                    enterImmersive()
                }

                override fun onSectionRow(row: Row) = onSectionRowClick(row)
                override fun onChannelRow(row: Row) = onChannelRowClick(row)
                override fun onStarRow(row: Row) = onStarClick(row)
                override fun isFavorite(channel: Channel): Boolean = prefs.isFavorite(channel.url)
                override fun onListsOpened() = pushAudioLists()
                override fun openReciter(id: String, title: String) {
                    openCatalogIfNeeded("quran")
                    selectSectionRow(Row(title = title, leading = "🎙", tag = "p|quran|$id"), autoPlay = false)
                }
            }
        )
    }

    private fun openCatalogIfNeeded(id: String) {
        if (catalogId != id) openCatalog(id, "إذاعات القرآن الكريم")
    }

    /** Offers to continue the last recitation from the exact second where it stopped. */
    private fun maybeResumeQuran() {
        if (nowPlaying != null || audio.isVisible) return // the last session was already restored
        val r = prefs.quranResume() ?: return
        if (r.positionMs < 3000L) return
        val seconds = r.positionMs / 1000
        val where = "%d:%02d".format(seconds / 60, seconds % 60)
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this, R.style.GoldDialog)
            .setTitle("متابعة التلاوة")
            .setMessage("${r.title}\n${r.group}\nمن الدقيقة $where")
            .setPositiveButton("متابعة") { _, _ ->
                startPositionMs = r.positionMs
                play(Channel(name = r.title, url = r.url, group = r.group))
            }
            .setNegativeButton("لاحقاً", null)
            .create()
        showImmersive(dialog)
    }

    /** Copies the current sections / stations into the floating window of the audio player. */
    private fun pushAudioLists() {
        audio.setSections(sectionAdapter.rowsSnapshot(), tvSectionTitle.text.toString())
        audio.setSelectedSection(currentPkgTag)
        audio.setChannels(adapter.rowsSnapshot(), tvListTitle.text.toString())
        audio.setPlayingUrl(nowUrl)
    }

    private fun setupSubtitles() {
        subtitles = SubtitleController(
            activity = this,
            prefs = prefs,
            host = object : SubtitleController.Host {
                override fun exoPlayer(): Player? = controller
                override fun vlcEngine(): VlcEngine = vlc
                override fun isVlc(): Boolean = vlcActive
                override fun subtitleViews(): List<Pair<PlayerView, Float>> =
                    listOf(playerView to 0.8f, stage.bigView to 1f)

                override fun pickSubtitleFile() {
                    subtitleLauncher.launch("*/*")
                }
            }
        )
        vlc.subtitleOptions = subtitles.vlcOptions()
        subtitles.applyStyle()
    }

    /** Volume (right half) / brightness (left half) swipes. A tap only shows / hides the player bar. */
    private fun setupGestures() {
        playerView.setOnTouchListener(PlayerGestures(this, tvIndicator) { toggleControls() })
        vlcView.setOnTouchListener(PlayerGestures(this, tvIndicator) { toggleControls() })
    }

    private fun setupOrbit() {
        orbit.items = listOf(
            OrbitLayout.Item("live", "البث المباشر", R.drawable.ic_live),
            OrbitLayout.Item("fav", "المفضلة", R.drawable.ic_star),
            OrbitLayout.Item("movies", "الأفلام", R.drawable.ic_film),
            OrbitLayout.Item("series", "المسلسلات", R.drawable.ic_tv),
            OrbitLayout.Item("quran", "القرآن الكريم", R.drawable.ic_quran),
            OrbitLayout.Item("radio", "الراديو", R.drawable.ic_radio),
            OrbitLayout.Item("songs", "الأغاني", R.drawable.ic_music),
            OrbitLayout.Item("iptv", "قنوات مجانية", R.drawable.ic_globe),
            OrbitLayout.Item("lists", "قوائمي", R.drawable.ic_folder),
            OrbitLayout.Item("recs", "التسجيلات", R.drawable.ic_record),
            OrbitLayout.Item("search", "بحث", R.drawable.ic_search),
            OrbitLayout.Item("refresh", "تحديث", R.drawable.ic_refresh),
            OrbitLayout.Item("ai", "المساعد الذكي", R.drawable.ic_ai),
            OrbitLayout.Item("subs", "اشتراكي", R.drawable.ic_server),
            OrbitLayout.Item("share", "مشاركة التطبيق", R.drawable.ic_share),
            OrbitLayout.Item("settings", "الإعدادات", R.drawable.ic_settings)
        )
        orbit.selectedId = "live"
        orbit.onItemClick = { item -> onOrbitClick(item.id) }
    }

    private fun onOrbitClick(id: String) {
        when (id) {
            "live" -> {
                // the live section of the CHOSEN subscription (the free list only when it is the chosen one)
                orbit.selectedId = id
                openCatalog(homeCatalogId(), homeCatalogTitle())
            }
            "radio" -> {
                orbit.selectedId = id
                openCatalog("radio", "الراديو")
            }
            "quran" -> {
                orbit.selectedId = id
                openCatalog("quran", "القرآن الكريم")
            }
            "iptv" -> {
                orbit.selectedId = id
                openCatalog("iptvorg", "قنوات مجانية عالمية (iptv-org)")
            }
            "movies", "series" -> {
                // pause what is playing, then open the separate movies / series page
                controller?.pause()
                if (vlcActive) vlc.pause()
                startActivity(Intent(this, MoviesActivity::class.java).putExtra(MoviesActivity.EXTRA_KIND, id))
            }
            "fav" -> startActivity(Intent(this, FavoritesActivity::class.java))
            "lists" -> startActivity(Intent(this, MyListsActivity::class.java))
            "search" -> showSearch()
            "refresh" -> updateNow()
            "ai" -> startActivity(Intent(this, AssistantActivity::class.java))
            "recs" -> startActivity(Intent(this, RecordingsActivity::class.java))
            "subs" -> startActivity(Intent(this, SubscriptionsActivity::class.java))
            "songs" -> {
                stopAllPlayersQuiet()
                startActivity(Intent(this, SongsActivity::class.java))
            }
            "share" -> ShareApp.share(this)
            "settings" -> startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun setupLists() {
        adapter = RowAdapter(
            onClick = { row -> onChannelRowClick(row) },
            onStar = { row -> onStarClick(row) },
            isFavorite = { channel -> prefs.isFavorite(channel.url) }
        )
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        list.itemAnimator = null

        sectionAdapter = RowAdapter(
            onClick = { row -> onSectionRowClick(row) },
            onStar = { },
            isFavorite = { false }
        )
        sectionList.layoutManager = LinearLayoutManager(this)
        sectionList.adapter = sectionAdapter
        sectionList.itemAnimator = null
    }

    private fun setupButtons() {
        btnPlay.setOnClickListener {
            togglePlayPause()
            showControls()
        }
        btnRecord.setOnClickListener {
            toggleRecording()
            showControls()
        }
        btnQuality.setOnClickListener { showQualityDialog() }
        btnEngine.setOnClickListener { toast("المشغل الحالي: " + switchEngine()) }
        btnSub.setOnClickListener { subtitles.show() }
        btnDual.setOnClickListener { stage.open(dual = true) }
        btnFullscreen.setOnClickListener {
            val channel = nowPlaying
            if (nowAudio && channel != null) {
                audio.show(channel.name, channel.group, catalogId == "quran", channel.logo, nowUrl ?: channel.url)
            } else {
                stage.open(dual = false)
            }
        }
        tvNowPlaying.setOnClickListener {
            val channel = nowPlaying
            if (nowAudio && channel != null) audio.show(channel.name, channel.group, catalogId == "quran", channel.logo, nowUrl ?: channel.url)
        }
        btnBack.setOnClickListener { goBack() }

        findViewById<View>(R.id.btnSearchClose).setOnClickListener { closeSearch() }
        etSearch.doAfterTextChanged { applyFilter() }
        etSearch.setOnEditorActionListener { view, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(view.windowToken, 0)
                enterImmersive()
                globalSearch(etSearch.text?.toString().orEmpty())
                true
            } else {
                false
            }
        }
    }

    // ================================================================== extra player tools

    private fun setupExtras() {
        extras = PlayerExtras(this, prefs, object : PlayerExtras.Host {
            override fun nowChannel(): Channel? = nowPlaying
            override fun streamUrl(): String? = nowUrl
            override fun previousChannel(): Channel? = prevChannel
            override fun playChannel(channel: Channel) = play(channel)
            override fun currentRowsChannels(): List<Channel> = currentRows.mapNotNull { it.channel }
            override fun isVlc(): Boolean = vlcActive
            override fun vlc(): VlcEngine = this@MainActivity.vlc
            override fun controller(): Player? = this@MainActivity.controller
            override fun snapshotRoot(): View? =
                if (stage.isOpen) (if (vlcActive) stage.vlcView else stage.bigView)
                else (if (vlcActive) vlcView else playerView)

            override fun hideChrome(hidden: Boolean) {
                val a = if (hidden) 0f else 1f
                controlsLayer.alpha = a
                findViewById<View>(R.id.overlayRoot)?.alpha = a
            }

            override fun onTranslationPanel(open: Boolean) {
                if (open && stage.isOpen) stage.dismissOverlay()
                listPanel.visibility = if (open) View.INVISIBLE else View.VISIBLE
            }

            override fun openLayoutAdjust() {
                val onStage = stage.isOpen
                LayoutAdjust.show(this@MainActivity, onStage) {
                    if (onStage) stage.layoutPanel() else applyLayoutPrefs()
                }
            }

            override fun rootFrame(): FrameLayout = findViewById(R.id.root)
            override fun replayCurrent() {
                nowPlaying?.let { play(it, nowAudio) }
            }

            override fun ensureMedia3(then: () -> Unit) {
                if (!vlcActive && !prefs.useVlc) {
                    then()
                    return
                }
                // one tap: switch the player to Media3 and continue with the same channel
                prefs.playerEngine = "exo"
                val channel = nowPlaying
                val url = nowUrl
                if (channel != null && url != null) startOnEngine(channel, url)
                handler.postDelayed({ then() }, 1500L)
            }

            override fun toast(text: String) = this@MainActivity.toast(text)
        })
        val dp = resources.displayMetrics.density
        // the strip inside the live rectangle (under the title line)
        (controlsLayer as? FrameLayout)?.addView(
            extras.buildStrip(30),
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                android.view.Gravity.TOP
            ).apply { topMargin = (24 * dp).toInt() }
        )
        // the same buttons in the full screen player: placed in the top / bottom bar by the user's layout
        stage.arrangeButtons(extras.buildButtons(40))
        extras.restoreInfo()
    }

    private fun setupBackHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    audio.isVisible -> audio.hide()
                    stage.isOpen -> stage.onBack()
                    searchBar.visibility == View.VISIBLE -> closeSearch()
                    returnIntents.isNotEmpty() -> {
                        // step back to the movie / series page the playback was started from
                        val pages = returnIntents
                        returnIntents = emptyList()
                        stopAllPlayers()
                        startActivities(pages.toTypedArray())
                    }
                    backStack.isNotEmpty() -> goBack()
                    catalogId != homeCatalogId() -> {
                        // step back to the home page first: the app is never closed by one press
                        orbit.selectedId = "live"
                        openCatalog(homeCatalogId(), homeCatalogTitle())
                    }
                    else -> {
                        val now = android.os.SystemClock.elapsedRealtime()
                        if (now - lastBackPress < 2000L) {
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                        } else {
                            lastBackPress = now
                            toast("اضغط رجوع مرة أخرى للخروج من التطبيق")
                        }
                    }
                }
            }
        })
    }

    // ================================================================== player bar (auto hide after 5 s)

    private fun showControls() {
        controlsLayer.visibility = View.VISIBLE
        handler.removeCallbacks(hideControlsRunnable)
        handler.postDelayed(hideControlsRunnable, CONTROLS_TIMEOUT_MS)
    }

    private fun toggleControls() {
        if (controlsLayer.visibility == View.VISIBLE) {
            handler.removeCallbacks(hideControlsRunnable)
            controlsLayer.visibility = View.GONE
        } else {
            showControls()
        }
    }

    private fun updatePlayIcon() {
        val playing = if (vlcActive) vlc.isPlaying
        else controller?.let { it.isPlaying || it.playWhenReady } == true
        btnPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    // ================================================================== automatic / manual update

    /** Background update of every section: first after 20 s, then every 30 minutes. */
    private fun startAutoUpdater() {
        lifecycleScope.launch {
            delay(AutoUpdater.FIRST_DELAY_MS)
            while (true) {
                runUpdate(manual = false)
                delay(AutoUpdater.INTERVAL_MS)
            }
        }
    }

    /** The "Update" icon of the orbit: immediate update of all sections, then the lists are reloaded. */
    private fun updateNow() {
        toast("جارٍ تحديث جميع الأقسام…")
        lifecycleScope.launch { runUpdate(manual = true) }
    }

    private suspend fun runUpdate(manual: Boolean) {
        val updated = try {
            AutoUpdater.refreshAll(prefs)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            0
        }
        PlaylistRepository.clearCache()
        if (manual) {
            openCatalog(catalogId, catalogTitle, selectTag = currentPkgTag)
            toast(if (updated > 0) "تم التحديث ($updated مصدر)" else "تعذر التحديث — تحقق من الإنترنت")
        }
    }

    // ================================================================== player connection

    private fun connectController() {
        if (controller != null || controllerFuture != null) return
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(playerListener)
                if (!vlcActive) (if (stage.isOpen) stage.bigView else playerView).player = c
                subtitles.applyStyle()

                val pending = pendingChannel
                if (pending != null) {
                    pendingChannel = null
                    val url = nowUrl
                    if (url != null) startOnEngine(pending, url)
                } else {
                    c.currentMediaItem?.mediaMetadata?.title?.let { if (nowPlaying == null) tvNowPlaying.text = it }
                }
                updatePlayIcon()
            } catch (e: Exception) {
                toast("تعذر تشغيل خدمة المشغل")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private var redrawOnFirstFrame = false

    /** Runs [block] when the video surface of the screen is laid out and valid (max. 3 s of waiting). */
    private fun whenSurfaceReady(block: () -> Unit) {
        var tries = 0
        fun ready(): Boolean {
            if (stage.isOpen) return true
            if (vlcActive || prefs.useVlc) return vlcView.isAttachedToWindow && vlcView.width > 0 && vlcView.height > 0
            val surface = playerView.videoSurfaceView
            val valid = when (surface) {
                is android.view.SurfaceView -> surface.holder.surface.isValid
                else -> surface != null && surface.isAttachedToWindow
            }
            return playerView.isAttachedToWindow && playerView.width > 0 && playerView.height > 0 && valid
        }
        val check = object : Runnable {
            override fun run() {
                if (isFinishing || isDestroyed) return
                if (ready() || ++tries > 30) block() else handler.postDelayed(this, 100L)
            }
        }
        handler.post(check)
    }

    /** Forces the picture to be drawn: the surface of the running engine is re-created once. */
    private fun refreshVideoSurface() {
        try {
            val target: View? = when {
                vlcActive -> if (stage.isOpen) stage.vlcView else vlcView
                else -> (if (stage.isOpen) stage.bigView else playerView).videoSurfaceView
            }
            target?.let { v ->
                v.visibility = View.INVISIBLE
                v.post { v.visibility = View.VISIBLE; v.requestLayout(); v.invalidate() }
            }
            if (!vlcActive) (if (stage.isOpen) stage.bigView else playerView).let { it.requestLayout(); it.invalidate() }
        } catch (_: Throwable) {
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onRenderedFirstFrame() {
            if (redrawOnFirstFrame) {
                redrawOnFirstFrame = false
                refreshVideoSurface()
            }
        }

        override fun onCues(cueGroup: androidx.media3.common.text.CueGroup) {
            val text = cueGroup.cues.mapNotNull { it.text?.toString() }.joinToString(" ").trim()
            if (text.isNotEmpty() && ::extras.isInitialized) extras.subs.onEmbeddedCue(text)
        }

        override fun onPlayerError(error: PlaybackException) {
            onPlayError()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            when (playbackState) {
                Player.STATE_READY -> handler.removeCallbacks(watchdog)
                // the stream stopped delivering data: the alternative is tried after 3 seconds
                Player.STATE_BUFFERING -> if (playedOnce) armWatchdog(STALL_MS)
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) {
                autoSkipRemaining = 0
                reconnectAttempts = 0
                handler.removeCallbacks(watchdog)
                playedOnce = true
                prefetchNeighbours()
            }
            updatePlayIcon()
        }
    }

    /** Anti-freeze: reconnect at once (up to 5 times), only then skip to the next channel. */
    private fun onPlayError() {
        // a live channel that failed: after one quick retry the alternative source takes over
        if (isLiveContext() && reconnectAttempts >= 1 && altSearchedFor != nowUrl) {
            switchToAlternative()
            return
        }
        if (nowPlaying != null && nowUrl != null && reconnectAttempts < MAX_RECONNECT) {
            reconnectAttempts++
            handler.postDelayed({ reconnect() }, 600L * reconnectAttempts)
            return
        }
        reconnectAttempts = 0
        if (autoSkipRemaining > 0) {
            autoSkipRemaining--
            playRelative(+1)
        } else {
            toast("تعذر تشغيل: ${nowPlaying?.name ?: ""}")
        }
    }

    // ------------------------------------------------------------------ zapping + alternative channel

    /** True while a live TV channel (not a radio, movie or episode) is playing. */
    private fun isLiveContext(): Boolean {
        val channel = nowPlaying ?: return false
        val url = nowUrl ?: return false
        if (nowAudio || progressKey != null) return false
        if (url.contains("/movie/") || url.contains("/series/") || channel.seriesId.isNotEmpty()) return false
        return true
    }

    private fun armWatchdog(delayMs: Long) {
        if (!isLiveContext() || switching) return
        handler.removeCallbacks(watchdog)
        handler.postDelayed(watchdog, delayMs)
    }

    private fun isReallyPlaying(): Boolean =
        if (vlcActive) vlc.isPlaying else controller?.let { it.isPlaying || !it.playWhenReady } ?: false

    private fun onStreamStalled() {
        if (!isLiveContext() || isReallyPlaying()) return
        // auto-reconnect first (same channel); only when that keeps failing the alternative source takes over
        if (reconnectAttempts < 2 && nowPlaying != null && nowUrl != null) {
            reconnectAttempts++
            reconnect()
            return
        }
        switchToAlternative()
    }

    /** Looks (in the background) for the same channel in another quality / source and plays it. */
    private fun switchToAlternative() {
        val channel = nowPlaying ?: return
        if (switching) return
        switching = true
        altSearchedFor = nowUrl
        triedAlternatives.add(channel.url)
        lifecycleScope.launch {
            try {
                val alt = StreamAlternatives.find(
                    prefs, channel, triedAlternatives, currentRows.mapNotNull { it.channel }
                )
                if (alt == null) {
                    // nothing better: the normal reconnect / skip logic goes on
                    switching = false
                    reconnectAttempts = 0
                    onPlayError()
                    return@launch
                }
                val url = Catalog.resolve(prefs, alt)
                triedAlternatives.add(alt.url)
                nowPlaying = alt
                nowUrl = url
                tvNowPlaying.text = alt.name
                adapter.playingUrl = alt.url
                reconnectAttempts = 0
                playedOnce = false
                startOnEngine(alt, url)
                showPill("تم التحويل تلقائياً للبث البديل المستقر")
                armWatchdog(START_GRACE_MS)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            } finally {
                switching = false
            }
        }
    }

    /** Warms up the next and the previous channel of the list so zapping starts in under a second. */
    private fun prefetchNeighbours() {
        if (!isLiveContext()) return
        val current = nowPlaying ?: return
        val channels = currentRows.mapNotNull { it.channel }
        val index = channels.indexOfFirst { it.url == current.url }
        if (index < 0) return
        for (target in intArrayOf(index + 1, index - 1)) {
            channels.getOrNull(target)?.let { ZapPrefetcher.warm(it.url) }
        }
    }

    /** Small elegant notice at the top of the screen. */
    private fun showPill(text: String) {
        val root = findViewById<FrameLayout>(R.id.root)
        val view = pill ?: TextView(this).also { tv ->
            tv.setBackgroundResource(R.drawable.bg_overlay)
            tv.setTextColor(getColor(R.color.gold_light))
            tv.textSize = 13f
            tv.gravity = android.view.Gravity.CENTER
            val h = (16 * resources.displayMetrics.density).toInt()
            val v = (8 * resources.displayMetrics.density).toInt()
            tv.setPadding(h, v, h, v)
            tv.layoutDirection = View.LAYOUT_DIRECTION_RTL
            root.addView(
                tv,
                FrameLayout.LayoutParams(-2, -2).apply {
                    gravity = android.view.Gravity.TOP or android.view.Gravity.CENTER_HORIZONTAL
                    topMargin = (18 * resources.displayMetrics.density).toInt()
                }
            )
            UiTheme.apply(tv)
            pill = tv
        }
        view.text = "⚡  $text"
        view.animate().cancel()
        view.alpha = 0f
        view.visibility = View.VISIBLE
        view.animate().alpha(1f).setDuration(250L).withEndAction {
            view.animate().alpha(0f).setStartDelay(3500L).setDuration(500L)
                .withEndAction { view.visibility = View.GONE }.start()
        }.start()
    }

    private fun reconnect() {
        val channel = nowPlaying ?: return
        val url = nowUrl ?: return
        val c = controller
        if (!vlcActive && c != null && c.mediaItemCount > 0) {
            // keeps the position of movies, jumps to the live edge of live streams
            c.prepare()
            c.play()
        } else {
            startOnEngine(channel, url)
        }
    }

    private fun togglePlayPause() {
        if (vlcActive) {
            vlc.togglePlayPause()
        } else {
            controller?.let { if (it.isPlaying || it.playWhenReady) it.pause() else it.play() }
        }
        handler.postDelayed({ updatePlayIcon() }, 250L)
    }

    // ------------------------------------------------------------------ engines

    private fun engineName(): String = Engines.title(prefs.playerEngine)

    /** Media3 <-> LibVLC. The running video continues on the new engine. */
    private fun switchEngine(): String {
        prefs.playerEngine = Engines.next(prefs.playerEngine)
        val channel = nowPlaying
        val url = nowUrl
        if (!nowAudio && channel != null && url != null) startOnEngine(channel, url)
        return engineName()
    }

    private fun stopAllPlayersQuiet() {
        try { controller?.pause() } catch (_: Throwable) {}
        if (vlcActive) vlc.pause()
    }

    private fun stopMainEngines() {
        controller?.let {
            it.stop()
            it.clearMediaItems()
        }
        if (vlcActive || vlc.isPlaying) {
            vlc.stop()
            vlc.attach(null)
        }
        vlcActive = false
    }

    private fun showEngineViews(useVlc: Boolean) {
        playerView.visibility = if (useVlc) View.GONE else View.VISIBLE
        vlcView.visibility = if (useVlc) View.VISIBLE else View.GONE
        stage.showEngineView(useVlc)
    }

    private fun attachVlc() {
        vlc.attach(if (stage.isOpen) stage.vlcView else vlcView)
    }

    /** Starts [url] on the engine chosen in the settings (audio always uses Media3 = background safe). */
    private fun startOnEngine(channel: Channel, url: String) {
        // engines that run outside the main screen: Android MediaPlayer page / external player app
        if (!nowAudio && prefs.playerEngine == Prefs.ENGINE_NATIVE) {
            stopMainEngines()
            startActivity(
                Intent(this, NativePlayerActivity::class.java)
                    .putExtra(NativePlayerActivity.EXTRA_URL, url)
                    .putExtra(NativePlayerActivity.EXTRA_TITLE, channel.name)
                    .putExtra(NativePlayerActivity.EXTRA_AGENT, NetConfig.userAgent())
            )
            return
        }
        if (!nowAudio && prefs.playerEngine == Prefs.ENGINE_EXTERNAL) {
            stopMainEngines()
            try {
                startActivity(
                    Intent.createChooser(
                        Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), "video/*"),
                        "فتح بمشغل خارجي"
                    )
                )
            } catch (e: Exception) {
                toast("لا يوجد مشغل خارجي مثبّت")
            }
            return
        }
        // VOD (films / series) always plays with LibVLC: no crackling AC3 / EAC3 / DTS sound, hardware decoding on
        val useVlc = (prefs.useVlc || isVodContent(channel)) && !nowAudio
        if (useVlc) {
            controller?.let {
                it.stop()
                it.clearMediaItems()
            }
            vlcActive = true
            showEngineViews(true)
            attachVlc()
            vlc.applyAspect(prefs.aspectMode, resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
            vlc.play(url, NetConfig.userAgent(), startPositionMs)
            startPositionMs = 0L
        } else {
            if (vlcActive || vlc.isPlaying) {
                vlc.stop()
                vlc.attach(null)
            }
            vlcActive = false
            showEngineViews(false)
            val c = controller
            if (c == null) {
                pendingChannel = channel
                return
            }
            (if (stage.isOpen) stage.bigView else playerView).player = c
            c.volume = if (nowAudio && audio.muted) 0f else 1f
            c.setMediaItem(buildMediaItem(channel, url), startPositionMs.coerceAtLeast(0L))
            startPositionMs = 0L
            c.prepare()
            c.play()
        }
        updatePlayIcon()
    }

    // ------------------------------------------------------------------ quality

    private fun autoQuality() {
        if (vlcActive) {
            vlc.resetQuality(NetConfig.userAgent())
        } else {
            controller?.let {
                it.trackSelectionParameters = it.trackSelectionParameters.buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                    .setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
                    .build()
            }
        }
    }

    /**
     * Every quality from the lowest to the highest: 360p, 480p, 720p, 1080p, 2K 1440p, 4K 2160p,
     * 8K 4320p. A level the stream really offers is selected directly; for the others the
     * automatic switching (ABR) is capped at that level.
     */
    private fun buildQualityEntries(): List<Pair<String, () -> Unit>> {
        if (vlcActive) {
            return vlc.videoTracks().map { (id, name) -> name to { vlc.selectVideoTrack(id) } }
        }
        val c = controller ?: return emptyList()
        val tracks = ArrayList<Pair<Int, Pair<androidx.media3.common.Tracks.Group, Int>>>()
        for (group in c.currentTracks.groups) {
            if (group.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until group.length) {
                val h = group.getTrackFormat(i).height
                if (h > 0) tracks.add(h to (group to i))
            }
        }
        val ladder = linkedMapOf(
            360 to "360p", 480 to "480p", 720 to "720p HD", 1080 to "1080p Full HD",
            1440 to "2K — 1440p", 2160 to "4K — 2160p", 4320 to "8K — 4320p"
        )
        val heights = (ladder.keys + tracks.map { it.first }).toSortedSet()
        val out = ArrayList<Pair<String, () -> Unit>>()
        for (h in heights) {
            val exact = tracks.firstOrNull { it.first == h }?.second
            val name = ladder[h] ?: "${h}p"
            val label = if (exact != null) "$name  ✓" else "$name  (حد أقصى)"
            out.add(label to {
                val builder = c.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                if (exact != null) {
                    builder.setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
                    builder.setOverrideForType(TrackSelectionOverride(exact.first.mediaTrackGroup, exact.second))
                } else {
                    builder.setMaxVideoSize(h * 16 / 9 + 16, h)
                }
                c.trackSelectionParameters = builder.build()
                toast("الجودة: $name")
            })
        }
        return out
    }

    private fun showQualityDialog() {
        val entries = buildQualityEntries()
        val labels = (listOf("تلقائي (Auto)") + entries.map { it.first }).toTypedArray()
        val dialog = AlertDialog.Builder(this, R.style.GoldDialog)
            .setTitle("جودة البث")
            .setItems(labels) { _, which ->
                if (which == 0) {
                    autoQuality()
                    toast("الجودة: تلقائي (Auto)")
                } else {
                    entries[which - 1].second.invoke()
                }
            }
            .setNegativeButton("إغلاق", null)
            .create()
        showImmersive(dialog)
        showControls()
    }

    // ------------------------------------------------------------------ playing

    private fun isAudioChannel(channel: Channel): Boolean {
        val ext = channel.url.substringBefore('?').substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (ext in setOf("mp3", "aac", "m4a", "ogg", "opus", "pls")) return true
        return catalogId == "radio" || catalogId == "quran"
    }

    /** Plays a channel on the big screen (the sound always belongs to the big screen). */
    private fun play(channel: Channel, audioOverride: Boolean? = null) {
        saveProgressNow()
        progressKey = pendingProgressKey
        pendingProgressKey = null
        if (WebPlayerActivity.isYoutube(channel.url) && WebPlayerActivity.open(this, channel.url)) {
            // official YouTube live channels / videos play inside the app (up to the quality YouTube serves, 4K included)
            stopAllPlayers()
            return
        }
        val isAudio = audioOverride ?: isAudioChannel(channel)
        // State persistence: this channel / movie / station is started again when the app is reopened
        if (restorableCatalog(catalogId) != null) prefs.saveLastPlayed(channel, isAudio, catalogId, progressKey)
        nowPlaying?.let { if (it.url != channel.url) prevChannel = it }
        nowPlaying = channel
        nowUrl = null
        nowAudio = isAudio
        reconnectAttempts = 0
        triedAlternatives.clear()
        altSearchedFor = null
        playedOnce = false
        handler.removeCallbacks(watchdog)
        tvNowPlaying.text = channel.name
        adapter.playingUrl = channel.url
        audio.setPlayingUrl(channel.url)
        stage.onBigChanged()
        showControls()

        if (isAudio) {
            if (stage.isOpen) stage.close()
            if (!audio.isVisible) audio.resetMute()
            audio.show(channel.name, channel.group, catalogId == "quran", channel.logo, nowUrl ?: channel.url)
        } else if (audio.isVisible) {
            audio.hide()
        }

        playJob?.cancel()
        playJob = lifecycleScope.launch {
            val url = try {
                Catalog.resolve(prefs, channel)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast("تعذر فتح القناة: ${e.message ?: e.javaClass.simpleName}")
                return@launch
            }
            nowUrl = url
            startOnEngine(channel, url)
            armWatchdog(START_GRACE_MS)
            extras.onChannelStarted()
        }
    }

    /** Next / previous entry of the channel list (also used by the audio player). */
    private fun playRelative(step: Int) {
        val current = nowPlaying ?: return
        val channels = currentRows.mapNotNull { it.channel }
        val index = channels.indexOfFirst { it.url == current.url }
        val target = index + step
        if (index >= 0 && target in channels.indices) {
            play(channels[target], audioOverride = nowAudio)
        }
    }

    // ================================================================== the two lists

    private fun favoriteKind(): String = when (catalogId) {
        "radio" -> "radio"
        "quran" -> "quran"
        "movies", "x_vod" -> "movie"
        "series", "x_series" -> "series"
        else -> ""
    }

    /**
     * Opens a catalog (live, radio, Quran, a subscription ...): the SECTIONS (groups, countries,
     * reciters, categories) go to the right list, the channels of the selected section to the
     * left list. Both lists scroll independently.
     */
    private fun openCatalog(id: String, title: String, autoPlay: Boolean = false, selectTag: String? = null) {
        catalogId = id
        catalogTitle = title
        currentPkgTag = null
        if (restorableCatalog(id) != null) {
            // State persistence: the open section is remembered (the selected package row is saved below)
            prefs.lastCatalogId = id
            prefs.lastCatalogTitle = title
            prefs.lastPkgTag = selectTag.orEmpty()
        }
        updateSourceButtons()
        returnIntents = emptyList()
        backStack.clear()
        updateBackButton()
        tvSectionTitle.text = title
        tvListTitle.text = getString(R.string.channels_title)
        sectionJob?.cancel()
        channelJob?.cancel()
        sectionAdapter.submit(emptyList())
        setRows(emptyList())

        if (id == "quran" && !audio.isVisible) handler.postDelayed({ if (!isFinishing) maybeResumeQuran() }, 700L)
        sectionJob = lifecycleScope.launch {
            val packages: List<Pkg>? = try {
                Catalog.packages(prefs, id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast("تعذر التحميل: ${e.message ?: e.javaClass.simpleName}")
                null
            }
            val rows = ArrayList<Row>()
            val allTitle = when (id) {
                "radio" -> "المحطات الافتراضية"
                "quran" -> "إذاعات القرآن الكريم"
                else -> "الكل"
            }
            rows.add(Row(title = allTitle, leading = "⭐", tag = "p|$id|${Catalog.ALL}"))
            // one tap: the favourites of this section (saved permanently); the ❤ star of every row adds / removes
            rows.add(Row(title = "❤️  المفضلة", leading = "❤️", tag = "p|$id|${Catalog.FAV}"))

            val arab = DefaultData.arabCountries.map { it.iso }.toSet()
            val list = packages?.filter { it.id != Catalog.ALL } ?: emptyList()
            if (id == "radio") {
                rows.add(Row(title = "🌍  الدول العربية", isHeader = true))
                list.filter { it.id in arab }.forEach { rows.add(pkgRow(id, it)) }
                rows.add(Row(title = "🌐  دول العالم", isHeader = true))
                list.filter { it.id !in arab }.forEach { rows.add(pkgRow(id, it)) }
            } else {
                list.forEach { rows.add(pkgRow(id, it)) }
            }
            if (id == "live") {
                // the countries (Arab first, then the world) live inside the live TV sections
                val countries = try {
                    Catalog.packages(prefs, "countries") ?: emptyList()
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    emptyList()
                }
                rows.add(Row(title = "🌍  الدول العربية", isHeader = true))
                countries.filter { it.id in arab }.forEach { rows.add(pkgRow("countries", it)) }
                rows.add(Row(title = "🌐  دول العالم", isHeader = true))
                countries.filter { it.id !in arab }.forEach { rows.add(pkgRow("countries", it)) }
            }
            sectionAdapter.submit(rows)
            audio.setSections(rows, tvSectionTitle.text.toString())

            val first = rows.firstOrNull { it.tag == selectTag } ?: rows.first { it.tag.startsWith("p|") }
            selectSectionRow(first, autoPlay)
        }
    }

    // ------------------------------------------------------------------ chosen subscription (source)

    /**
     * The "home" live catalog of the subscription the USER chose in "My subscription" / the source button:
     * the built-in free lists ("live"), Xtream ("x_live"), Stalker or one of the M3U lists. The choice is saved
     * and never changes by itself - the app never goes back to the free list unless the user picks it.
     */
    private fun homeCatalogId(): String {
        val active = prefs.activeSub
        return when {
            active == "xtream" && prefs.xtreamConfigured() -> "x_live"
            active == "stalker" && prefs.stalkerConfigured() -> "stalker"
            active.startsWith("m3u:") && prefs.customLists().any { "m3u:${it.id}" == active } -> active
            else -> {
                if (active != "free" && active.isNotEmpty()) prefs.activeSub = "free" // the chosen source was deleted
                "live"
            }
        }
    }

    private fun homeCatalogTitle(): String {
        val id = homeCatalogId()
        return Catalog.sections(prefs).firstOrNull { it.id == id }?.title ?: "البث المباشر"
    }

    /** [id] when that section may be opened again at start (it belongs to the chosen subscription), else null. */
    private fun restorableCatalog(id: String): String? = when {
        id.isEmpty() -> null
        id == "radio" || id == "quran" || id == "iptvorg" || id == "countries" -> id
        id == "live" -> if (homeCatalogId() == "live") id else null
        id == "x_live" || id == "x_vod" || id == "x_series" ->
            if (prefs.activeSub == "xtream" && prefs.xtreamConfigured()) id else null
        id == "stalker" -> if (prefs.activeSub == "stalker" && prefs.stalkerConfigured()) id else null
        id.startsWith("m3u:") -> if (prefs.activeSub == id && homeCatalogId() == id) id else null
        else -> null
    }

    private fun orbitIdFor(catalog: String): String = when (catalog) {
        "radio" -> "radio"
        "quran" -> "quran"
        "iptvorg" -> "iptv"
        else -> "live"
    }

    /** Name of the source shown on the "Current source" buttons. */
    private fun sourceName(): String = when {
        prefs.activeSub == "xtream" && prefs.xtreamConfigured() -> prefs.xtreamName.ifBlank { "اشتراك Xtream" }
        prefs.activeSub == "stalker" && prefs.stalkerConfigured() -> prefs.stalkerName.ifBlank { "Stalker Portal" }
        prefs.activeSub.startsWith("m3u:") ->
            prefs.customLists().firstOrNull { "m3u:${it.id}" == prefs.activeSub }?.name ?: "البث المجاني المدمج"
        else -> "البث المجاني المدمج"
    }

    private fun updateSourceButtons() {
        val label = "📡 المصدر الحالي: " + sourceName()
        (findViewById<TextView?>(R.id.btnSource))?.text = label
        sourceChipLive?.text = "📡 المصدر الحالي"
    }

    private var sourceChipLive: TextView? = null

    /**
     * "Current source" quick switcher: the built-in free stream + every saved Xtream / Stalker subscription +
     * every M3U list or link. One tap switches the whole app to that source and the choice is saved.
     */
    private fun showSourceDialog() {
        val ids = ArrayList<String>()
        val names = ArrayList<String>()
        fun mark(id: String) = if (prefs.activeSub == id) "✔  " else "      "
        ids.add("free"); names.add(mark("free") + "البث المجاني المدمج")
        if (prefs.xtreamConfigured()) { ids.add("xtream"); names.add(mark("xtream") + "Xtream — " + prefs.xtreamName.ifBlank { "اشتراكي" }) }
        if (prefs.stalkerConfigured()) { ids.add("stalker"); names.add(mark("stalker") + "Stalker — " + prefs.stalkerName.ifBlank { "Portal" }) }
        for (item in prefs.customLists()) { ids.add("m3u:${item.id}"); names.add(mark("m3u:${item.id}") + "M3U — " + item.name) }
        val dialog = AlertDialog.Builder(this, R.style.GoldDialog)
            .setTitle("📡 المصدر الحالي — اختر مصدر البث")
            .setItems(names.toTypedArray()) { _, which -> switchSource(ids[which]) }
            .setNeutralButton("إدارة الاشتراكات") { _, _ -> startActivity(Intent(this, SubscriptionsActivity::class.java)) }
            .setNegativeButton("إغلاق", null)
            .create()
        showImmersive(dialog)
        showControls()
    }

    private fun switchSource(id: String) {
        if (stage.isOpen) stage.dismissOverlay()
        prefs.activeSub = id
        listsSignature = prefs.listsSignature()
        PlaylistRepository.clearCache()
        orbit.selectedId = "live"
        openCatalog(homeCatalogId(), homeCatalogTitle())
        toast("✔ المصدر الحالي: " + sourceName())
    }

    private fun pkgRow(catalog: String, pkg: Pkg) =
        Row(title = pkg.title, leading = pkg.leading.ifEmpty { "•" }, tag = "p|$catalog|${pkg.id}")

    private fun onSectionRowClick(row: Row) {
        if (row.tag.startsWith("p|")) selectSectionRow(row, autoPlay = false)
    }

    private fun selectSectionRow(row: Row, autoPlay: Boolean) {
        val parts = row.tag.split('|')
        if (parts.size < 3) return
        val cid = parts[1]
        val pid = parts.drop(2).joinToString("|")
        currentPkgTag = row.tag
        if (restorableCatalog(catalogId) != null) prefs.lastPkgTag = row.tag
        sectionAdapter.selectedTag = row.tag
        audio.setSelectedSection(row.tag)
        tvListTitle.text = row.title
        backStack.clear()
        updateBackButton()

        channelJob?.cancel()
        setRows(emptyList())
        channelJob = lifecycleScope.launch {
            val channels = try {
                Catalog.channels(prefs, cid, if (pid == Catalog.ALL) null else pid)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast("تعذر التحميل: ${e.message ?: e.javaClass.simpleName}")
                return@launch
            }
            // a big list lives in the SQLite database on the disk: only the 30 rows on the screen are in memory
            val rows: List<Row> = if (channels.size >= PAGED_MIN && pid != Catalog.FAV) {
                withContext(Dispatchers.IO) {
                    val key = ChannelDb.key(cid, pid)
                    ChannelDb.replace(key, channels)
                    PagedRows(key, channels.size)
                }
            } else withContext(Dispatchers.Default) { channelRows(channels) }
            setRows(rows)
            if (autoPlay && !firstAutoPlayDone && channels.isNotEmpty()) {
                firstAutoPlayDone = true
                val last = prefs.lastPlayed()?.takeIf { restorableCatalog(it.catalogId) != null }
                if (last != null) {
                    // the channel / movie of the last session comes back at once
                    redrawOnFirstFrame = true
                    pendingProgressKey = last.progressKey.ifEmpty { null }
                    if (!last.audio) {
                        val key = last.progressKey.ifEmpty { last.channel.url }
                        if (prefs.resumePosition(key) > 0L && !prefs.isWatched(key)) startPositionMs = prefs.resumePosition(key)
                    } else {
                        prefs.quranResume()?.takeIf { it.url == last.channel.url }?.let { startPositionMs = it.positionMs }
                    }
                    whenSurfaceReady { play(last.channel, audioOverride = last.audio) }
                } else {
                    autoSkipRemaining = 6 // skip dead channels automatically at start
                    redrawOnFirstFrame = true
                    // wait until the video surface really exists, otherwise the sound starts without a picture
                    whenSurfaceReady { play(channels.first()) }
                }
            }
        }
    }

    /** Xtream series: shows the episodes; "back" returns to the previous list. */
    private fun openSeries(series: Channel) {
        val previousRows = currentRows
        val previousTitle = tvListTitle.text.toString()
        backStack.add {
            tvListTitle.text = previousTitle
            setRows(previousRows)
        }
        tvListTitle.text = series.name
        updateBackButton()
        setRows(emptyList())

        channelJob?.cancel()
        channelJob = lifecycleScope.launch {
            try {
                setRows(channelRows(Catalog.episodes(prefs, series.seriesId)))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast("تعذر تحميل الحلقات: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    private fun onChannelRowClick(row: Row) {
        val channel = row.channel ?: return
        if (channel.seriesId.isNotEmpty()) openSeries(channel) else play(channel)
    }

    private fun onStarClick(row: Row) {
        val channel = row.channel ?: return
        val nowFavorite = prefs.toggleFavorite(channel, favoriteKind())
        adapter.refresh()
        toast(if (nowFavorite) "أُضيفت «${channel.name}» إلى المفضلة" else "أُزيلت «${channel.name}» من المفضلة")
    }

    private fun goBack() {
        if (backStack.isNotEmpty()) {
            val action = backStack.removeAt(backStack.size - 1)
            action()
        }
        updateBackButton()
    }

    private fun updateBackButton() {
        btnBack.visibility = if (backStack.isNotEmpty()) View.VISIBLE else View.GONE
    }

    private fun channelRows(channels: List<Channel>): List<Row> = channels.map {
        Row(title = it.name, subtitle = it.group, leading = "", channel = it)
    }

    private fun setRows(rows: List<Row>) {
        currentRows = rows
        applyFilter()
    }

    private fun applyFilter() {
        val query = if (searchBar.visibility == View.VISIBLE) etSearch.text?.toString()?.trim().orEmpty() else ""
        filterJob?.cancel()
        if (query.isEmpty()) {
            showFiltered(currentRows, query)
            return
        }
        // filtering a big list never blocks the screen: it runs on a background thread
        val source = currentRows
        filterJob = lifecycleScope.launch {
            kotlinx.coroutines.delay(120L)
            if (source is PagedRows) {
                // searching a big list = a database query (all the spellings), never a scan of the memory
                val found = withContext(Dispatchers.IO) {
                    ChannelDb.search(source.key, Aliases.variants(query) + query + ArabicText.normalize(query))
                }
                showFiltered(channelRows(found), query)
                return@launch
            }
            val rows = withContext(Dispatchers.Default) {
                val q = ArabicText.normalize(query)
                source.filter {
                    !it.isHeader && (ArabicText.normalize(it.title).contains(q) || Aliases.matches(it.title, query) ||
                        ArabicText.normalize(it.subtitle).contains(q) ||
                        it.title.contains(query, ignoreCase = true))
                }
            }
            showFiltered(rows, query)
        }
    }

    private fun showFiltered(rows: List<Row>, query: String) {
        adapter.submit(rows)
        audio.setChannels(rows, tvListTitle.text.toString())
        if (catalogId == "radio" && query.length >= 2) radioRemoteSearch(query, rows) else radioSearchJob?.cancel()
    }

    private var radioSearchJob: Job? = null

    /** Radio: while typing, the whole Radio Browser database is searched too (instant, thousands of stations). */
    private fun radioRemoteSearch(query: String, local: List<Row>) {
        radioSearchJob?.cancel()
        radioSearchJob = lifecycleScope.launch {
            kotlinx.coroutines.delay(350L)
            val found = try {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { RadioClient.search(query) }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                return@launch
            }
            if (etSearch.text?.toString()?.trim() != query) return@launch
            val have = local.mapNotNull { it.channel?.url }.toSet()
            adapter.submit(local + channelRows(found.filter { it.url !in have }))
        }
    }

    // ================================================================== search

    /** The search icon of the orbit: opens the search bar and the keyboard (landscape, never full screen). */
    private fun showSearch() {
        searchBar.visibility = View.VISIBLE
        etSearch.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        etSearch.post { imm.showSoftInput(etSearch, InputMethodManager.SHOW_IMPLICIT) }
    }

    private fun closeSearch() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(etSearch.windowToken, 0)
        etSearch.setText("")
        searchBar.visibility = View.GONE
        applyFilter()
        enterImmersive()
    }

    /** Every source at once: favourites, live TV, radio, Quran and the user's lists. */
    private suspend fun searchSources(): List<Pair<String, List<Channel>>> {
        val sources = ArrayList<Pair<String, List<Channel>>>()
        sources.add("fav" to prefs.favorites())
        for (id in listOf("live", "radio", "quran") + Catalog.subscriptions(prefs).map { it.id }) {
            if (id == "x_vod" || id == "x_series" || id == "stalker") continue
            try {
                sources.add(id to Catalog.channels(prefs, id, null))
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            }
        }
        return sources
    }

    /** "Search" key of the keyboard: results of all sources in the channel list. */
    private fun globalSearch(query: String) {
        val wanted = ArabicText.normalize(query)
        if (wanted.isEmpty()) return
        val previousRows = currentRows
        val previousTitle = tvListTitle.text.toString()
        lifecycleScope.launch {
            val found = LinkedHashMap<String, Channel>()
            for ((_, channels) in searchSources()) {
                for (c in channels) {
                    if (ArabicText.normalize(c.name).contains(wanted) || Aliases.matches(c.name, query)) found.putIfAbsent(c.url, c)
                    if (found.size >= 300) break
                }
            }
            backStack.add {
                tvListTitle.text = previousTitle
                setRows(previousRows)
            }
            updateBackButton()
            tvListTitle.text = "نتائج البحث"
            etSearch.setText("")
            setRows(channelRows(found.values.toList()))
            if (found.isEmpty()) toast("لا توجد نتائج لـ «$query»")
            closeSearch()
        }
    }

    // ================================================================== recording

    /** Record / stop for everything: live TV, movies, series and audio. */
    private fun toggleRecording() {
        if (RecordingService.active || recShown) {
            RecordingService.stop(this)
            toast("جارٍ إيقاف التسجيل وحفظه…")
            return
        }
        val channel = nowPlaying
        val url = nowUrl
        if (channel == null || url == null || !url.startsWith("http", ignoreCase = true)) {
            toast("شغّل بثاً أولاً ثم اضغط زر التسجيل")
            return
        }
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE))
            toast("امنح صلاحية التخزين ثم أعد المحاولة")
            return
        }
        RecordingService.start(this, url, channel.name, recordingSource(url))
        recLocalStart = System.currentTimeMillis()
        showRecording(true)
        toast("بدأ تسجيل: ${channel.name}")
    }

    /** live / movie / series / radio / quran - written into the file name and shown as a badge. */
    private fun recordingSource(url: String): String {
        val lower = url.lowercase()
        return when {
            audio.isVisible && catalogId == "quran" -> "quran"
            audio.isVisible || nowAudio -> "radio"
            lower.contains("/series/") -> "series"
            lower.contains("/movie/") || lower.substringBefore('?').let { it.endsWith(".mp4") || it.endsWith(".mkv") || it.endsWith(".avi") } -> "movie"
            else -> "live"
        }
    }

    private fun onRecordingState(recording: Boolean, path: String?) {
        if (recording) {
            showRecording(true)
        } else {
            showRecording(false)
            when {
                path != null -> toast("تم الحفظ في: $path\nوتظهر نسخة منه في معرض الهاتف (Movies / Music › OsoGoldTV)")
                RecordingService.lastMessage != null -> toast(RecordingService.lastMessage!!)
                else -> toast("لم يُحفظ التسجيل (قصير جداً أو تعذر الحفظ)")
            }
        }
    }

    private fun showRecording(on: Boolean) {
        recShown = on
        btnRecord.setImageResource(if (on) R.drawable.ic_stop else R.drawable.ic_record)
        handler.removeCallbacks(recTick)
        if (on) {
            tvRec.visibility = View.VISIBLE
            handler.post(recTick)
        } else {
            tvRec.visibility = View.GONE
            stage.setRecordingText(null)
            audio.setRecording(null)
        }
    }

    /** The small live counter above the record button (also on the stage overlay and in the audio player). */
    private fun updateRecordingTimer() {
        val total = if (RecordingService.active && RecordingService.startedAt > 0L) RecordingService.elapsedMs() / 1000L
        else ((System.currentTimeMillis() - recLocalStart) / 1000L).coerceAtLeast(0L)
        val text = "%02d:%02d:%02d".format(total / 3600, (total % 3600) / 60, total % 60)
        tvRec.text = "● $text"
        stage.setRecordingText(text)
        audio.setRecording(text)
    }

    // ================================================================== subtitles

    /** Copies the chosen subtitle file into the app (the player service can read it) and loads it. */
    private fun importSubtitle(uri: Uri) {
        lifecycleScope.launch {
            var name = "subtitle.srt"
            try {
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0 && c.moveToFirst()) c.getString(i)?.let { name = it }
                }
            } catch (_: Exception) {
            }
            val dir = File(filesDir, "subs")
            val target = File(dir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
            val ok = withContext(Dispatchers.IO) {
                try {
                    dir.mkdirs()
                    contentResolver.openInputStream(uri)?.use { input ->
                        target.outputStream().use { out -> input.copyTo(out) }
                    }
                    target.length() > 0L
                } catch (_: Exception) {
                    false
                }
            }
            if (ok) subtitles.loadFile(Uri.fromFile(target), name) else toast("تعذر قراءة ملف الترجمة")
        }
    }

    // ================================================================== intents (pages, assistant)

    private fun handleIntent(intent: Intent?) {
        intent ?: return

        // "Play" of the movie page / a favourite
        val playUrl = intent.getStringExtra(EXTRA_PLAY_URL)
        if (!playUrl.isNullOrBlank()) {
            val channel = Channel(
                name = intent.getStringExtra(EXTRA_PLAY_NAME).orEmpty().ifBlank { "—" },
                url = playUrl,
                logo = intent.getStringExtra(EXTRA_PLAY_LOGO).orEmpty()
            )
            val audioFlag = intent.getBooleanExtra(EXTRA_PLAY_AUDIO, false)
            val fullscreen = intent.getBooleanExtra(EXTRA_PLAY_FULLSCREEN, true)
            startPositionMs = intent.getLongExtra(EXTRA_PLAY_START, 0L)
            pendingProgressKey = intent.getStringExtra(EXTRA_PROGRESS_KEY)
            @Suppress("DEPRECATION")
            val moviesPage = intent.getParcelableExtra<Intent>(EXTRA_RETURN_MOVIES)
            @Suppress("DEPRECATION")
            val detailPage = intent.getParcelableExtra<Intent>(EXTRA_RETURN_DETAIL)
            returnIntents = listOfNotNull(moviesPage, detailPage)
            intent.removeExtra(EXTRA_RETURN_MOVIES)
            intent.removeExtra(EXTRA_RETURN_DETAIL)
            intent.removeExtra(EXTRA_PLAY_URL)
            play(channel, audioOverride = audioFlag)
            if (fullscreen && !audioFlag) stage.open(dual = false)
            return
        }

        // command of the AI assistant / "My lists"
        val command = intent.getStringExtra(EXTRA_COMMAND)
        if (!command.isNullOrBlank()) {
            val argument = intent.getStringExtra(EXTRA_ARGUMENT).orEmpty()
            intent.removeExtra(EXTRA_COMMAND)
            executeCommand(command, argument)
        }
    }

    private fun openList(id: String) {
        val def = Catalog.sections(prefs).firstOrNull { it.id == id }
        if (def == null) {
            toast("القائمة غير موجودة")
            return
        }
        orbit.selectedId = "lists"
        openCatalog(def.id, def.title)
    }

    private fun executeCommand(command: String, argument: String) {
        when (command) {
            Assistant.CMD_PLAY -> findAndPlay(argument)
            Assistant.CMD_SURAH -> playSurah(argument)
            Assistant.CMD_OPEN_LIST -> openList(argument)
            Assistant.CMD_SECTION -> {
                when (argument) {
                    "countries" -> onOrbitClick("live")
                    "subs" -> onOrbitClick("lists")
                    else -> onOrbitClick(argument)
                }
            }
            Assistant.CMD_RECORD_START -> if (!(RecordingService.active || recShown)) toggleRecording()
            Assistant.CMD_RECORD_STOP -> if (RecordingService.active || recShown) toggleRecording()
            Assistant.CMD_PAUSE -> {
                controller?.pause()
                if (vlcActive) vlc.pause()
                updatePlayIcon()
            }
            Assistant.CMD_RESUME -> {
                controller?.play()
                if (vlcActive) vlc.resume()
                updatePlayIcon()
            }
            Assistant.CMD_MUTE -> {
                controller?.volume = 0f
                audio.setMuted(true)
            }
            Assistant.CMD_UNMUTE -> {
                controller?.volume = 1f
                audio.setMuted(false)
            }
            Assistant.CMD_VOLUME_UP, Assistant.CMD_VOLUME_DOWN -> {
                val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
                am.adjustStreamVolume(
                    android.media.AudioManager.STREAM_MUSIC,
                    if (command == Assistant.CMD_VOLUME_UP) android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER,
                    android.media.AudioManager.FLAG_SHOW_UI
                )
            }
            Assistant.CMD_NEXT -> playRelative(+1)
            Assistant.CMD_PREVIOUS -> playRelative(-1)
            Assistant.CMD_FULLSCREEN -> stage.open(dual = false)
            Assistant.CMD_DUAL -> stage.open(dual = true)
            Assistant.CMD_REFRESH -> updateNow()
            Assistant.CMD_ENGINE -> toast("المشغل الحالي: " + switchEngine())
        }
    }

    /** "Play channel X": looks in favourites, live TV, radio, Quran radio and the user's lists. */
    private fun findAndPlay(query: String) {
        val wantedList = Assistant.expand(query)
        val wanted = wantedList.firstOrNull() ?: ""
        if (wanted.isEmpty()) {
            toast("لم أفهم اسم القناة")
            return
        }
        toast("أبحث عن «$query»…")
        lifecycleScope.launch {
            var best: Channel? = null
            var bestScore = 0
            var bestAudio = false
            for ((id, channels) in searchSources()) {
                for (c in channels) {
                    val name = ArabicText.normalize(c.name)
                    val group = ArabicText.normalize(c.group)
                    var score = 0
                    for ((index, w) in wantedList.withIndex()) {
                        val s = when {
                            name == w -> 5
                            name.startsWith(w) -> 4
                            name.contains(w) -> 3
                            w.contains(name) && name.length >= 4 -> 2
                            // flexible partial search: every word of the query is somewhere in the name
                            w.split(' ').all { it.length > 1 && name.contains(it) } -> 2
                            // bilingual alias: the spelling without spaces / quality words is inside the channel name
                            LogoDb.norm(w).let { kw -> kw.length >= 3 && LogoDb.norm(c.name).contains(kw) } -> 3
                            group.contains(w) -> 1 // a section name ("sports", "news" ...)
                            else -> 0
                        }
                        // the original wording wins over its synonyms
                        score = maxOf(score, if (index == 0 || s <= 1) s else s - 0)
                    }
                    if (score > bestScore) {
                        best = c
                        bestScore = score
                        bestAudio = id == "radio" || id == "quran"
                    }
                }
            }
            val found = best
            if (found == null) toast("لم أجد «$query» في القوائم") else play(found, audioOverride = bestAudio)
        }
    }

    /** "Open surah X [by reciter Y]". argument = "<number>|<reciter words>". */
    private fun playSurah(argument: String) {
        val number = argument.substringBefore('|').toIntOrNull()
        val reciterWords = ArabicText.normalize(argument.substringAfter('|', ""))
        if (number == null || number !in 1..114) {
            toast("لم أفهم رقم السورة")
            return
        }
        lifecycleScope.launch {
            val all = try {
                QuranClient.recitationsAsync()
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                emptyList()
            }
            val available = all.filter { number in it.surahs }
            val wanted = if (reciterWords.isNotEmpty()) {
                available.firstOrNull { rec ->
                    val name = ArabicText.normalize(rec.reciter)
                    reciterWords.split(' ').filter { it.length > 2 }.any { name.contains(it) }
                }
            } else {
                null
            }
            val chosen = wanted
                ?: available.firstOrNull { ArabicText.normalize(it.reciter).contains("العفاسي") }
                ?: available.firstOrNull()
            if (chosen == null) {
                toast("لم أجد هذه السورة")
                return@launch
            }
            catalogId = "quran"
            orbit.selectedId = "quran"
            val channel = Channel(
                name = "%03d  سورة %s".format(number, Surahs.name(number)),
                url = chosen.server + "%03d.mp3".format(number),
                group = chosen.reciter
            )
            play(channel, audioOverride = true)
        }
    }

    companion object {
        private const val STALL_MS = 4000L // a frozen live stream reconnects after 4 seconds
        private const val START_GRACE_MS = 7000L
        const val EXTRA_PLAY_START = "play_start_ms"
        const val EXTRA_PROGRESS_KEY = "progress_key"
        const val EXTRA_RETURN_MOVIES = "return_movies"
        const val EXTRA_RETURN_DETAIL = "return_detail"
        const val EXTRA_PLAY_URL = "play_url"
        const val EXTRA_PLAY_NAME = "play_name"
        const val EXTRA_PLAY_LOGO = "play_logo"
        const val EXTRA_PLAY_AUDIO = "play_audio"
        const val EXTRA_PLAY_FULLSCREEN = "play_fullscreen"
        const val EXTRA_COMMAND = "assistant_command"
        const val EXTRA_ARGUMENT = "assistant_argument"

        private const val CONTROLS_TIMEOUT_MS = 5_000L
        private const val MAX_RECONNECT = 5
        private const val PAGED_MIN = 500
    }
}
