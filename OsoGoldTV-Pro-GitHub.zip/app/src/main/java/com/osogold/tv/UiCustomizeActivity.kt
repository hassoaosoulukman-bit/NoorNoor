package com.osogold.tv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/**
 * Settings -> "تخصيص الواجهة الرئيسية": colour theme, the place of the live screen and of the
 * sections / channels lists (left / center / right) and their width and height (sliders).
 * Nothing changes until the user presses "حفظ"; then the main screen applies everything at once.
 */
class UiCustomizeActivity : BaseActivity() {

    private lateinit var prefs: Prefs

    private var theme = 0
    private var stageSide = 0
    private var listSide = 2
    private var stageW = 68
    private var stageH = 100
    private var listW = 32
    private var listH = 100

    private lateinit var preview: PreviewView
    private val themeDots = ArrayList<View>()
    private val stageChips = ArrayList<TextView>()
    private val listChips = ArrayList<TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        theme = prefs.themeIndex
        stageSide = prefs.stageSide
        listSide = prefs.listSide
        stageW = prefs.stageWidthPct
        stageH = prefs.stageHeightPct
        listW = prefs.listWidthPct
        listH = prefs.listHeightPct

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        root.addView(CosmicBackgroundView(this), FrameLayout.LayoutParams(-1, -1))

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(column, FrameLayout.LayoutParams(-1, -2))
        }
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        // header: back + title
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(title("تخصيص الواجهة الرئيسية", 22f), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("رجوع", false) { finish() }, LinearLayout.LayoutParams(-2, dp(40)))
        column.addView(header)

        // live preview of the two blocks
        preview = PreviewView(this)
        column.addView(preview, LinearLayout.LayoutParams(-1, dp(120)).apply { topMargin = dp(10) })

        // ---------------------------------------------------------------- A) colours
        column.addView(section("أ)  ألوان وثيمات الواجهة"))
        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        UiTheme.all.forEachIndexed { index, t ->
            val holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            val dot = View(this)
            dot.setTag(R.id.tag_theme_bg, false) // the swatches must keep their real colours
            themeDots.add(dot)
            dot.setOnClickListener {
                theme = index
                refreshThemes()
            }
            holder.addView(dot, LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(dp(6), dp(4), dp(6), dp(2)) })
            holder.addView(TextView(this).apply {
                text = t.name
                textSize = 10f
                setTextColor(0xFFF3E9CF.toInt())
                gravity = Gravity.CENTER
            })
            dots.addView(holder)
        }
        column.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(dots)
        })
        refreshThemes()

        // ---------------------------------------------------------------- B) places
        column.addView(section("ب)  أماكن العناصر"))
        column.addView(label("شاشة البث والمدار:"))
        column.addView(segment(stageChips) { stageSide = it; refreshChips(); preview.invalidate() })
        column.addView(label("قائمة الأقسام والقنوات:"))
        column.addView(segment(listChips) { listSide = it; refreshChips(); preview.invalidate() })
        refreshChips()

        // ---------------------------------------------------------------- C) sizes
        column.addView(section("ج)  الأحجام والمقاسات"))
        column.addView(slider("عرض شاشة البث المباشر", stageW, 30) { stageW = it })
        column.addView(slider("طول شاشة البث المباشر", stageH, 30) { stageH = it })
        column.addView(slider("عرض قائمة الأقسام والقنوات", listW, 20) { listW = it })
        column.addView(slider("طول قائمة الأقسام والقنوات", listH, 30) { listH = it })
        column.addView(
            TextView(this).apply {
                text = "ملاحظة: إذا زاد مجموع العرضين عن 100٪ ستتراكب الشاشتان جزئياً."
                textSize = 11f
                setTextColor(0xFFD4AF37.toInt())
                setPadding(0, dp(4), 0, 0)
            }
        )

        // ---------------------------------------------------------------- D) save
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        }
        actions.addView(button("حفظ", true) { save() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(View(this), LinearLayout.LayoutParams(dp(10), 1))
        actions.addView(button("استعادة الافتراضي", false) { restoreDefaults() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        column.addView(actions)

        setContentView(root)
    }

    // ------------------------------------------------------------------ actions

    private fun save() {
        prefs.themeIndex = theme
        prefs.stageSide = stageSide
        prefs.listSide = listSide
        prefs.stageWidthPct = stageW
        prefs.stageHeightPct = stageH
        prefs.listWidthPct = listW
        prefs.listHeightPct = listH
        UiTheme.select(theme)
        toast("تم الحفظ")
        finish() // the main screen applies the new theme and layout as soon as it is shown again
    }

    private fun restoreDefaults() {
        theme = 0
        stageSide = 0
        listSide = 2
        stageW = 68
        stageH = 100
        listW = 32
        listH = 100
        recreateForm()
    }

    private fun recreateForm() {
        // simplest way to reset every slider: rebuild the screen from the saved defaults in memory
        prefs.resetLayout()
        UiTheme.select(0)
        toast("تمت استعادة الإعدادات الافتراضية")
        recreate()
    }

    // ------------------------------------------------------------------ building blocks

    private fun refreshThemes() {
        themeDots.forEachIndexed { i, dot ->
            val shape = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(UiTheme.all[i].swatch)
                setStroke(dp(if (i == theme) 4 else 1), if (i == theme) 0xFFFFFFFF.toInt() else 0x66FFFFFF)
            }
            dot.background = shape
        }
        preview.accent = UiTheme.all[theme].swatch
        preview.invalidate()
    }

    private fun refreshChips() {
        fun paint(chips: List<TextView>, selected: Int) {
            chips.forEachIndexed { i, chip ->
                chip.setBackgroundResource(if (i == selected) R.drawable.bg_chip_active else R.drawable.bg_chip)
                UiTheme.apply(chip)
            }
        }
        paint(stageChips, stageSide)
        paint(listChips, listSide)
    }

    private fun segment(into: MutableList<TextView>, onPick: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        into.clear()
        listOf("اليسار", "المنتصف", "اليمين").forEachIndexed { index, name ->
            val chip = TextView(this).apply {
                text = name
                gravity = Gravity.CENTER
                textSize = 14f
                setTextColor(0xFFFFD86B.toInt())
                setOnClickListener { onPick(index) }
            }
            into.add(chip)
            box.addView(chip, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
        }
        return box
    }

    private fun slider(name: String, value: Int, min: Int, onChange: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, 0) }
        val text = TextView(this).apply {
            this.text = "$name:  $value٪"
            setTextColor(0xFFF3E9CF.toInt())
            textSize = 13f
        }
        val bar = SeekBar(this).apply {
            max = 100 - min
            progress = value - min
            progressTintList = android.content.res.ColorStateList.valueOf(UiTheme.all[theme].swatch)
            thumbTintList = android.content.res.ColorStateList.valueOf(0xFFFFD86B.toInt())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = progress + min
                    text.text = "$name:  $v٪"
                    onChange(v)
                    preview.invalidate()
                }

                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
        }
        box.addView(text)
        box.addView(bar, LinearLayout.LayoutParams(-1, dp(32)))
        return box
    }

    private fun title(text: String, size: Float) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(0xFFFFD86B.toInt())
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun section(text: String) = title(text, 16f).apply { setPadding(0, dp(16), 0, dp(4)) }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(0xFFF3E9CF.toInt())
        setPadding(0, dp(6), 0, 0)
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        gravity = Gravity.CENTER
        textSize = 15f
        setPadding(dp(16), 0, dp(16), 0)
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        if (primary) {
            setBackgroundResource(R.drawable.bg_gold_button)
            setTextColor(0xFF1A1405.toInt())
        } else {
            setBackgroundResource(R.drawable.bg_chip)
            setTextColor(0xFFFFD86B.toInt())
        }
        setOnClickListener { onClick() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** A small screen drawing that shows where the two blocks will be. */
    private inner class PreviewView(context: Context) : View(context) {
        var accent = 0xFFD4AF37.toInt()
        private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = 0x88FFFFFF.toInt() }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF000000.toInt(); textAlign = Paint.Align.CENTER; textSize = 30f }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            canvas.drawRoundRect(RectF(1f, 1f, w - 1, h - 1), 14f, 14f, frame)
            fun x(side: Int, bw: Float) = when (side) { 0 -> 0f; 2 -> w - bw; else -> (w - bw) / 2 }
            val sw = w * stageW / 100f
            val sh = h * stageH / 100f
            val lw = w * listW / 100f
            val lh = h * listH / 100f
            val sx = x(stageSide, sw)
            var lx = x(listSide, lw)
            if (sx < lx + lw && lx < sx + sw) {
                lx = if (w - (sx + sw) >= sx) (sx + sw).coerceAtMost(w - lw) else (sx - lw).coerceAtLeast(0f)
            }
            fill.color = accent
            fill.alpha = 200
            canvas.drawRoundRect(RectF(sx, (h - sh) / 2, sx + sw, (h - sh) / 2 + sh), 12f, 12f, fill)
            canvas.drawText("البث", sx + sw / 2, h / 2 + 10f, text)
            fill.alpha = 120
            canvas.drawRoundRect(RectF(lx, (h - lh) / 2, lx + lw, (h - lh) / 2 + lh), 12f, 12f, fill)
            canvas.drawText("القوائم", lx + lw / 2, h / 2 + 10f, text)
        }
    }
}
