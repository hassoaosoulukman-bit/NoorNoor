package com.osogold.tv

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/**
 * Settings -> "تخصيص واجهة المشغل والأزرار": side of the lists panel (right / left), its width,
 * height and opacity (saved automatically while sliding) and the place of every control button
 * (top bar / bottom bar / hidden).
 */
class PlayerUiActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private val gold = 0xFFD4AF37.toInt()
    private val sideChips = ArrayList<TextView>()
    private val posChips = HashMap<String, List<TextView>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        root.addView(CosmicBackgroundView(this), FrameLayout.LayoutParams(-1, -1))
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(
            ScrollView(this).apply {
                isFillViewport = true
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(column, FrameLayout.LayoutParams(-1, -2))
            },
            FrameLayout.LayoutParams(-1, -1)
        )

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            TextView(this).apply {
                text = "تخصيص واجهة المشغل والأزرار"
                textSize = 22f
                setTextColor(gold)
            },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        header.addView(chip("رجوع", true) { finish() }, LinearLayout.LayoutParams(-2, dp(40)))
        column.addView(header)

        // a) side
        column.addView(section("أ)  مكان لوحة الأقسام والقنوات"))
        val sideRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("يمين الشاشة" to 0, "يسار الشاشة" to 1).forEach { (name, value) ->
            val c = chip(name, false) {
                prefs.panelSide = value
                refreshSide()
            }
            sideChips.add(c)
            sideRow.addView(c, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        column.addView(sideRow)
        refreshSide()

        // b) sizes (saved at once)
        column.addView(section("ب)  حجم اللوحة وشفافيتها (يُحفظ تلقائياً)"))
        column.addView(slider("العرض", prefs.panelWidthDp, 220, 560, "dp") { prefs.panelWidthDp = it })
        column.addView(slider("الطول", prefs.panelHeightPct, 40, 100, "٪") { prefs.panelHeightPct = it })
        column.addView(slider("الشفافية (الكثافة)", prefs.panelAlphaPct, 20, 100, "٪") { prefs.panelAlphaPct = it })

        // c) buttons
        column.addView(section("ج)  توزيع الأزرار: شريط علوي / شريط سفلي / إخفاء"))
        for (def in StageButtons.defs) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(
                TextView(this).apply {
                    text = def.title
                    textSize = 14f
                    setTextColor(0xFFF3E9CF.toInt())
                },
                LinearLayout.LayoutParams(0, -2, 1.2f)
            )
            val chips = ArrayList<TextView>()
            listOf("علوي" to 0, "سفلي" to 1, "مخفي" to 2).forEach { (name, value) ->
                val c = chip(name, false) {
                    prefs.setPlayerBtnPos(def.key, value)
                    refreshButton(def.key)
                }
                chips.add(c)
                row.addView(c, LinearLayout.LayoutParams(0, dp(38), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            posChips[def.key] = chips
            refreshButton(def.key)
            column.addView(row)
        }

        column.addView(
            chip("استعادة الافتراضي", false) {
                prefs.resetPlayerLayout()
                prefs.panelSide = 0
                prefs.panelWidthDp = 340
                prefs.panelHeightPct = 100
                prefs.panelAlphaPct = 60
                recreate()
            },
            LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(16) }
        )
        setContentView(root)
    }

    private fun refreshSide() {
        sideChips.forEachIndexed { i, c -> style(c, prefs.panelSide == i) }
    }

    private fun refreshButton(key: String) {
        val current = prefs.playerBtnPos(key, StageButtons.defaultPos(key))
        posChips[key]?.forEachIndexed { i, c -> style(c, current == i) }
    }

    private fun style(c: TextView, on: Boolean) {
        c.background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(if (on) gold else 0x33FFFFFF)
            setStroke(dp(1), gold)
        }
        c.setTextColor(if (on) 0xFF000000.toInt() else gold)
    }

    private fun chip(text: String, on: Boolean, click: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 13f
        gravity = Gravity.CENTER
        setPadding(dp(14), 0, dp(14), 0)
        style(this, on)
        setOnClickListener { click() }
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text
        textSize = 16f
        setTextColor(gold)
        setPadding(0, dp(18), 0, dp(6))
    }

    private fun slider(name: String, value: Int, min: Int, max: Int, unit: String, onChange: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val label = TextView(this).apply {
            text = "$name: $value$unit"
            textSize = 13f
            setTextColor(0xFFF3E9CF.toInt())
        }
        val bar = SeekBar(this).apply {
            this.max = max - min
            progress = value.coerceIn(min, max) - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + min
                    label.text = "$name: $v$unit"
                    if (fromUser) onChange(v)
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(label)
        box.addView(bar, LinearLayout.LayoutParams(-1, -2))
        return box
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
