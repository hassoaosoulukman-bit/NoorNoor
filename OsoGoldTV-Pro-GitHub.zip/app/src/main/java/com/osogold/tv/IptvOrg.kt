package com.osogold.tv

/**
 * The open-source iptv-org library (github.com/iptv-org/iptv): free world and Arabic channels, fetched
 * automatically (lists older than a day are downloaded again), plus official YouTube live channels
 * that open inside the app.
 */
object IptvOrg {

    private const val BASE = "https://iptv-org.github.io/iptv/"
    private const val MAX_AGE_MS = 24L * 60L * 60L * 1000L
    private val refreshedThisSession = HashSet<String>()

    val groups: List<Pkg> = listOf(
        Pkg("lang:ara", "القنوات العربية", "🌙"),
        Pkg("lang:kur", "القنوات الكردية", "🟡"),
        Pkg("lang:tur", "القنوات التركية", "🇹🇷"),
        Pkg("lang:deu", "القنوات الألمانية", "🇩🇪"),
        Pkg("lang:eng", "القنوات الإنجليزية", "🇬🇧"),
        Pkg("lang:fra", "القنوات الفرنسية", "🇫🇷"),
        Pkg("lang:spa", "القنوات الإسبانية", "🇪🇸"),
        Pkg("cat:news", "أخبار", "📰"),
        Pkg("cat:sports", "رياضة", "⚽"),
        Pkg("cat:movies", "أفلام", "🎬"),
        Pkg("cat:kids", "أطفال", "🧒"),
        Pkg("cat:music", "موسيقى", "🎵"),
        Pkg("yt", "يوتيوب — قنوات رسمية مباشرة", "▶")
    )

    private fun address(id: String): String = when {
        id.startsWith("lang:") -> BASE + "languages/" + id.removePrefix("lang:") + ".m3u"
        id.startsWith("cat:") -> BASE + "categories/" + id.removePrefix("cat:") + ".m3u"
        else -> BASE + "index.m3u"
    }

    /** Official YouTube live channels (the "youtube:live:" scheme opens them in the in-app player). */
    private fun youtube(): List<Channel> = listOf(
        "الجزيرة (عربي)" to "UCfiwzLy-8yKzIbsmZTzxDgw",
        "Al Jazeera English" to "UCNye-wNBqNL5ZzHSJj3l8Bg",
        "DW News" to "UCknLrEdhRCp1aegoMqRaCZg",
        "France 24 English" to "UCQfwfsi5VrQ8yKZ-UWmAEFg",
        "Sky News" to "UCoMdktPbSTixAyNGwb-UYkQ",
        "TRT World" to "UC7fWeaHhqgM4Ry-RMpM2YYw",
        "NASA" to "UCLA_DiR1FfKNvjuUpBHmylQ"
    ).map { (name, id) -> Channel(name = name, url = "youtube:live:$id", group = "YouTube") }

    suspend fun channels(prefs: Prefs, id: String, force: Boolean): List<Channel> {
        if (id == "yt") return youtube()
        val stale = System.currentTimeMillis() - prefs.iptvStamp(id) > MAX_AGE_MS
        val refresh = force || (stale && refreshedThisSession.add(id))
        val list = PlaylistRepository.load(address(id), refresh)
        if (refresh) prefs.setIptvStamp(id)
        return list
    }
}
