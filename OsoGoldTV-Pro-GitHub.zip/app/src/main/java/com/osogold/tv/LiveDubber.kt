package com.osogold.tv

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * AI Dubbing: speaks the Arabic translation. The voice follows the speaker heard in the channel
 * (pitch analysis: child / girl, woman, young man, old man), the original sound is lowered ("ducking",
 * default 15 %) while the dubbing speaks and restored when it is silent. Android's TTS speaks (free);
 * with an OpenAI key the cloud voices are used instead.
 */
class LiveDubber(
    private val context: Context,
    private val prefs: Prefs,
    private val setChannelVolume: (Float) -> Unit
) {

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var tts: TextToSpeech? = null
    private var ready = false
    private val pending = AtomicInteger(0)
    private var cloudPlayer: MediaPlayer? = null

    /** Smoothed fundamental frequency (Hz) of the voice heard in the channel; 0 = unknown. */
    @Volatile
    private var pitchHz = 0f

    enum class Voice(val label: String, val pitch: Float, val rate: Float, val cloud: String) {
        CHILD("طفل / بنت", 1.55f, 1.08f, "shimmer"),
        WOMAN("امرأة", 1.25f, 1.0f, "nova"),
        YOUNG_MAN("رجل شاب", 1.0f, 1.0f, "echo"),
        OLD_MAN("رجل كبير", 0.72f, 0.92f, "onyx")
    }

    fun currentVoice(): Voice = when {
        pitchHz >= 280f -> Voice.CHILD
        pitchHz >= 190f -> Voice.WOMAN
        pitchHz in 1f..120f -> Voice.OLD_MAN
        else -> Voice.YOUNG_MAN
    }

    fun start() {
        if (tts != null) return
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val t = tts ?: return@TextToSpeech
                val r = t.setLanguage(Locale("ar"))
                ready = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                t.setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = duck()
                    override fun onDone(utteranceId: String?) = finished()
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = finished()
                })
            }
        }
    }

    fun stop() {
        try { tts?.stop(); tts?.shutdown() } catch (_: Throwable) {}
        tts = null
        ready = false
        try { cloudPlayer?.release() } catch (_: Throwable) {}
        cloudPlayer = null
        pending.set(0)
        main.removeCallbacksAndMessages(null)
        main.post { setChannelVolume(1f) }
    }

    /** Feed the sound of the channel (mono 16 kHz): used to find the pitch of the speaker. */
    fun observe(pcm: ShortArray) {
        if (pcm.size < 1200) return
        var energy = 0.0
        for (i in 0 until 1200) energy += pcm[i].toDouble() * pcm[i]
        if (Math.sqrt(energy / 1200) < 700) return // silence or noise: keep the last value
        val f0 = estimate(pcm, 16000)
        if (f0 > 0f) pitchHz = if (pitchHz == 0f) f0 else pitchHz * 0.7f + f0 * 0.3f
    }

    /** Autocorrelation pitch (60..400 Hz). 0 when no clear voice. */
    private fun estimate(pcm: ShortArray, rate: Int): Float {
        val n = 1024
        val minLag = rate / 400
        val maxLag = rate / 60
        if (pcm.size < n + maxLag) return 0f
        var zero = 0.0
        for (i in 0 until n) zero += pcm[i].toDouble() * pcm[i]
        if (zero <= 0.0) return 0f
        var bestLag = 0
        var best = 0.0
        for (lag in minLag..maxLag) {
            var sum = 0.0
            for (i in 0 until n) sum += pcm[i].toDouble() * pcm[i + lag]
            if (sum > best) {
                best = sum
                bestLag = lag
            }
        }
        return if (bestLag > 0 && best / zero > 0.35) rate.toFloat() / bestLag else 0f
    }

    fun speak(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val voice = currentVoice()
        val spoken = if (prefs.dubDialect == 1) ShamiDict.convert(clean) else clean
        val openAi = AiKeys.active(prefs).firstOrNull { AiKeys.provider(it) == AiKeys.OPENAI }
        if (openAi != null) {
            speakCloud(spoken, voice, openAi)
            return
        }
        val t = tts ?: return
        if (!ready) return
        // never let a backlog build up: the dubbing must stay close to the picture
        if (pending.get() > 3) {
            t.stop()
            pending.set(0)
        }
        pending.incrementAndGet()
        t.setPitch(voice.pitch)
        t.setSpeechRate(voice.rate)
        t.speak(spoken, TextToSpeech.QUEUE_ADD, null, "dub" + System.nanoTime())
    }

    private fun duck() {
        main.post { setChannelVolume(prefs.dubDuck / 100f) }
    }

    private fun finished() {
        if (pending.decrementAndGet() <= 0) {
            pending.set(0)
            // a short moment of silence first, then the original sound comes back
            main.postDelayed({ if (pending.get() == 0) setChannelVolume(1f) }, 500L)
        }
    }

    private fun speakCloud(text: String, voice: Voice, key: String) {
        pending.incrementAndGet()
        duck()
        io.execute {
            var ok = false
            try {
                val body = JSONObject().put("model", "gpt-4o-mini-tts").put("voice", voice.cloud)
                    .put("input", text).put("response_format", "mp3").toString()
                val request = Request.Builder().url("https://api.openai.com/v1/audio/speech")
                    .header("Authorization", "Bearer $key")
                    .post(body.toRequestBody("application/json".toMediaType())).build()
                val file = File(context.cacheDir, "dub_" + System.nanoTime() + ".mp3")
                NetConfig.client().newCall(request).execute().use { r ->
                    if (r.isSuccessful) r.body?.byteStream()?.use { input -> file.outputStream().use { input.copyTo(it) } }
                    else AiKeys.markKeyProblem(key)
                }
                if (file.length() > 0) {
                    ok = true
                    main.post {
                        try {
                            cloudPlayer?.release()
                            val mp = MediaPlayer()
                            cloudPlayer = mp
                            mp.setDataSource(file.absolutePath)
                            mp.setOnCompletionListener { file.delete(); finished() }
                            mp.setOnErrorListener { _, _, _ -> file.delete(); finished(); true }
                            mp.setOnPreparedListener { it.start() }
                            mp.prepareAsync()
                        } catch (_: Throwable) {
                            file.delete()
                            finished()
                        }
                    }
                } else file.delete()
            } catch (_: Throwable) {
            }
            if (!ok) main.post { finished() }
        }
    }
}

/** A small Levantine (Syrian / Shami) rewrite of Modern Standard Arabic for the free local engine. */
object ShamiDict {
    private val words = linkedMapOf(
        "ماذا" to "شو", "لماذا" to "ليش", "كيف حالك" to "كيفك", "كيف" to "كيف", "الآن" to "هلق", "الان" to "هلق",
        "هذا" to "هاد", "هذه" to "هاي", "هؤلاء" to "هدول", "ذلك" to "هيداك", "أريد" to "بدي", "اريد" to "بدي",
        "تريد" to "بدك", "نريد" to "بدنا", "يريد" to "بدو", "أين" to "وين", "اين" to "وين", "الآن" to "هلق",
        "لا أعرف" to "ما بعرف", "لا اعرف" to "ما بعرف", "لا يوجد" to "ما في", "يوجد" to "في", "جداً" to "كتير", "جدا" to "كتير",
        "كثيراً" to "كتير", "كثيرا" to "كتير", "أنا" to "أنا", "نحن" to "نحنا", "أنت" to "إنت", "انت" to "إنت", "أنتِ" to "إنتي",
        "هو" to "هو", "هي" to "هي", "هم" to "هنن", "ليس" to "مو", "لست" to "مو", "ليست" to "مو", "الآن" to "هلق",
        "سوف" to "رح", "سأ" to "رح ", "ذهب" to "راح", "أذهب" to "روح", "اذهب" to "روح", "يذهب" to "بيروح",
        "تعال" to "تعا", "انظر" to "شوف", "أنظر" to "شوف", "ينظر" to "بيشوف", "الآن" to "هلق", "أيضاً" to "كمان", "ايضا" to "كمان",
        "قليلاً" to "شوي", "قليلا" to "شوي", "الى" to "لـ", "إلى" to "لـ", "مع" to "مع", "حسناً" to "تمام", "حسنا" to "تمام",
        "نعم" to "إي", "طفل" to "ولد", "أطفال" to "ولاد", "رجل" to "زلمة", "امرأة" to "مرا", "المرأة" to "المرا",
        "الآن" to "هلق", "بسرعة" to "بسرعة", "جميل" to "حلو", "جميلة" to "حلوة", "ماذا تفعل" to "شو عم تعمل",
        "يا إلهي" to "يا ربي", "شكراً" to "يعطيك العافية", "شكرا" to "يعطيك العافية", "من فضلك" to "الله يخليك",
        "صباح الخير" to "صباح الخير", "ماذا حدث" to "شو صار", "حدث" to "صار", "ماذا يحدث" to "شو عم يصير"
    )

    private val regexes: List<Pair<Regex, String>> = words.entries
        .sortedByDescending { it.key.length }
        .map { Regex("(?<![\\p{L}])" + Regex.escape(it.key) + "(?![\\p{L}])") to it.value }

    fun convert(text: String): String {
        var t = text
        for ((re, to) in regexes) t = re.replace(t, to)
        return t
    }
}
