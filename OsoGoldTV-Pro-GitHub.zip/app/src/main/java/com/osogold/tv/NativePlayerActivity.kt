package com.osogold.tv

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/**
 * Third engine: the phone's own Android MediaPlayer (hardware decoder of the device) on a SurfaceView,
 * with its own play / pause, seek and aspect controls. Started when the engine "Android MediaPlayer"
 * is chosen. Tap the picture to show / hide the controls.
 */
class NativePlayerActivity : BaseActivity() {

    private var player: MediaPlayer? = null
    private lateinit var surface: SurfaceView
    private lateinit var status: TextView
    private lateinit var playBtn: TextView
    private lateinit var seek: SeekBar
    private lateinit var controls: View
    private val handler = Handler(Looper.getMainLooper())
    private var prepared = false
    private var fill = false
    private var videoW = 0
    private var videoH = 0
    private var surfaceReady = false

    override val floatingBackEnabled: Boolean get() = false

    private val tick = object : Runnable {
        override fun run() {
            try {
                val mp = player
                if (mp != null && prepared) {
                    val d = mp.duration
                    if (d > 0) {
                        seek.max = d
                        seek.progress = mp.currentPosition
                    }
                    playBtn.text = if (mp.isPlaying) "⏸" else "▶"
                }
            } catch (_: Throwable) {
            }
            handler.postDelayed(this, 500L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra(EXTRA_URL).orEmpty()
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        val agent = intent.getStringExtra(EXTRA_AGENT) ?: NetConfig.userAgent()

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        surface = SurfaceView(this)
        root.addView(surface, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))

        status = TextView(this).apply {
            setTextColor(0xFFD4AF37.toInt())
            textSize = 15f
            gravity = Gravity.CENTER
            text = "جارٍ التحميل…"
        }
        root.addView(status, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xAA000000.toInt())
            setPadding(dp(16), dp(8), dp(16), dp(8))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        fun button(text: String, click: () -> Unit) = TextView(this).apply {
            this.text = text
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(0xFFD4AF37.toInt())
            setBackgroundResource(R.drawable.bg_control_dark)
            setOnClickListener { click() }
        }
        bar.addView(button("✕") { finish() }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(8) })
        playBtn = button("⏸") { toggle() }
        bar.addView(playBtn, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(8) })
        seek = SeekBar(this).apply {
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser && prepared) try { player?.seekTo(p) } catch (_: Throwable) {}
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        bar.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(button("⛶") { fill = !fill; resizeSurface(); toast(if (fill) "ملء الشاشة" else "أصلي") },
            LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(8) })
        bar.addView(
            TextView(this).apply {
                text = title
                setTextColor(0xFFF3E9CF.toInt())
                textSize = 13f
                maxLines = 1
                setPadding(dp(10), 0, 0, 0)
            },
            LinearLayout.LayoutParams(dp(160), -2)
        )
        controls = bar
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        surface.setOnClickListener {
            controls.visibility = if (controls.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        setContentView(root)

        surface.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                surfaceReady = true
                if (player == null) start(url, agent) else player?.setDisplay(holder)
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
            override fun surfaceDestroyed(holder: SurfaceHolder) {
                surfaceReady = false
                try { player?.setDisplay(null) } catch (_: Throwable) {}
            }
        })
        handler.post(tick)
    }

    private fun start(url: String, agent: String) {
        try {
            val mp = MediaPlayer()
            player = mp
            mp.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build()
            )
            mp.setDisplay(surface.holder)
            mp.setDataSource(this, Uri.parse(url), mapOf("User-Agent" to agent))
            mp.setOnPreparedListener {
                prepared = true
                status.visibility = View.GONE
                it.start()
            }
            mp.setOnVideoSizeChangedListener { _, w, h ->
                videoW = w
                videoH = h
                resizeSurface()
            }
            mp.setOnErrorListener { _, what, extra ->
                status.visibility = View.VISIBLE
                status.text = "تعذّر التشغيل بالمشغل الأصلي ($what/$extra)\nجرّب Media3 أو LibVLC"
                true
            }
            mp.prepareAsync()
        } catch (e: Throwable) {
            status.text = "تعذّر التشغيل: " + (e.message ?: "")
        }
    }

    private fun toggle() {
        try {
            val mp = player ?: return
            if (mp.isPlaying) mp.pause() else mp.start()
        } catch (_: Throwable) {
        }
    }

    /** Original shape (fit) or fill the screen (crop). */
    private fun resizeSurface() {
        val parent = surface.parent as? View ?: return
        val pw = parent.width
        val ph = parent.height
        if (pw == 0 || ph == 0 || videoW == 0 || videoH == 0) return
        val scale = if (fill) maxOf(pw.toFloat() / videoW, ph.toFloat() / videoH)
        else minOf(pw.toFloat() / videoW, ph.toFloat() / videoH)
        val lp = surface.layoutParams as FrameLayout.LayoutParams
        lp.width = (videoW * scale).toInt()
        lp.height = (videoH * scale).toInt()
        lp.gravity = Gravity.CENTER
        surface.layoutParams = lp
    }

    override fun onStop() {
        super.onStop()
        try { player?.pause() } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            player?.release()
        } catch (_: Throwable) {
        }
        player = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_AGENT = "agent"
    }
}
