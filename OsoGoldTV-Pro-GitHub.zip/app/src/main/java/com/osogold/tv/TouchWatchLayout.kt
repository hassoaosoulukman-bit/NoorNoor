package com.osogold.tv

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.widget.FrameLayout

/** A FrameLayout that reports every touch inside it (even on its buttons): used to reset the 5 s auto-hide timer. */
class TouchWatchLayout @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : FrameLayout(context, attrs) {
    var onAnyTouch: (() -> Unit)? = null

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN || ev.actionMasked == MotionEvent.ACTION_UP) onAnyTouch?.invoke()
        return super.dispatchTouchEvent(ev)
    }
}
