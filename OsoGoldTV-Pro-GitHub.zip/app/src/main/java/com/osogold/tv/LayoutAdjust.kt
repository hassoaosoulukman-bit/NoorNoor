package com.osogold.tv

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/**
 * "ضبط الأبعاد": width, height, side and opacity of the sections / channels panel (and the live screen on the main screen),
 * changed LIVE in front of the user's eyes from a small window at the bottom (the screen behind stays visible and usable).
 * Save and apply / reset to the defaults.
 */
object LayoutAdjust {

    fun show(activity: Activity, fullScreenStage: Boolean, apply: () -> Unit) {
        val prefs = Prefs(activity)
        val gold = 0xFFD4AF37.toInt()
        val d = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val dialog = Dialog(activity)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL)
            setGravity(Gravity.BOTTOM)
        }
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xE6000000.toInt())
            setPadding(dp(14), dp(8), dp(14), dp(8))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(activity).apply { addView(box) }
        box.addView(TextView(activity).apply { text = "ضبط الأبعاد"; setTextColor(gold); textSize = 16f; gravity = Gravity.CENTER })

        fun slider(name: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit, unit: String = "%") {
            val label = TextView(activity).apply { setTextColor(Color.WHITE); textSize = 12f; text = "$name: ${get()}$unit" }
            box.addView(label)
            box.addView(SeekBar(activity).apply {
                this.max = max - min; progress = get().coerceIn(min, max) - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        if (!fromUser) return
                        set(p + min); label.text = "$name: ${p + min}$unit"; apply()
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }, LinearLayout.LayoutParams(-1, dp(36)))
        }
        fun chips(vararg items: Pair<String, () -> Unit>) {
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
            for ((text, click) in items) {
                row.addView(TextView(activity).apply {
                    this.text = text; setTextColor(gold); textSize = 12f; gravity = Gravity.CENTER; minHeight = dp(40)
                    background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0x55000000); setStroke(dp(1), gold) }
                    setOnClickListener { click(); apply() }
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
            }
            box.addView(row)
        }

        if (fullScreenStage) {
            slider("عرض لوحة الأقسام والقنوات", 220, 560, { prefs.panelWidthDp }, { prefs.panelWidthDp = it }, " dp")
            slider("طول اللوحة", 40, 100, { prefs.panelHeightPct }, { prefs.panelHeightPct = it })
            slider("الشفافية (شفاف 20% ... داكن 100%)", 20, 100, { prefs.panelAlphaPct }, { prefs.panelAlphaPct = it })
            chips("◀ اللوحة يميناً" to { prefs.panelSide = 0 }, "اللوحة يساراً ▶" to { prefs.panelSide = 1 })
        } else {
            slider("عرض شاشة العرض", 30, 100, { prefs.stageWidthPct }, { prefs.stageWidthPct = it })
            slider("طول شاشة العرض", 30, 100, { prefs.stageHeightPct }, { prefs.stageHeightPct = it })
            slider("عرض الأقسام والقنوات", 20, 100, { prefs.listWidthPct }, { prefs.listWidthPct = it })
            slider("طول الأقسام والقنوات", 30, 100, { prefs.listHeightPct }, { prefs.listHeightPct = it })
            slider("شفافية الأقسام والقنوات (شفاف 0% ... داكن 100%)", 0, 100, { prefs.listAlphaPct }, { prefs.listAlphaPct = it })
            chips("شاشة العرض: يمين" to { prefs.stageSide = 2 }, "وسط" to { prefs.stageSide = 1 }, "يسار" to { prefs.stageSide = 0 })
            chips("القوائم: يمين" to { prefs.listSide = 2 }, "وسط" to { prefs.listSide = 1 }, "يسار" to { prefs.listSide = 0 })
        }
        val buttons = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(TextView(activity).apply {
            text = "حفظ وتطبيق"; setTextColor(Color.BLACK); textSize = 14f; gravity = Gravity.CENTER; minHeight = dp(48)
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(gold) }
            setOnClickListener { apply(); dialog.dismiss(); Toasts.show(activity, "✓ تم الحفظ والتطبيق") }
        }, LinearLayout.LayoutParams(0, -2, 1.4f).apply { setMargins(dp(3), dp(8), dp(3), dp(4)) })
        buttons.addView(TextView(activity).apply {
            text = "إعادة ضبط"; setTextColor(gold); textSize = 14f; gravity = Gravity.CENTER; minHeight = dp(48)
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(0x55000000); setStroke(dp(1), gold) }
            setOnClickListener {
                if (fullScreenStage) prefs.resetPlayerLayout() else { prefs.resetLayout(); prefs.listAlphaPct = 100 }
                apply(); dialog.dismiss(); Toasts.show(activity, "أُعيد الضبط الافتراضي")
            }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(8), dp(3), dp(4)) })
        box.addView(buttons)

        dialog.setContentView(scroll)
        dialog.window?.setLayout(
            (activity.resources.displayMetrics.widthPixels * 0.96f).toInt(),
            (activity.resources.displayMetrics.heightPixels * 0.55f).toInt()
        )
        dialog.show()
    }
}

/** A tiny toast helper usable without a BaseActivity. */
object Toasts {
    fun show(context: android.content.Context, text: String) {
        android.widget.Toast.makeText(context, text, android.widget.Toast.LENGTH_SHORT).show()
    }
}
