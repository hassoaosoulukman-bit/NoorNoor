package com.osogold.tv

import android.util.JsonReader
import android.util.JsonToken
import android.util.JsonWriter
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter

/**
 * Local JSON cache of the subscription lists (M3U lists and Xtream categories / streams).
 *
 * The parsed lists are stored as streaming JSON files in the app storage, so that opening a section
 * never has to download or parse a 50 000 entry list again, and the lists still work offline.
 *
 * Everything here is BLOCKING file work: always call it from Dispatchers.IO / Dispatchers.Default.
 */
object ChannelCache {

    private fun dir(): File {
        val d = File(NetConfig.app.filesDir, "json_cache")
        d.mkdirs()
        return d
    }

    fun file(key: String): File = File(dir(), key.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".json")

    fun key(prefix: String, address: String): String =
        prefix + Integer.toHexString(address.hashCode()) + "_" + address.length

    /** True when [f] exists and is younger than [maxAgeMs] (and not older than [notOlderThan]). */
    fun isFresh(f: File, maxAgeMs: Long, notOlderThan: Long = 0L): Boolean =
        f.exists() && f.length() > 2L &&
            System.currentTimeMillis() - f.lastModified() < maxAgeMs &&
            f.lastModified() >= notOlderThan

    // ------------------------------------------------------------------ channels

    fun writeChannels(f: File, list: List<Channel>) {
        try {
            val tmp = File(f.parentFile, f.name + ".tmp")
            JsonWriter(BufferedWriter(OutputStreamWriter(tmp.outputStream(), Charsets.UTF_8), 64 * 1024)).use { w ->
                w.beginArray()
                for (c in list) {
                    w.beginObject()
                    w.name("n").value(c.name)
                    w.name("u").value(c.url)
                    if (c.logo.isNotEmpty()) w.name("l").value(c.logo)
                    if (c.group.isNotEmpty()) w.name("g").value(c.group)
                    if (c.seriesId.isNotEmpty()) w.name("s").value(c.seriesId)
                    if (c.infoId.isNotEmpty()) w.name("i").value(c.infoId)
                    w.endObject()
                }
                w.endArray()
            }
            f.delete()
            tmp.renameTo(f)
        } catch (_: Throwable) {
            // a cache that cannot be written is only slower, never wrong
        }
    }

    fun readChannels(f: File): List<Channel>? {
        if (!f.exists()) return null
        return try {
            JsonReader(BufferedReader(InputStreamReader(f.inputStream(), Charsets.UTF_8), 64 * 1024)).use { r ->
                val out = ArrayList<Channel>()
                r.beginArray()
                while (r.hasNext()) {
                    var n = ""
                    var u = ""
                    var l = ""
                    var g = ""
                    var s = ""
                    var i = ""
                    r.beginObject()
                    while (r.hasNext()) {
                        val name = r.nextName()
                        if (r.peek() == JsonToken.NULL) {
                            r.nextNull()
                            continue
                        }
                        val v = r.nextString()
                        when (name) {
                            "n" -> n = v
                            "u" -> u = v
                            "l" -> l = v
                            "g" -> g = v
                            "s" -> s = v
                            "i" -> i = v
                        }
                    }
                    r.endObject()
                    if (u.isNotEmpty()) out.add(Channel(name = n, url = u, logo = l, group = g, seriesId = s, infoId = i))
                }
                r.endArray()
                out
            }
        } catch (_: Throwable) {
            null
        }
    }

    // ------------------------------------------------------------------ packages (categories)

    fun writePkgs(f: File, list: List<Pkg>) {
        try {
            val tmp = File(f.parentFile, f.name + ".tmp")
            JsonWriter(BufferedWriter(OutputStreamWriter(tmp.outputStream(), Charsets.UTF_8))).use { w ->
                w.beginArray()
                for (p in list) {
                    w.beginObject()
                    w.name("i").value(p.id)
                    w.name("t").value(p.title)
                    if (p.leading.isNotEmpty()) w.name("l").value(p.leading)
                    w.endObject()
                }
                w.endArray()
            }
            f.delete()
            tmp.renameTo(f)
        } catch (_: Throwable) {
        }
    }

    fun readPkgs(f: File): List<Pkg>? {
        if (!f.exists()) return null
        return try {
            JsonReader(BufferedReader(InputStreamReader(f.inputStream(), Charsets.UTF_8))).use { r ->
                val out = ArrayList<Pkg>()
                r.beginArray()
                while (r.hasNext()) {
                    var i = ""
                    var t = ""
                    var l = ""
                    r.beginObject()
                    while (r.hasNext()) {
                        when (r.nextName()) {
                            "i" -> i = r.nextString()
                            "t" -> t = r.nextString()
                            "l" -> l = r.nextString()
                            else -> r.skipValue()
                        }
                    }
                    r.endObject()
                    if (i.isNotEmpty()) out.add(Pkg(i, t, l))
                }
                r.endArray()
                out
            }
        } catch (_: Throwable) {
            null
        }
    }

    // ------------------------------------------------------------------ maintenance

    /** Removes the cached Xtream data (called by "Update now" so the next open downloads fresh lists). */
    fun clearPrefix(prefix: String) {
        try {
            dir().listFiles()?.forEach { if (it.name.startsWith(prefix)) it.delete() }
        } catch (_: Throwable) {
        }
    }

    fun clearAll() {
        try {
            dir().listFiles()?.forEach { it.delete() }
        } catch (_: Throwable) {
        }
    }
}
