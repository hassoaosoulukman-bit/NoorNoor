package com.osogold.tv

/**
 * Bilingual (Arabic <-> English) phonetic and alias dictionary for the voice assistant and the search.
 * "بي ان سبورت" finds beIN, "ابو ظبي" finds AD Sport, "ام بي سي" finds MBC, "روتانا" finds Rotana ...
 * The numbers / words after a name are kept ("بي ان سبورت 1" -> "bein sports 1").
 */
object Aliases {

    /** Each line = the same name written in different ways (Arabic spellings, phonetic, English). */
    private val groups: List<List<String>> = listOf(
        listOf("بي ان سبورت", "بي ان سبورتس", "بين سبورت", "بي إن سبورت", "بى ان سبورت", "بي ان", "bein sports", "bein sport", "beinsports", "bein", "bein sports"),
        listOf("ابو ظبي الرياضيه", "ابوظبي الرياضيه", "ابو ظبي الرياضية", "ابو ظبي", "ابوظبي", "أبو ظبي", "ad sports", "ad sport", "abu dhabi sports", "abu dhabi", "adtv", "ad "),
        listOf("ام بي سي", "إم بي سي", "ام بى سى", "mbc"),
        listOf("روتانا", "rotana"),
        listOf("سكاي نيوز", "sky news"),
        listOf("سكاي سبورت", "sky sports", "sky sport"),
        listOf("سكاي", "sky"),
        listOf("الجزيره", "الجزيرة", "al jazeera", "aljazeera", "jazeera"),
        listOf("العربيه", "العربية", "al arabiya", "alarabiya"),
        listOf("الحدث", "al hadath", "alhadath"),
        listOf("سي ان ان", "cnn"),
        listOf("بي بي سي", "bbc"),
        listOf("دبي", "dubai"),
        listOf("الكويت", "kuwait", "kuwaiti"),
        listOf("السعوديه", "السعودية", "saudi", "ksa"),
        listOf("نايل سبورت", "nile sport", "nile sports"),
        listOf("نايل", "nile"),
        listOf("اوربت", "أوربت", "orbit"),
        listOf("ام تي في", "mtv"),
        listOf("ناشيونال جيوغرافيك", "ناشيونال جيوجرافيك", "ناشونال جيوغرافيك", "national geographic", "nat geo", "natgeo"),
        listOf("ديسكفري", "ديسكوفري", "discovery"),
        listOf("فوكس", "fox"),
        listOf("اي اس بي ان", "ايه اس بي ان", "espn"),
        listOf("يورو سبورت", "يوروسبورت", "eurosport"),
        listOf("ثمانيه", "ثمانية", "thmanyah"),
        listOf("قطر", "qatar"),
        listOf("دريم", "dream"),
        listOf("القاهره", "القاهرة", "cairo"),
        listOf("النهار", "al nahar", "alnahar"),
        listOf("الحياه", "الحياة", "al hayah", "alhayah"),
        listOf("سي بي سي", "cbc"),
        listOf("سبيستون", "سبيس تون", "spacetoon", "space toon"),
        listOf("كرتون نتورك", "كرتون نيتورك", "cartoon network"),
        listOf("ديزني", "disney"),
        listOf("نتفلكس", "نتفليكس", "netflix"),
        listOf("اتش بي او", "hbo"),
        listOf("اوسن", "أوسن", "osn"),
        listOf("شاهد", "shahid"),
        listOf("الشرقيه", "الشرقية", "al sharqiya", "alsharqiya"),
        listOf("العراقيه", "العراقية", "iraqiya", "iraqia"),
        listOf("كوردسات", "kurdsat"),
        listOf("روداو", "rudaw"),
        listOf("تي ار تي", "trt"),
        listOf("ماسه", "ماسة", "masa"),
        listOf("المملكه", "المملكة", "al mamlaka", "mamlaka"),
        listOf("رويا", "roya"),
        listOf("الغد", "al ghad", "alghad"),
        listOf("المنار", "al manar", "almanar"),
        listOf("الميادين", "al mayadeen", "almayadeen"),
        listOf("فرانس 24", "france 24", "france24"),
        listOf("روسيا اليوم", "rt arabic", "russia today", "rt"),
        listOf("دوتش فيله", "دويتشه فيله", "dw", "deutsche welle"),
        listOf("تلفزيون سوريا", "سوريا", "syria", "syrian"),
        listOf("لبنان", "lebanon", "lbc", "ال بي سي"),
        listOf("مصر", "egypt", "masr"),
        listOf("ابو ظبي الاولى", "ابوظبي الاولى", "abu dhabi 1", "abu dhabi tv"),
        listOf("اليوم", "alyaum"),
        listOf("كأس العالم", "كاس العالم", "world cup", "fifa")
    )

    /** Letters unified, spaces and symbols removed: the comparison key of a name. */
    fun key(text: String): String = LogoDb.norm(text)

    private val keyed: List<List<Pair<String, String>>> by lazy {
        groups.map { g -> g.map { it to key(it) }.filter { it.second.length >= 2 }.sortedByDescending { it.second.length } }
    }

    /** Different spellings of [query] (the original included): the matched name is replaced by every alias of it. */
    fun variants(query: String): List<String> {
        val out = LinkedHashSet<String>()
        out.add(query)
        val qk = key(query)
        if (qk.isEmpty()) return out.toList()
        for (g in keyed) {
            val hit = g.firstOrNull { qk.startsWith(it.second) } ?: continue
            val rest = qk.substring(hit.second.length) // "1", "hd", "" ...
            val restPretty = if (rest.isNotEmpty()) " $rest" else ""
            for ((raw, _) in g) out.add(raw.trim() + restPretty)
        }
        return out.toList()
    }

    /** All the aliases of the names found INSIDE [name] (used to find a logo by another spelling). */
    fun spellings(name: String): List<String> {
        val nk = key(name)
        val out = LinkedHashSet<String>()
        for (g in keyed) {
            val hit = g.firstOrNull { nk.contains(it.second) } ?: continue
            val rest = nk.substringAfter(hit.second)
            val tail = rest.takeWhile { it.isDigit() }
            for ((raw, _) in g) out.add(raw.trim() + (if (tail.isNotEmpty()) " $tail" else ""))
        }
        return out.toList()
    }

    /** True when the channel [name] answers [query] in any of the Arabic / English spellings. */
    fun matches(name: String, query: String): Boolean {
        val nk = key(name)
        if (nk.isEmpty()) return false
        for (v in variants(query)) {
            val vk = key(v)
            if (vk.length >= 2 && nk.contains(vk)) return true
        }
        return false
    }
}
