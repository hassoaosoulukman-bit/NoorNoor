package com.osogold.tv

/**
 * Arabic <-> Latin search helper for singers: "إبراهيم تاتليسس" also searches "Ibrahim Tatlises".
 * A dictionary of well known Turkish / Kurdish singers first, then a letter by letter transliteration.
 */
object Translit {

    private val dictionary = mapOf(
        "ابراهيم تاتليسس" to "Ibrahim Tatlises", "ابراهيم تاتلس" to "Ibrahim Tatlises", "ابراهيم تاتليس" to "Ibrahim Tatlises",
        "تاركان" to "Tarkan", "طركان" to "Tarkan", "شيفان برور" to "Sivan Perwer", "شيفان بروير" to "Sivan Perwer",
        "سيزن اكسو" to "Sezen Aksu", "اجدا بيكان" to "Ajda Pekkan", "بارش مانتشو" to "Baris Manco",
        "مسلم غورسس" to "Muslum Gurses", "ايبرو غوندش" to "Ebru Gundes", "مصطفى ساندال" to "Mustafa Sandal",
        "كينان دوغولو" to "Kenan Dogulu", "فرهاد تونج" to "Ferhat Tunc", "جوان حاجو" to "Ciwan Haco",
        "هوزان دينو" to "Hozan Dino", "ارام تيغران" to "Aram Tigran", "محسون كيرميزيغول" to "Mahsun Kirmizigul",
        "روجدا" to "Rojda", "ايدا" to "Hande Yener", "هاندي ينير" to "Hande Yener", "سرتاب ارنر" to "Sertab Erener",
        "فردي تايفور" to "Ferdi Tayfur", "اورهان جنجباي" to "Orhan Gencebay", "زكي موران" to "Zeki Muren",
        "عائشه" to "Ayse", "نظام الدين اريج" to "Nizamettin Aric", "ايدين" to "Aynur Dogan", "اينور دوغان" to "Aynur Dogan"
    )

    private val letters = mapOf(
        'ا' to "a", 'أ' to "a", 'إ' to "i", 'آ' to "a", 'ب' to "b", 'ت' to "t", 'ث' to "s", 'ج' to "c", 'ح' to "h",
        'خ' to "kh", 'د' to "d", 'ذ' to "z", 'ر' to "r", 'ز' to "z", 'س' to "s", 'ش' to "sh", 'ص' to "s", 'ض' to "d",
        'ط' to "t", 'ظ' to "z", 'ع' to "a", 'غ' to "g", 'ف' to "f", 'ق' to "k", 'ك' to "k", 'ل' to "l", 'م' to "m",
        'ن' to "n", 'ه' to "h", 'ة' to "a", 'و' to "u", 'ي' to "i", 'ى' to "a", 'ئ' to "i", 'ؤ' to "u", 'ء' to "",
        'پ' to "p", 'چ' to "c", 'گ' to "g", 'ڤ' to "v", 'ژ' to "j"
    )

    private fun isArabic(text: String) = text.any { it in '؀'..'ۿ' }

    /** All the spellings to search with (the typed text first). */
    fun variants(query: String): List<String> {
        val q = query.trim()
        if (q.isEmpty()) return emptyList()
        val out = LinkedHashSet<String>()
        out.add(q)
        if (isArabic(q)) {
            val n = ArabicText.normalize(q)
            dictionary[n]?.let { out.add(it) }
            for ((k, v) in dictionary) if (n.contains(k) || k.contains(n) && n.length >= 4) out.add(v)
            val sb = StringBuilder()
            for (ch in n) sb.append(if (ch == ' ') " " else letters[ch] ?: "")
            val latin = sb.toString().trim()
            if (latin.length >= 3) out.add(latin)
        }
        return out.toList().take(5)
    }
}
