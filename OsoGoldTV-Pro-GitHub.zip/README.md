# Oso Gold TV

تطبيق أندرويد (Kotlin + Media3/ExoPlayer) بتصميم "البوصلة الكونية" الأسود والذهبي.

## البناء التلقائي على GitHub
1. أنشئ مستودعاً جديداً على GitHub وارفع **كل** محتويات هذا المجلد (بما فيه المجلد المخفي `.github`).
2. بمجرد الرفع يبدأ GitHub Actions تلقائياً (تبويب **Actions** ← *Build Oso Gold TV APK*).
3. بعد انتهاء البناء (حوالي 3–6 دقائق) افتح التشغيل الناجح ونزّل الملف **OsoGoldTV-apk** من قسم *Artifacts*.
4. فكّ الضغط وثبّت `OsoGoldTV.apk` على الجوال (يلزم السماح بالتثبيت من مصادر غير معروفة).

> لإصدار رابط تنزيل ثابت: أنشئ وسماً (tag) مثل `v1.0.0` وسيُرفق الـ APK تلقائياً في صفحة *Releases*.

## كلمة السر
- كلمة السر الافتراضية: **1234** — غيّرها من *الإعدادات ← كلمة السر*.
- تُطلب مرة واحدة فقط، ثم تُحفظ حالة الدخول. عند تغيير كلمة السر تُطلب مرة أخرى في الفتح التالي.

## الفيديو الترحيبي
- بعد كلمة السر يعمل الفيديو الترحيبي بملء الشاشة مع زر **تخطي**.
- من *الإعدادات ← الفيديو الترحيبي*: اختر فيديو من المعرض أو صوّر فيديو جديداً.
- إن لم تختر فيديو، يعمل مقطع افتتاحي ملكي متحرك مدته 30 ثانية.
- (اختياري) ضع ملفاً باسم `welcome.mp4` في `app/src/main/res/raw/` ليكون الفيديو الافتراضي.

## القوائم (M3U)
الروابط الافتراضية من مشروع iptv-org ويمكن تغييرها من *الإعدادات ← مصادر القوائم*.

## هيكل المشروع
```
OsoGoldTV/
├── .github/workflows/build.yml
├── build.gradle
├── settings.gradle
├── gradle.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/osogold/tv/   (Kotlin)
        └── res/                   (layout, drawable, values, xml)
```

## الإصدار 3.0 — ما الجديد
- **الواجهة الرئيسية**: مشغّل مستطيل (~68%) تدور حوله أيقونات المدار؛ الباقي (~32%) قائمتان مستقلتان: الأقسام + القنوات (بشعارات القنوات).
- **المدار**: البث، المفضلة، الأفلام، المسلسلات، القرآن، الراديو، قوائمي، بحث، تحديث، المساعد الذكي، الإعدادات.
- **المفضلة**: صفحة بأربعة أقسام (قنوات/أفلام/مسلسلات/راديو) مع زر حذف لكل عنصر ورجوع خطوة بخطوة.
- **قوائمي**: كل ملفات/روابط M3U واشتراكات Xtream/Stalker بأسمائك، بنقرة واحدة للتبديل.
- **المشغل**: اللمس يُظهر/يُخفي القوائم فقط؛ التشغيل/الإيقاف بزر مخصص؛ جودات 360p…8K + Auto؛ إعادة اتصال تلقائية ومخزن 20 ثانية؛ زر تسجيل بعدّاد حي.
- **الإعدادات**: المشغل، التسجيلات، مؤقت النوم، التصليح التلقائي، المساعد، الدخول الذكي لـ Xtream (الصق الرابط الطويل) مع حقول الأسماء وزر «حفظ».

## What's new (this update)

- Build fix: `RecordingStore.delete()` uses a block body (`return` inside `?:` is not allowed with `=`).
- TMDB (Settings -> Add API key): Arabic story, poster, rating and trailer; the poster grid uses TMDB when the provider picture is missing.
- Movie / series page: full-screen trailer (Arabic subtitles requested), story, Play, Favourite; Play falls back to the other saved lists, Archive.org and official YouTube channels (YouTube needs a YouTube Data API key).
- Series: a check icon on watched episodes, saved second per episode, "continue watching".
- Settings -> Customise the main screen: 14 colour themes, left / center / right placement and sliders for width and height of the live screen and of the lists.
- Settings -> Add API key: TMDB / YouTube / AI keys stored with AES-256 (EncryptedSharedPreferences); save and delete.
- Settings -> Protection: DNS-over-HTTPS, TLS 1.3 (OkHttp + ExoPlayer), custom User-Agent, SOCKS5 / HTTP proxy, live "encrypted" indicator and a connection test. Subscriptions are stored AES-256 encrypted (old plain data is migrated).
- All players (ExoPlayer, LibVLC, the background service) stop when the app is left or closed.
- Back button goes one step back everywhere; on the main screen it returns to the live home first and needs a second press to exit.

## Part 1 of the final features

- Instant zapping: `DefaultLoadControl(1500, 30000, 500, 1500)`, background warm-up of the next / previous channel (`ZapPrefetcher`).
- Instant alternative channel: a live stream that stalls for 3 s (or fails after one retry) is replaced by the same channel in another quality / list (`StreamAlternatives`), with a small notice.
- Settings -> "شاشة الترحيب والهوية": welcome message, welcome picture, text size / colour / font / place, duration, main screen background, app icon (activity-alias + custom shortcut).
- Start sequence: welcome message -> welcome video -> main screen, "تخطي" on both.

## الميزات الأخيرة (الإصدار 3)
- **معادل الصوت (EQ)** بأوضاع جاهزة + مخصص، **بحث سريع** عن قناة وفي الأفلام/المسلسلات، **القناة السابقة ⇄**، **لقطة شاشة صافية** إلى ألبوم الصور، **شارة معلومات البث** (الدقة/FPS/Mbps)، **مباريات اليوم**، **صوت فقط**، **توصيل بالتلفاز**.
- **الترجمة الفورية للعربية (AI Live)**: نسخة صوتية مخفية على حافة البث المباشر + تأخير الصورة 5–30 ثانية في الذاكرة فقط للمزامنة؛ مجاني (ML Kit) أو فائق الدقة بمفتاح Gemini (الإعدادات ← إضافة مفتاح API).
- **الراديو**: Radio Browser (كردي/تركي/عربي/ألماني/عالمي + بحث فوري)، مشغل راديو/قرآن بموجات ذهبية ومؤقت نوم متدرج والآيات.
- **iptv-org** تلقائي التحديث + قنوات يوتيوب الرسمية داخل التطبيق، و**مشاركة التطبيق** (APK) عبر FileProvider.
